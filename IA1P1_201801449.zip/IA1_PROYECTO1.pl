 %--- BASE DE CONOCIMIENTOS ---%
artista(1,'queen',1,inactivo).
artista(2,'alex north',2,activo).
artista(3,'alice gomez',3,activo).
artista(4,'anders koppel',2,activo).
artista(5,'andrew thomas',2,activo).
artista(6,'axel fries',1,inactivo).
artista(7,'blake tyson',2,activo).
artista(8,'dave hollinden',2,activo).
artista(9,'david macbride',2,inactivo).
artista(10,'david mancini',4,activo).
artista(11,'emmanuel sejourne',5,activo).
artista(12,'eric sammut',6,activo).
artista(13,'gene koshinski',5,inactivo).
artista(14,'gordon stout',1,activo).
artista(15,'heitor villa-lobos',7,activo).
artista(16,'ivan trevino',4,activo).
artista(17,'jacob druckman',2,activo).
artista(18,'jesse monkman',2,activo).
artista(19,'joseph schwantner',8,inactivo).
artista(20,'juan vicente mas quiles',3,activo).
artista(21,'julie spencer',2,activo).
artista(22,'keiko abe',9,activo).
artista(23,'michael burritt',2,activo).
artista(24,'michio miyagi',10,activo).
artista(25,'minoru miki',9,inactivo).
artista(26,'mitchell peters',2,activo).
artista(27,'nancy zeltsman',2,activo).
artista(28,'nebojsa zivkovic',11,activo).
artista(29,'ney rosauro',2,activo).
artista(30,'owen clayton condon',2,inactivo).
artista(31,'paul creston',2,activo).
artista(32,'paul lansky',1,activo).
artista(33,'paul smadbeck',1,activo).
artista(34,'peter tanner',2,activo).
artista(35,'ross edwards',2,activo).
artista(36,'steve reich',2,activo).
artista(37,'takatsugu muramatsu',9,inactivo).
artista(38,'william kraft',1,activo).
artista(39,'madonna',2,inactivo).
artista(40,'michael jackson',2,inactivo).
artista(41,'the beatles',1,inactivo).
artista(42,'bts',10,activo).
artista(43,'sugarhill gang',2,activo).
artista(44,'grandmaster flash',2,activo).
artista(45,'afrika bambaataa',2,activo).
artista(46,'run-d.m.c.',2,activo).
artista(47,'public enemy',2,activo).
artista(48,'n.w.a',2,activo).
artista(49,'dj jazzy jeff',2,activo).
artista(50,'geto boys',2,activo).
artista(51,'dr. dre',2,activo).
artista(52,'coolio',2,inactivo).
artista(53,'2pac',2,activo).
artista(54,'the notorious b.i.g.',2,activo).
artista(55,'eminem',2,activo).
artista(56,'outkast',2,activo).
artista(57,'nelly',2,activo).
artista(58,'kanye west',2,inactivo).
artista(59,'beyonce',2,activo).
artista(60,'jay-z',2,activo).
artista(61,'snoop dogg',2,activo).
artista(62,'wiz khalifa',2,activo).
artista(63,'drake',2,activo).
artista(64,'mark ronson',2,activo).
artista(65,'travis scott',2,activo).
artista(66,'lil nas x',2,activo).
artista(67,'migos',2,activo).
artista(68,'kendrick lamar',2,activo).
artista(69,'post malone',2,activo).
artista(70,'billie eilish',2,activo).
artista(71,'megan thee stallion',2,activo).
artista(72,'cardi b',2,activo).
artista(73,'future',2,activo).
artista(74,'olivia rodrigo',3,activo).
artista(75,'silk sonic',12,activo).
artista(76,'call me by your name',2,activo).
artista(77,'wizkid',2,activo).
artista(78,'taylor swift',2,activo).
artista(79,'nicki minaj',2,activo).
artista(80,'24kgoldn',2,activo).
artista(81,'harry styles',2,activo).
artista(82,'juice wrld',2,activo).
artista(83,'alan walker',2,activo).
artista(84,'ariana grande',2,activo).
artista(85,'justin bieber',2,activo).
artista(86,'maroon 5',2,activo).
artista(87,'arizona zervas',2,activo).
artista(88,'lewis capaldi',2,activo).
artista(89,'the weeknd',2,activo).
artista(90,'tones and i',2,activo).
artista(91,'marshmello',2,activo).
artista(92,'shawn mend',2,activo).
artista(93,'carl philipp emanuel bach',8,inactivo).
artista(94,'wolfgang amadeus mozart',13,inactivo).
artista(95,'christoph willibald gluck',8,inactivo).
artista(96,'antonio vivaldi',4,inactivo).
artista(97,'john philip sousa',2,inactivo).
artista(98,'benjamin godard',1,inactivo).
artista(99,'gabriel faure',6,inactivo).
artista(100,'albert franz doppler',6,inactivo).
artista(101,'luigi hugues',4,inactivo).
artista(102,'paul taffanel',6,inactivo).
artista(103,'charles koechlin',6,inactivo).
artista(104,'claude debussy',6,activo).
artista(105,'paul hindemith',1,activo).
artista(106,'edgar varèse',6,activo).
artista(107,'samuel barber',8,activo).
artista(108,'toru takemitsu',1,activo).
artista(109,'ian clarke',1,activo).
artista(110,'sofia gubaidulina',1,activo).
artista(111,'jennifer higdon',1,activo).
artista(112,'melvin lauf jr.',1,inactivo).
artista(113,'gary schocker',1,activo).
artista(114,'wil offermans',1,activo).
artista(115,'matthias ziegler',1,activo).
artista(116,'mike mower',8,activo).
artista(117,'nicole chamberlain',1,activo).
artista(118,'valerie coleman',1,activo).
artista(119,'amanda harberg',8,activo).
artista(120,'derek charke',1,inactivo).
artista(121,'daniel dorff',1,activo).
artista(122,'toshio hosokawa',9,activo).
artista(123,'robert dick',1,activo).
artista(124,'eugene magalif',1,activo).
artista(125,'anne la berge',1,activo).
artista(126,'jonathan cohen',1,activo).
artista(127,'mary jane rupert',1,activo).
artista(128,'elizabeth brown',1,activo).
artista(129,'olivier messiaen',8,inactivo).
artista(130,'gergely ittzes',1,activo).
artista(131,'christopher rouse',1,activo).
artista(132,'katherine hoover',8,activo).
artista(133,'john thow',1,activo).
artista(134,'kaija saariaho',5,activo).
artista(135,'chen yi',14,activo).
artista(136,'louis armstrong',2,inactivo).
artista(137,'miles davis',2,inactivo).
artista(138,'john coltrane',2,inactivo).
artista(139,'django reinhardt',6,inactivo).
artista(140,'michel legrand',6,inactivo).
artista(141,'chucho valdes',15,inactivo).
artista(142,'paquito d rivera',15,inactivo).
artista(143,'b.b. king',2,inactivo).
artista(144,'muddy waters',2,inactivo).
artista(145,'robert johnson',2,inactivo).
artista(146,'john lee hooker',2,inactivo).
artista(147,'johnny cash',2,inactivo).
artista(148,'willie nelson',2,activo).
artista(149,'hank williams',2,activo).
artista(150,'aphex twin',2,activo).
artista(151,'bassnectar',2,activo).
artista(152,'orbital',1,inactivo).
artista(153,'daft punk',6,inactivo).
artista(154,'david guetta',6,inactivo).
artista(155,'ludwig van beethoven',8,inactivo).
artista(156,'pyotr ilyich tchaikovsky',16,inactivo).
artista(157,'bob marley',17,inactivo).
artista(158,'peter tosh',17,inactivo).
artista(159,'calypso rose',18,inactivo).
artista(160,'johnny ramone',2,inactivo).
artista(161,'sid vicious',1,inactivo).
artista(162,'james brown',2,inactivo).
artista(163,'prince',2,inactivo).
artista(164,'larry graham',2,inactivo).
artista(165,'black sabbath',1,inactivo).
artista(166,'iron maiden',1,inactivo).
artista(167,'judas priest',1,inactivo).
artista(168,'metallica',2,activo).
artista(169,'megadeth',2,activo).
artista(170,'slayer',2,activo).
artista(171,'bob dylan',2,activo).
artista(172,'woody guthrie',2,inactivo).
artista(173,'joni mitchell',19,activo).
artista(174,'mahalia jackson',2,activo).
artista(175,'kirk franklin',2,activo).
artista(176,'celia cruz',15,inactivo).
artista(177,'tito puente',2,inactivo).
artista(178,'hector lavoe',20,inactivo).
artista(179,'willie colon',20,inactivo).
artista(180,'ruben blades',21,inactivo).
artista(181,'gilberto santa rosa',20,inactivo).
artista(182,'johnny pacheco',22,inactivo).
artista(183,'oscar d leon',23,inactivo).
artista(184,'jerry rivera',20,inactivo).
artista(185,'romeo santos',22,activo).
artista(186,'juan luis guerra',22,activo).
artista(187,'antony santos',22,activo).
artista(188,'silvio rodriguez',15,activo).
artista(189,'pablo milanes',15,inactivo).
artista(190,'vicente feliu',15,inactivo).
artista(191,'noel nicola',15,inactivo).
artista(192,'luis eduardo aute',24,inactivo).
artista(193,'leon gieco',25,inactivo).
artista(194,'mercedes sosa',25,inactivo).
artista(195,'victor jara',26,inactivo).
artista(196,'carlos mejia godoy',27,activo).
artista(197,'quinteto tiempo',25,inactivo).

cancion(1,'unchained melody',2,1955,30,3,3,6,5.98).
cancion(2,'rain dance',3,1993,30,3,3,3,3.01).
cancion(3,'aurora',4,2008,30,4,1,6,5.62).
cancion(4,'merlin',5,2004,30,3,1,9,5.46).
cancion(5,'april sun',6,2006,30,2,2,3,2.16).
cancion(6,'a cricket sang and set the sun',7,2003,30,4,1,7,1.77).
cancion(7,'a song of piccolo',7,2003,30,3,1,3,5.17).
cancion(8,'neon',8,1990,30,4,4,9,2.56).
cancion(9,'leigh howard stevens tribute',8,2005,30,3,1,3,3.15).
cancion(10,'twice removed',9,2006,30,3,2,5,1.05).
cancion(11,'schizophrenic',10,2006,30,5,5,7,3.05).
cancion(12,'etude in a minor',11,2004,30,5,2,6,5.93).
cancion(13,'strange dreams',12,2001,30,4,5,9,5.13).
cancion(14,'four rotations',12,2006,30,5,4,1,3.69).
cancion(15,'moon chasers',13,2003,30,3,4,8,1.45).
cancion(16,'two mexican dances',14,1983,30,1,2,5,3.64).
cancion(17,'two mexican dances',14,1983,30,4,2,2,1.79).
cancion(18,'bachianas brasileiras no. 5',15,1938,30,1,2,2,4.19).
cancion(19,'catching shadows',16,2013,30,4,3,9,5.63).
cancion(20,'whispers from beyond',16,2016,30,2,2,9,4.22).
cancion(21,'reflections on the nature of water',17,1986,30,4,1,9,2.13).
cancion(22,'cuban landscape with rain',18,2013,30,4,5,5,4.54).
cancion(23,'velocities',19,1990,30,4,2,2,4.9).
cancion(24,'etude in e minor',20,1995,30,1,1,3,3.98).
cancion(25,'elegy for solo marimba',21,1998,30,2,3,3,4.18).
cancion(26,'prism rhapsody',22,1986,30,3,4,6,1.17).
cancion(27,'variations on japanese childrens songs',22,1978,30,4,2,2,5.02).
cancion(28,'my lady white',22,1990,30,2,2,1,3.48).
cancion(29,'prism rhapsody',22,1986,30,3,4,4,4).
cancion(30,'the offering',23,1998,30,4,1,7,1.13).
cancion(31,'kebyar',23,2008,30,2,2,6,5.4).
cancion(32,'ryukyu-bushi',24,1927,30,3,4,10,4.69).
cancion(33,'marimba spiritual',25,1984,30,3,1,7,2.86).
cancion(34,'time for marimba',25,1977,30,3,3,8,4.97).
cancion(35,'yellow after the rain',26,1979,30,1,5,8,2.94).
cancion(36,'opus no. 5',27,1995,30,3,4,9,4.08).
cancion(37,'valse brillante',28,1999,30,5,2,2,4.88).
cancion(38,'prelude no. 1',29,1986,30,2,3,1,3.21).
cancion(39,'suite for marimba',29,1986,30,3,5,4,2.01).
cancion(40,'concerto for marimba',29,1991,30,2,4,6,3.33).
cancion(41,'fractalia',30,2010,30,3,5,9,5.49).
cancion(42,'toccata',31,1980,30,2,2,2,4.85).
cancion(43,'three moves for marimba',32,1985,30,4,1,5,1.07).
cancion(44,'rhythm song',33,1980,30,2,1,3,2.29).
cancion(45,'suite for marimba',34,2008,30,1,1,9,1.65).
cancion(46,'marimba dances',35,1984,30,2,4,4,2.72).
cancion(47,'percussive counterpoint',36,1973,30,2,1,10,3.9).
cancion(48,'land',37,2007,30,4,1,7,2.57).
cancion(49,'spiral passages',38,1997,30,3,3,3,3.66).
cancion(50,'keep yourself alive',1,1973,2,1,2,3,2.72).
cancion(51,'doing all right',1,1973,2,4,3,1,5.83).
cancion(52,'great king rat',1,1973,2,5,1,9,4.99).
cancion(53,'my fairy king',1,1973,2,4,1,10,5.27).
cancion(54,'liar',1,1973,2,1,4,5,5.67).
cancion(55,'the night comes down',1,1973,2,3,5,10,5.09).
cancion(56,'modern times rock n roll',1,1973,2,2,4,3,4.37).
cancion(57,'son and daughter',1,1973,2,4,3,3,3).
cancion(58,'jesus',1,1973,2,4,1,5,3.9).
cancion(59,'seven seas of rhye',1,1973,2,4,4,10,4.83).
cancion(60,'procession',1,1974,2,3,1,1,1.34).
cancion(61,'father to son',1,1974,2,3,1,2,3.35).
cancion(62,'white queen (as it began)',1,1974,2,3,5,2,1.4).
cancion(63,'some day one day',1,1974,2,1,4,9,4.09).
cancion(64,'the loser in the end',1,1974,2,1,4,10,1.02).
cancion(65,'ogre battle',1,1974,2,1,5,1,2.46).
cancion(66,'the fairy fellers master-stroke',1,1974,2,2,3,1,3.1).
cancion(67,'nevermore',1,1974,2,2,3,4,4).
cancion(68,'the march of the black queen',1,1974,2,2,2,6,5.37).
cancion(69,'funny how love is',1,1974,2,2,2,10,2.07).
cancion(70,'seven seas of rhye',1,1974,2,3,4,8,1.38).
cancion(71,'brighton rock',1,1974,2,3,1,6,1.24).
cancion(72,'killer queen',1,1974,2,2,3,8,5.76).
cancion(73,'tenement funster',1,1974,2,4,5,4,2.13).
cancion(74,'flick of the wrist',1,1974,2,3,4,10,5.09).
cancion(75,'lily of the valley',1,1974,2,4,5,7,2.76).
cancion(76,'now im here',1,1974,2,3,1,3,2.94).
cancion(77,'in the lap of the gods',1,1974,2,3,3,9,3.59).
cancion(78,'stone cold crazy',1,1974,2,4,2,6,2.43).
cancion(79,'dear friends',1,1974,2,2,4,10,4.82).
cancion(80,'misfire',1,1974,2,5,1,10,1.16).
cancion(81,'bring back that leroy brown',1,1974,2,5,4,9,2.66).
cancion(82,'she makes me',1,1974,2,4,3,2,3.72).
cancion(83,'in the lap of the gods',1,1974,2,4,4,6,3.66).
cancion(84,'death on two legs',1,1975,2,3,3,9,3.87).
cancion(85,'lazing on a sunday afternoon',1,1975,2,5,2,9,5.36).
cancion(86,'im in love with my car',1,1975,2,4,5,7,1.64).
cancion(87,'youre my best friend',1,1975,2,5,4,10,2.14).
cancion(88,'39',1,1975,2,4,3,4,3.98).
cancion(89,'sweet lady',1,1975,2,4,2,8,4.9).
cancion(90,'seaside rendezvous',1,1975,2,3,3,2,3.19).
cancion(91,'the prophets song',1,1975,2,4,3,8,4.12).
cancion(92,'love of my life',1,1975,2,2,1,6,2.05).
cancion(93,'good company',1,1975,2,3,1,7,1.47).
cancion(94,'bohemian rhapsody',1,1975,2,3,3,6,2.44).
cancion(95,'god save the queen',1,1975,2,3,2,9,1.68).
cancion(96,'tie your mother down',1,1976,2,4,4,3,1.25).
cancion(97,'you take my breath away',1,1976,2,2,5,6,2.76).
cancion(98,'long away',1,1976,2,4,1,5,4.57).
cancion(99,'the millionaire waltz',1,1976,2,4,4,9,1.72).
cancion(100,'you and i',1,1976,2,5,2,8,4.18).
cancion(101,'somebody to love',1,1976,2,4,3,2,2.37).
cancion(102,'white man',1,1976,2,4,1,10,5.4).
cancion(103,'good old-fashioned lover boy',1,1976,2,4,3,10,2.76).
cancion(104,'drowse',1,1976,2,3,1,7,4.31).
cancion(105,'teo torriate',1,1976,2,2,3,7,4.38).
cancion(106,'we will rock you',1,1977,2,4,3,10,3.89).
cancion(107,'we are the champions',1,1977,2,2,4,10,3.12).
cancion(108,'sheer heart attack',1,1977,2,5,2,2,3.1).
cancion(109,'all dead, all dead',1,1977,2,5,1,10,1.51).
cancion(110,'spread your wings',1,1977,2,4,5,8,4.15).
cancion(111,'fight from the inside',1,1977,2,5,2,4,4.23).
cancion(112,'get down, make love',1,1977,2,3,4,2,1.41).
cancion(113,'sleeping on the sidewalk',1,1977,2,4,5,3,3.2).
cancion(114,'who needs you',1,1977,2,2,3,2,2.76).
cancion(115,'its late',1,1977,2,5,2,6,3.29).
cancion(116,'my melancholy blues',1,1977,2,4,2,1,3).
cancion(117,'mustapha',1,1978,2,4,5,7,5.52).
cancion(118,'fat bottomed girls',1,1978,2,5,4,5,4.5).
cancion(119,'jealousy',1,1978,2,1,3,3,2.78).
cancion(120,'bicycle race',1,1978,2,3,4,4,3.96).
cancion(121,'if you cant beat them',1,1978,2,3,4,9,5.13).
cancion(122,'let me entertain you',1,1978,2,2,5,9,2.26).
cancion(123,'dead on time',1,1978,2,3,4,7,5.68).
cancion(124,'in only seven days',1,1978,2,2,2,10,3.05).
cancion(125,'dreamers ball',1,1978,2,2,3,5,1.06).
cancion(126,'fun it',1,1978,2,5,1,4,4.1).
cancion(127,'leaving home aint easy',1,1978,2,4,2,9,3.47).
cancion(128,'dont stop me now',1,1978,2,4,1,4,3.84).
cancion(129,'more of that jazz',1,1978,2,4,2,10,5.88).
cancion(130,'play the game',1,1980,2,4,5,5,2.04).
cancion(131,'dragon attack',1,1980,2,2,3,4,4.16).
cancion(132,'another one bites the dust',1,1980,2,4,3,5,4.85).
cancion(133,'need your loving tonight',1,1980,2,3,4,2,2.9).
cancion(134,'crazy little thing called love',1,1980,2,4,1,3,3.62).
cancion(135,'rock it (prime jive)',1,1980,2,1,1,2,2.82).
cancion(136,'dont try suicide',1,1980,2,1,4,5,2.57).
cancion(137,'sail away sweet sister',1,1980,2,4,4,7,3.56).
cancion(138,'coming soon',1,1980,2,5,3,4,3.53).
cancion(139,'save me',1,1980,2,3,1,1,5.57).
cancion(140,'staying power',1,1982,2,4,1,8,3.89).
cancion(141,'dancer',1,1982,2,3,1,8,5.15).
cancion(142,'back chat',1,1982,2,3,4,4,4.91).
cancion(143,'body language',1,1982,2,1,4,6,3.54).
cancion(144,'action this day',1,1982,2,1,1,1,5.04).
cancion(145,'put out the fire',1,1982,2,3,1,7,3.57).
cancion(146,'life is real (song for lennon)',1,1982,2,5,2,7,2.94).
cancion(147,'calling all girls',1,1982,2,1,3,10,2.62).
cancion(148,'las palabras de amor',1,1982,2,3,5,3,5.37).
cancion(149,'cool cat',1,1982,2,2,1,3,4.99).
cancion(150,'under pressure',1,1982,2,3,5,8,4.21).
cancion(151,'radio ga ga',1,1984,2,3,5,6,2.69).
cancion(152,'tear it up',1,1984,2,2,1,1,5.7).
cancion(153,'its a hard life',1,1984,2,3,1,7,2.29).
cancion(154,'man on the prowl',1,1984,2,2,2,10,1.73).
cancion(155,'machines (or back to humans)',1,1984,2,4,1,10,3.73).
cancion(156,'i want to break free',1,1984,2,3,5,9,5.23).
cancion(157,'keep passing the open windows',1,1984,2,3,5,4,1.6).
cancion(158,'hammer to fall',1,1984,2,4,1,7,1.77).
cancion(159,'is this the world we created...?',1,1984,2,3,3,10,2.94).
cancion(160,'one vision',1,1986,2,3,2,1,4.98).
cancion(161,'a kind of magic',1,1986,2,4,1,1,3.4).
cancion(162,'one year of love',1,1986,2,3,5,8,1.51).
cancion(163,'pain is so close to pleasure',1,1986,2,4,4,2,5.24).
cancion(164,'friends will be friends',1,1986,2,3,2,9,4.59).
cancion(165,'who wants to live forever',1,1986,2,4,1,1,2.97).
cancion(166,'gimme the prize',1,1986,2,4,4,8,2.11).
cancion(167,'dont lose your head',1,1986,2,4,2,9,5.85).
cancion(168,'princes of the universe',1,1986,2,4,3,1,3.24).
cancion(169,'party',1,1989,2,2,1,7,5.2).
cancion(170,'khashoggis ship',1,1989,2,3,4,8,2.29).
cancion(171,'the miracle',1,1989,2,2,5,7,2.98).
cancion(172,'i want it all',1,1989,2,3,1,7,3.27).
cancion(173,'the invisible man',1,1989,2,3,4,5,2.08).
cancion(174,'breakthru',1,1989,2,3,3,8,4.47).
cancion(175,'rain must fall',1,1989,2,5,4,3,2.74).
cancion(176,'scandal',1,1989,2,2,2,10,4.37).
cancion(177,'my baby does me',1,1989,2,2,3,1,4.63).
cancion(178,'was it all worth it',1,1989,2,2,2,9,4.79).
cancion(179,'innuendo',1,1991,2,3,4,5,5.52).
cancion(180,'im going slightly mad',1,1991,2,3,3,3,5.47).
cancion(181,'headlong',1,1991,2,4,4,8,5.67).
cancion(182,'i cant live with you',1,1991,2,1,5,3,3.76).
cancion(183,'dont try so hard',1,1991,2,2,2,2,3.28).
cancion(184,'ride the wild wind',1,1991,2,4,5,4,5.91).
cancion(185,'all gods people',1,1991,2,4,3,2,5.31).
cancion(186,'these are the days of our lives',1,1991,2,3,3,6,3.24).
cancion(187,'delilah',1,1991,2,1,5,8,2.42).
cancion(188,'the hitman',1,1991,2,2,5,5,1.19).
cancion(189,'bijou',1,1991,2,4,3,8,2.81).
cancion(190,'the show must go on',1,1991,2,1,1,3,3.9).
cancion(191,'its a beautiful day',1,1995,2,4,2,2,4.8).
cancion(192,'made in heaven',1,1995,2,4,5,4,3.21).
cancion(193,'let me live',1,1995,2,1,5,5,5.45).
cancion(194,'mother love',1,1995,2,2,3,5,5.11).
cancion(195,'my life has been saved',1,1995,2,3,3,2,4.94).
cancion(196,'i was born to love you',1,1995,2,5,2,8,3.58).
cancion(197,'heaven for everyone',1,1995,2,3,3,7,3.18).
cancion(198,'too much love will kill you',1,1995,2,2,5,9,2.97).
cancion(199,'you dont fool me',1,1995,2,2,5,1,2.52).
cancion(200,'a winters tale',1,1995,2,3,3,2,4.4).
cancion(201,'its a beautiful day (reprise)',1,1995,2,3,2,9,2.62).
cancion(202,'hold my hand',40,2010,1,3,4,8,5.83).
cancion(203,'hollywood tonight',40,2010,1,4,2,5,5.06).
cancion(204,'heartbreaker',40,2001,1,3,4,4,5.9).
cancion(205,'invincible',40,2001,1,2,4,4,3.66).
cancion(206,'liberian girl',40,2012,1,4,2,6,5.3).
cancion(207,'you rock my world',40,2001,1,3,4,3,1.69).
cancion(208,'love never felt so good',40,2003,1,4,4,10,5.8).
cancion(209,'cry',40,2001,1,3,4,10,4.71).
cancion(210,'beat it',40,2003,1,3,4,2,3.52).
cancion(211,'say say say',40,2008,1,5,4,1,4.58).
cancion(212,'i just cant stop loving you',40,2014,1,5,1,4,5).
cancion(213,'do you know where your children are',40,2014,1,4,2,8,1.81).
cancion(214,'streetwalker',40,1987,1,5,3,6,1).
cancion(215,'threatened',40,2001,1,3,4,1,2.24).
cancion(216,'morphine',40,1997,1,1,5,1,4.77).
cancion(217,'little susie',40,1995,1,4,3,8,5.21).
cancion(218,'someone in the dark',40,1982,1,1,5,6,3.58).
cancion(219,'just good friends',40,2012,1,4,1,10,2.23).
cancion(220,'you are my life',40,2001,1,2,4,7,1.68).
cancion(221,'blame it on the boogie',40,2005,1,4,5,10,5.85).
cancion(222,'man in the mirror',40,2009,1,4,4,6,5.45).
cancion(223,'dont stop til you get enough',40,2003,1,4,2,10,2.82).
cancion(224,'privacy',40,2001,1,1,1,2,5.46).
cancion(225,'2000 watts',40,2001,1,2,1,5,4).
cancion(226,'the lost children',40,2001,1,3,1,2,4.17).
cancion(227,'rock with you',40,2003,1,4,1,7,3.5).
cancion(228,'dont walk away',40,2001,1,2,4,6,2.46).
cancion(229,'is it scary',40,1997,1,3,4,9,5.66).
cancion(230,'abc the jackson 5 and michael jackson',40,1993,1,4,1,8,5.37).
cancion(231,'hold my hand - duet with akon',40,2010,1,2,1,9,1.09).
cancion(232,'can you feel it',40,1991,1,3,4,9,2.32).
cancion(233,'dont stop till you get enough',40,2006,1,3,4,4,5.55).
cancion(234,'we are the world',40,1993,1,3,1,6,5.07).
cancion(235,'you rock my world',40,2004,1,1,3,6,5.71).
cancion(236,'working day and night',40,1979,1,3,4,2,2.71).
cancion(237,'fly away',40,1987,1,5,1,8,1.07).
cancion(238,'childhood',40,1995,1,2,1,9,4.71).
cancion(239,'earth song',40,2003,1,3,2,1,3.09).
cancion(240,'superfly sister',40,1997,1,2,2,9,2.4).
cancion(241,'my girl',40,1972,1,3,3,5,3.95).
cancion(242,'behind the mask',40,2010,1,2,1,4,2.55).
cancion(243,'i like the way you love me',40,2010,1,4,2,6,5.3).
cancion(244,'p.y.t.',40,1982,1,2,2,9,3.32).
cancion(245,'were almost there',40,1975,1,1,5,7,3.84).
cancion(246,'youve got a friend',40,1971,1,2,4,5,5.15).
cancion(247,'in our small way',40,1971,1,2,5,7,5.14).
cancion(248,'breaking news',40,2010,1,4,3,6,5.73).
cancion(249,'keep your head up',40,2010,1,3,4,5,2.49).
cancion(250,'for all time',40,2008,1,1,3,3,4.07).
cancion(251,'black or white',40,2003,1,4,1,7,3.45).
cancion(252,'music and me',40,1973,1,5,2,10,2.18).
cancion(253,'got to be there',40,2008,1,4,1,5,2.6).
cancion(254,'childhood',40,1995,1,1,2,8,1.85).
cancion(255,'shake your body',40,2004,1,3,1,10,4.63).
cancion(256,'best of joy',40,2010,1,2,4,2,1.38).
cancion(257,'weve got a good thing going',40,1972,1,4,2,1,4.92).
cancion(258,'weve had enough',40,2004,1,4,2,10,4.08).
cancion(259,'just a little bit of you',40,1975,1,4,4,9,4.16).
cancion(260,'todo mi amor eres tu',40,2001,1,3,3,10,3.9).
cancion(261,'much too soon',40,2010,1,3,5,8,4.2).
cancion(262,'ill be there',40,1986,1,3,4,6,4.91).
cancion(263,'shoo-be-doo-be-doo-da-day',40,1972,1,1,1,7,1.27).
cancion(264,'greatest show on earth',40,1972,1,1,3,1,4.3).
cancion(265,'girl dont take your love from me',40,1971,1,1,4,4,5.83).
cancion(266,'farewell my summer love',40,1984,1,2,3,1,4.86).
cancion(267,'someone put your hand out',40,2004,1,2,2,4,3.67).
cancion(268,'a place with no name',40,2014,1,2,2,7,1.56).
cancion(269,'all i need',40,2014,1,2,5,6,2.07).
cancion(270,'blue gangster',40,2014,1,3,5,1,2.85).
cancion(271,'chicago',40,2014,1,3,1,2,3.85).
cancion(272,'i have this dream',40,2014,1,2,4,7,3.37).
cancion(273,'i was the loser',40,2014,1,4,2,9,4.28).
cancion(274,'love never felt so good',40,2014,1,3,2,10,4.65).
cancion(275,'loving you',40,2014,1,4,1,10,1.03).
cancion(276,'she was loving me',40,2014,1,3,2,6,1.4).
cancion(277,'slave to the rhythm',40,2014,1,3,5,6,3.04).
cancion(278,'xscape',40,2014,1,4,2,5,1.25).
cancion(279,'another day',40,2010,1,2,5,6,1.89).
cancion(280,'mamas pear',40,2010,1,5,1,5,1.42).
cancion(281,'monster',40,2010,1,5,2,1,5.16).
cancion(282,'abc',40,2009,1,4,5,2,2.76).
cancion(283,'aint no sunshine',40,2009,1,4,3,8,5.71).
cancion(284,'ben',40,2009,1,3,2,5,5.93).
cancion(285,'dancing machin',40,2009,1,5,2,5,3.86).
cancion(286,'dancing machine',40,2009,1,4,3,10,5.96).
cancion(287,'forever came today',40,2009,1,5,1,9,2.98).
cancion(288,'hum along and dance',40,2009,1,4,1,4,5.11).
cancion(289,'i wanna be where you are',40,2009,1,4,3,10,4.56).
cancion(290,'ill be there',40,2009,1,3,3,2,1.7).
cancion(291,'maria',40,2009,1,4,5,5,1.57).
cancion(292,'maybe tomorrow',40,2009,1,2,4,5,2.18).
cancion(293,'never can say goodbye',40,2009,1,3,2,2,1.84).
cancion(294,'planet earth',40,2009,1,3,4,10,4.82).
cancion(295,'planet earth',40,2009,1,3,1,7,5.65).
cancion(296,'skywriter',40,2009,1,4,1,4,4.43).
cancion(297,'the girl is mine',40,2009,1,2,5,9,2.33).
cancion(298,'this is it',40,2009,1,4,5,2,3.29).
cancion(299,'working day night',40,2009,1,4,4,2,5.12).
cancion(300,'a kingdom in ruins',40,2008,1,5,3,10,2.57).
cancion(301,'a new friend',40,2008,1,4,1,1,1.42).
cancion(302,'behold the man',40,2008,1,4,3,2,2.11).
cancion(303,'thriller',40,1980,1,4,4,7,3.41).
cancion(304,'blue skies',40,1999,1,3,3,7,2.05).
cancion(305,'can i see you in the morning',40,1999,1,2,1,9,3.71).
cancion(306,'can you remember',40,1999,1,4,3,6,5.96).
cancion(307,'dapper ',40,1999,1,2,3,5,1.71).
cancion(308,'girl is mine, the',40,1999,1,5,4,5,4.8).
cancion(309,'goin back to indiana',40,1999,1,5,1,5,3.52).
cancion(310,'ill bet you',40,1999,1,4,1,4,5.7).
cancion(311,'lookin through the windows',40,1999,1,5,3,7,2.08).
cancion(312,'my little baby',40,1999,1,3,4,6,1.13).
cancion(313,'true love can be beautiful',40,1999,1,4,3,1,3.5).
cancion(314,'whos lovin you',40,1999,1,2,3,3,4.2).
cancion(315,'dancing machine',40,1998,1,5,3,5,5.02).
cancion(316,'twenty five miles',40,1998,1,4,4,9,3.98).
cancion(317,'bad ',40,1997,1,4,3,5,5.91).
cancion(318,'blood on the dance floor',40,1997,1,5,2,2,3.41).
cancion(319,'earth song',40,1997,1,1,1,8,3.42).
cancion(320,'ghosts',40,1997,1,3,5,8,5.08).
cancion(321,'history',40,1997,1,3,4,10,5.1).
cancion(322,'money ',40,1997,1,2,4,2,5.34).
cancion(323,'scream louder',40,1997,1,3,4,2,5.41).
cancion(324,'stranger in moscow',40,1997,1,2,2,9,2.35).
cancion(325,'this time around',40,1997,1,2,2,10,3.16).
cancion(326,'you are not alone',40,1997,1,5,5,1,4.53).
cancion(327,'they dont care about us',40,1996,1,4,3,10,5.01).
cancion(328,'call on me',40,1995,1,4,5,6,3.44).
cancion(329,'come together',40,1995,1,4,5,9,2.43).
cancion(330,'d.s.',40,1995,1,4,4,3,4.57).
cancion(331,'dont let it get you down',40,1995,1,2,3,5,1.75).
cancion(332,'earth song',40,1995,1,4,1,5,3.61).
cancion(333,'history',40,1995,1,3,1,8,5.5).
cancion(334,'ill be there',40,1995,1,4,4,7,5.98).
cancion(335,'if n i was god',40,1995,1,1,2,3,2.76).
cancion(336,'loves gone bad',40,1995,1,1,2,10,4.94).
cancion(337,'holiday',39,1983,1,4,3,2,4.97).
cancion(338,'like a virgin',39,1984,1,5,2,2,3.9).
cancion(339,'material girl',39,1985,1,3,2,6,2.81).
cancion(340,'into the groove',39,1985,1,4,2,9,2.16).
cancion(341,'papa dont preach',39,1986,1,3,1,6,1.6).
cancion(342,'la isla bonita',39,1986,1,3,1,4,1.35).
cancion(343,'like a prayer',39,1989,1,1,4,4,5.47).
cancion(344,'express yourself',39,1989,1,1,3,3,4.14).
cancion(345,'vogue',39,1990,1,3,4,6,5.77).
cancion(346,'justify my love',39,1990,1,5,5,5,3.03).
cancion(347,'frozen',39,1998,1,1,1,8,5.75).
cancion(348,'ray of light',39,1998,1,3,4,7,5.25).
cancion(349,'music',39,2000,1,2,3,6,2.53).
cancion(350,'dont tell me',39,2000,1,3,2,6,2.43).
cancion(351,'hung up',39,2005,1,3,1,8,2.21).
cancion(352,'sorry',39,2006,1,2,4,3,3.66).
cancion(353,'4 minutes',39,2008,1,3,4,5,2.42).
cancion(354,'give it 2 me',39,2008,1,2,1,9,5.39).
cancion(355,'like a prayer',39,2008,1,4,3,5,1.93).
cancion(356,'celebration',39,2009,1,3,3,4,5.07).
cancion(357,'girl gone wild',39,2012,1,3,2,9,3.98).
cancion(358,'living for love',39,2015,1,4,1,4,5.43).
cancion(359,'ghosttown',39,2015,1,3,4,9,3.2).
cancion(360,'medellín',39,2019,1,3,5,8,1.4).
cancion(361,'crave',39,2019,1,4,1,9,4.56).
cancion(362,'i dont search i find',39,2019,1,3,5,2,1.41).
cancion(363,'hung up',39,2020,1,4,5,6,1.79).
cancion(364,'i rise',39,2019,1,3,2,9,1.18).
cancion(365,'holiday',39,1983,1,4,1,1,5.78).
cancion(366,'rain',39,1993,1,4,1,8,4.25).
cancion(367,'secret',39,1994,1,4,3,10,2.09).
cancion(368,'bedtime story',39,1995,1,4,5,9,1.96).
cancion(369,'american pie',39,2000,1,2,2,2,2.67).
cancion(370,'die another day',39,2002,1,3,1,9,5.94).
cancion(371,'love profusion',39,2003,1,2,2,9,4.6).
cancion(372,'nothing fails',39,2003,1,3,2,8,5.3).
cancion(373,'sorry',39,2008,1,3,4,9,3.51).
cancion(374,'4 minutes',39,2008,1,3,1,3,4.32).
cancion(375,'love spent',39,2012,1,5,1,3,1.76).
cancion(376,'turn up the radio',39,2012,1,2,2,6,5.08).
cancion(377,'masterpiece',39,2011,1,2,3,4,5.03).
cancion(378,'gang bang',39,2012,1,2,2,7,3.11).
cancion(379,'bitch im madonna',39,2015,1,3,5,5,5.26).
cancion(380,'devil pray',39,2015,1,3,5,4,3.13).
cancion(381,'unapologetic bitch',39,2015,1,4,1,7,2.23).
cancion(382,'crazy for you',39,1985,1,1,5,3,4.54).
cancion(383,'true blue',39,1986,1,2,3,3,1.2).
cancion(384,'whos that girl',39,1987,1,4,5,4,4.06).
cancion(385,'causing a commotion',39,1987,1,4,5,2,4.49).
cancion(386,'cherish',39,1989,1,3,3,9,5.85).
cancion(387,'erotica',39,1992,1,1,2,10,3).
cancion(388,'deeper and deeper',39,1992,1,2,3,4,5.1).
cancion(389,'take a bow',39,1994,1,4,3,1,3.22).
cancion(390,'bedtime story',39,1994,1,1,3,10,1.5).
cancion(391,'human nature',39,1995,1,4,3,8,2.44).
cancion(392,'beautiful stranger',39,1999,1,4,5,9,4.94).
cancion(393,'die another day',39,2002,1,1,5,10,1.25).
cancion(394,'american life',39,2003,1,2,3,5,4.14).
cancion(395,'jump',39,2006,1,3,5,5,2.94).
cancion(396,'4 minutes',39,2008,1,5,1,9,3.95).
cancion(397,'love me do',41,1962,2,3,5,3,3.28).
cancion(398,'please please me',41,1963,2,2,5,2,2.11).
cancion(399,'i saw her standing there',41,1963,2,2,2,9,1.74).
cancion(400,'twist and shout',41,1963,2,3,4,4,3.42).
cancion(401,'all my loving',41,1963,2,3,1,5,1.58).
cancion(402,'a hard days night',41,1964,2,3,4,2,3).
cancion(403,'cant buy me love',41,1964,2,4,1,5,3.37).
cancion(404,'and i love her',41,1964,2,3,5,10,4.01).
cancion(405,'i want to hold your hand',41,1963,2,2,1,4,3.26).
cancion(406,'eight days a week',41,1964,2,4,4,7,5.73).
cancion(407,'i feel fine',41,1964,2,3,3,6,2.35).
cancion(408,'ticket to ride',41,1965,2,4,1,3,4.83).
cancion(409,'help!',41,1965,2,3,1,5,2.59).
cancion(410,'youve got to hide your love away',41,1965,2,3,1,2,5.89).
cancion(411,'yesterday',41,1965,2,5,5,7,1.5).
cancion(412,'we can work it out',41,1965,2,5,4,9,2.66).
cancion(413,'day tripper',41,1965,2,4,4,1,1.79).
cancion(414,'drive my car',41,1965,2,5,4,1,3.56).
cancion(415,'norwegian wood',41,1965,2,3,4,8,1.39).
cancion(416,'nowhere man',41,1965,2,1,3,5,2.05).
cancion(417,'michelle',41,1965,2,4,1,1,4.78).
cancion(418,'paperback writer',41,1966,2,1,5,1,2.32).
cancion(419,'rain',41,1966,2,4,4,7,1.9).
cancion(420,'yellow submarine',41,1966,2,2,2,2,2.44).
cancion(421,'eleanor rigby',41,1966,2,4,5,4,1.02).
cancion(422,'strawberry fields forever',41,1967,2,4,4,7,1).
cancion(423,'penny lane',41,1967,2,4,3,3,5.56).
cancion(424,'all you need is love',41,1967,2,1,3,10,2.57).
cancion(425,'hello, goodbye',41,1967,2,2,3,6,3.94).
cancion(426,'i am the walrus',41,1967,2,3,4,10,4.07).
cancion(427,'lady madonna',41,1968,2,4,5,9,3.98).
cancion(428,'hey jude',41,1968,2,2,3,7,1.43).
cancion(429,'revolution',41,1968,2,3,4,10,3.61).
cancion(430,'while my guitar gently weeps',41,1968,2,4,5,5,5.39).
cancion(431,'ob-la-di, ob-la-da',41,1968,2,2,3,10,2.23).
cancion(432,'blackbird',41,1968,2,3,3,5,4.61).
cancion(433,'helter skelter',41,1968,2,3,3,5,1.28).
cancion(434,'come together',41,1969,2,3,4,2,1.96).
cancion(435,'something',41,1969,2,1,5,8,2).
cancion(436,'let it be',41,1970,2,3,1,5,4.94).
cancion(437,'the long and winding road',41,1970,2,5,1,5,4.26).
cancion(438,'get back',41,1970,2,2,2,1,5.8).
cancion(439,'across the universe',41,1970,2,3,2,10,1.29).
cancion(440,'golden slumbers/carry that weight/the end',41,1969,2,2,1,3,3.77).
cancion(441,'here comes the sun',41,1969,2,3,5,6,3.29).
cancion(442,'octopuss garden',41,1969,2,2,4,3,5.17).
cancion(443,'while my guitar gently weeps',41,1968,2,4,3,7,1.45).
cancion(444,'ballad of john and yoko',41,1969,2,2,3,9,1.53).
cancion(445,'something',41,1969,2,1,4,4,2.98).
cancion(446,'let it be',41,1969,2,2,2,6,3.11).
cancion(447,'because',41,1969,2,2,2,10,1.64).
cancion(448,'oh! darling',41,1969,2,4,5,8,5.16).
cancion(449,'get back',41,1969,2,3,1,6,5.36).
cancion(450,'across the universe',41,1969,2,1,4,7,2.88).
cancion(451,'dig a pony',41,1969,2,4,1,7,5.69).
cancion(452,'dig it',41,1969,2,5,1,9,3.14).
cancion(453,'maggie mae',41,1969,2,4,4,5,3.01).
cancion(454,'two of us',41,1969,2,1,5,6,3.34).
cancion(455,'ive got a feeling',41,1969,2,3,3,6,5.62).
cancion(456,'one after 909',41,1969,2,2,3,1,3.22).
cancion(457,'the long and winding road',41,1969,2,4,4,9,1.64).
cancion(458,'for you blue',41,1970,2,4,1,5,1.85).
cancion(459,'get back',41,1970,2,4,4,7,4.38).
cancion(460,'dont let me down',41,1969,2,3,1,1,5.78).
cancion(461,'i me mine',41,1970,2,3,3,8,4.28).
cancion(462,'the ballad of john and yoko',41,1970,2,3,4,1,3.89).
cancion(463,'old brown shoe',41,1970,2,1,1,2,5.25).
cancion(464,'across the universe',41,1970,2,1,3,6,2.21).
cancion(465,'let it be',41,1970,2,1,5,2,1.51).
cancion(466,'you know my name',41,1970,2,2,5,6,2.82).
cancion(467,'love me do',41,1962,2,2,2,2,4.29).
cancion(468,'from me to you',41,1963,2,2,4,2,1.77).
cancion(469,'thank you girl',41,1963,2,2,1,8,2.83).
cancion(470,'she loves you',41,1963,2,3,2,4,3.04).
cancion(471,'ill get you',41,1963,2,3,2,7,2.68).
cancion(472,'i want to hold your hand',41,1963,2,2,3,6,2.75).
cancion(473,'this boy',41,1963,2,4,1,4,1.16).
cancion(474,'komm, gib mir deine hand',41,1964,2,3,5,8,4.44).
cancion(475,'sie liebt dich',41,1964,2,4,3,5,1.15).
cancion(476,'long tall sally',41,1964,2,3,5,5,1.96).
cancion(477,'i call your name',41,1964,2,3,1,3,2).
cancion(478,'slow down',41,1964,2,4,1,3,2.26).
cancion(479,'matchbox',41,1964,2,2,3,8,2.4).
cancion(480,'i feel fine',41,1964,2,5,1,5,1.36).
cancion(481,'shes a woman',41,1964,2,5,3,10,2.53).
cancion(482,'bad boy',41,1965,2,4,3,4,1.74).
cancion(483,'yes it is',41,1965,2,4,5,7,1.78).
cancion(484,'im down',41,1965,2,3,4,10,1.12).
cancion(485,'day tripper',41,1965,2,5,2,4,2.13).
cancion(486,'we can work it out',41,1965,2,4,5,8,1.17).
cancion(487,'paperback writer',41,1966,2,5,1,6,4.04).
cancion(488,'rain',41,1966,2,4,2,7,2.95).
cancion(489,'rain',41,1966,2,4,1,4,2.97).
cancion(490,'tomorrow never knows',41,1966,2,3,4,7,1.06).
cancion(491,'strawberry fields forever',41,1967,2,4,5,8,5.59).
cancion(492,'penny lane',41,1967,2,2,5,10,3.85).
cancion(493,'only a northern song',41,1969,2,3,1,6,5.26).
cancion(494,'all together now',41,1969,2,3,5,4,3.18).
cancion(495,'hey bulldog',41,1969,2,3,2,2,1.71).
cancion(496,'its all too much',41,1969,2,4,4,1,1.17).
cancion(497,'get back',41,1969,2,2,1,3,1.46).
cancion(498,'dont let me down',41,1969,2,4,1,9,1.9).
cancion(499,'across the universe',41,1969,2,4,3,10,1.16).
cancion(500,'you know my name',41,1969,2,5,2,6,4.94).
cancion(501,'one after 909',41,1969,2,4,5,7,5.1).
cancion(502,'ill keep you satisfied',41,1963,2,4,3,6,2.7).
cancion(503,'i want to hold your hand',41,1964,2,4,5,7,4.66).
cancion(504,'thank you girl',41,1964,2,3,4,1,2.83).
cancion(505,'i call your name',41,1964,2,2,3,10,4.32).
cancion(506,'long tall sally',41,1964,2,4,2,8,3.14).
cancion(507,'you cant do that',41,1964,2,2,3,7,2.58).
cancion(508,'i should have known better',41,1964,2,5,1,2,3.29).
cancion(509,'and i love her',41,1964,2,5,1,2,2).
cancion(510,'tell me why',41,1964,2,4,5,6,3.19).
cancion(511,'if i fell',41,1964,2,5,5,10,4.03).
cancion(512,'im happy just to dance with you',41,1964,2,3,1,9,1.28).
cancion(513,'and i love her',41,1964,2,4,5,1,4.43).
cancion(514,'no reply',41,1964,2,2,3,3,3.96).
cancion(515,'im a loser',41,1964,2,5,1,5,5.15).
cancion(516,'babys in black',41,1964,2,4,1,2,3.37).
cancion(517,'rock and roll music',41,1964,2,4,4,3,4.03).
cancion(518,'ill follow the sun',41,1964,2,5,4,10,4.73).
cancion(519,'mr. moonlight',41,1964,2,1,2,9,5.04).
cancion(520,'every little thing',41,1964,2,3,1,7,1.86).
cancion(521,'i dont want to spoil the party',41,1964,2,3,5,1,2.25).
cancion(522,'what youre doing',41,1964,2,2,3,5,2.11).
cancion(523,'everybodys trying to be my baby',41,1964,2,3,3,9,2.88).
cancion(524,'kansas city/hey, hey, hey, hey!',41,1964,2,2,1,3,3.84).
cancion(525,'eight days a week',41,1964,2,2,3,6,3.05).
cancion(526,'words of love',41,1964,2,5,3,9,2.06).
cancion(527,'honey dont',41,1964,2,4,5,6,5.81).
cancion(528,'every little thing',41,1964,2,4,3,2,2.55).
cancion(529,'i dont want to spoil the party',41,1964,2,4,2,10,4.39).
cancion(530,'what youre doing',41,1964,2,4,1,4,4.49).
cancion(531,'everybodys trying to be my baby',41,1964,2,2,4,5,1.15).
cancion(532,'you like me too much',41,1965,2,4,4,9,2.3).
cancion(533,'tell me what you see',41,1965,2,3,3,8,2.61).
cancion(534,'ive just seen a face',41,1965,2,4,2,9,5.09).
cancion(535,'yesterday',41,1965,2,1,1,4,4.49).
cancion(536,'dizzy miss lizzy',41,1965,2,1,1,7,3.89).
cancion(537,'help!',41,1965,2,4,3,10,4.65).
cancion(538,'the night before',41,1965,2,5,4,9,5.72).
cancion(539,'youve got to hide your love away',41,1965,2,3,4,9,4.73).
cancion(540,'i need you',41,1965,2,4,5,6,4.88).
cancion(541,'another girl',41,1965,2,3,3,2,1.57).
cancion(542,'youre going to lose that girl',41,1965,2,3,5,4,2.72).
cancion(543,'ticket to ride',41,1965,2,1,3,4,2.58).
cancion(544,'act naturally',41,1965,2,1,1,3,3.91).
cancion(545,'its only love',41,1965,2,3,1,5,3.62).
cancion(546,'you like me too much',41,1965,2,5,4,2,4.21).
cancion(547,'no more dream',42,2013,27,1,1,1,4.23).
cancion(548,'we are bulletproof pt.2',42,2013,27,3,1,2,4.75).
cancion(549,'i like it',42,2013,27,2,1,6,1.21).
cancion(550,'n.o',42,2013,27,3,3,6,3.51).
cancion(551,'boy in luv',42,2014,27,3,3,6,2.09).
cancion(552,'just one day',42,2014,27,2,4,1,5.76).
cancion(553,'danger',42,2014,27,3,4,8,4.62).
cancion(554,'war of hormone',42,2014,27,2,1,1,1.07).
cancion(555,'i need u',42,2015,27,4,1,8,3.14).
cancion(556,'dope',42,2015,27,3,3,7,1.21).
cancion(557,'run',42,2015,27,3,1,4,3.98).
cancion(558,'butterfly',42,2015,27,4,2,8,1.97).
cancion(559,'fire',42,2016,27,3,1,2,2.67).
cancion(560,'save me',42,2016,27,3,5,6,4.81).
cancion(561,'blood sweat & tears',42,2016,27,4,4,6,5.13).
cancion(562,'spring day',42,2017,27,3,3,8,3.92).
cancion(563,'not today',42,2017,27,4,5,4,3.7).
cancion(564,'dna',42,2017,27,3,3,3,1.98).
cancion(565,'mic drop',42,2017,27,4,3,5,5.06).
cancion(566,'go go',42,2017,27,4,2,8,1.73).
cancion(567,'anpanman',42,2018,27,4,2,4,1.33).
cancion(568,'fake love',42,2018,27,4,4,10,4.63).
cancion(569,'the truth untold',42,2018,27,2,4,7,3.51).
cancion(570,'idol',42,2018,27,3,4,9,3.85).
cancion(571,'euphoria',42,2018,27,2,3,9,5.42).
cancion(572,'trivia: just dance',42,2018,27,3,4,10,2.98).
cancion(573,'trivia: love',42,2018,27,3,2,6,4.26).
cancion(574,'trivia: seesaw',42,2018,27,3,1,6,1.64).
cancion(575,'epiphany',42,2018,27,5,3,1,5.03).
cancion(576,'singularity',42,2018,27,2,3,3,3.57).
cancion(577,'fake love',42,2018,27,2,5,2,4.04).
cancion(578,'idol',42,2018,27,2,5,8,3.02).
cancion(579,'serendipity',42,2017,27,3,5,5,2.97).
cancion(580,'trivia: love',42,2018,27,3,5,5,2.67).
cancion(581,'airplane pt.2',42,2018,27,4,3,3,5.44).
cancion(582,'the truth untold',42,2018,27,1,5,4,1.98).
cancion(583,'best of me',42,2017,27,2,2,1,5.02).
cancion(584,'let go',42,2018,27,4,4,4,1.56).
cancion(585,'dont leave me',42,2018,27,4,4,10,1.45).
cancion(586,'for you',42,2015,27,3,2,9,1.33).
cancion(587,'black swan',42,2020,27,1,4,9,2.32).
cancion(588,'on',42,2020,27,2,1,10,4.85).
cancion(589,'inner child',42,2020,27,4,1,10,2.78).
cancion(590,'filter',42,2020,27,1,3,9,4.04).
cancion(591,'my time',42,2020,27,4,4,10,2.42).
cancion(592,'louder than bombs',42,2020,27,4,1,5,4.6).
cancion(593,'ugh!',42,2020,27,1,1,6,4.01).
cancion(594,'zero oclock',42,2020,27,2,5,1,1.52).
cancion(595,'friends',42,2020,27,3,4,8,3.41).
cancion(596,'moon',42,2020,27,5,4,10,1.86).
cancion(597,'respect',42,2020,27,3,3,2,3.84).
cancion(598,'we are bulletproof: the eternal',42,2020,27,2,2,5,1.25).
cancion(599,'outro: ego',42,2020,27,2,5,1,4.48).
cancion(600,'make it right',42,2019,27,3,1,10,3).
cancion(601,'jamais vu',42,2019,27,3,5,5,3.47).
cancion(602,'dionysus',42,2019,27,3,3,1,2.32).
cancion(603,'interlude: shadow',42,2020,27,4,5,2,2.62).
cancion(604,'black swan',42,2020,27,3,5,5,5.99).
cancion(605,'stay gold',42,2020,27,2,5,4,2.06).
cancion(606,'your eyes tell',42,2020,27,4,1,7,1.41).
cancion(607,'dynamite',42,2020,27,3,2,3,3.79).
cancion(608,'life goes on',42,2020,27,4,3,5,5.76).
cancion(609,'blue & grey',42,2020,27,3,5,3,3.49).
cancion(610,'skit',42,2020,27,3,3,7,3.7).
cancion(611,'telepathy',42,2020,27,5,1,2,3.23).
cancion(612,'dis-ease',42,2020,27,5,1,8,5.8).
cancion(613,'stay',42,2020,27,4,1,1,4.83).
cancion(614,'fly to my room',42,2020,27,5,1,8,3.4).
cancion(615,'savage love',42,2020,27,3,2,3,4.62).
cancion(616,'butter',42,2021,27,1,4,1,5.1).
cancion(617,'permission to dance',42,2021,27,4,3,4,5.37).
cancion(618,'rappers delight',43,1979,3,1,3,2,3.04).
cancion(619,'the message',44,1982,3,4,4,3,3.54).
cancion(620,'planet rock',45,1982,3,2,3,7,1.45).
cancion(621,'walk this way',46,1986,3,4,4,5,1.21).
cancion(622,'fight the power',47,1989,3,4,3,6,4.99).
cancion(623,'straight outta compton',48,1988,3,4,3,7,4.04).
cancion(624,'parents just dont understand',49,1988,3,1,1,1,4.52).
cancion(625,'mind playing tricks on me',50,1991,3,2,5,2,1.17).
cancion(626,'nuthin but a g thang',51,1992,3,3,2,7,3.46).
cancion(627,'gangstas paradise',52,1995,3,4,1,2,4.02).
cancion(628,'california love',53,1995,3,2,5,1,4.76).
cancion(629,'mo money mo problems',54,1997,3,3,5,9,5.53).
cancion(630,'my name is',55,1999,3,4,4,1,5.79).
cancion(631,'the real slim shady',55,2000,3,2,1,1,3.89).
cancion(632,'ms. jackson',56,2000,3,3,5,1,3.38).
cancion(633,'stan',55,2000,3,3,5,6,4.77).
cancion(634,'hot in herre',57,2002,3,3,3,4,4.65).
cancion(635,'lose yourself',55,2002,3,1,4,4,2.2).
cancion(636,'hey ya!',56,2003,3,3,2,2,5.33).
cancion(637,'gold digger',58,2005,3,5,3,5,4.99).
cancion(638,'crazy in love',59,2003,3,2,3,1,3.48).
cancion(639,'99 problems',60,2003,3,3,3,2,1.81).
cancion(640,'drop it like its hot',61,2004,3,2,1,8,4.05).
cancion(641,'stronger',58,2007,3,3,3,3,2.26).
cancion(642,'empire state of mind',60,2009,3,2,1,4,2.54).
cancion(643,'not afraid',55,2010,3,4,5,3,1.16).
cancion(644,'black and yellow',62,2010,3,2,4,7,5.64).
cancion(645,'run this town',60,2009,3,1,1,7,2.2).
cancion(646,'hotline bling',63,2015,3,2,1,5,2.82).
cancion(647,'uptown funk',64,2014,3,2,2,8,4.95).
cancion(648,'sicko mode',65,2018,3,4,1,1,2.12).
cancion(649,'old town road',66,2019,3,3,2,4,1.89).
cancion(650,'bad and boujee',67,2016,3,1,2,7,5.5).
cancion(651,'humble.',68,2017,3,4,5,6,3.13).
cancion(652,'rockstar',69,2017,3,5,3,1,4.6).
cancion(653,'sicko mode',65,2018,3,4,4,6,4.42).
cancion(654,'hotline bling',63,2015,3,1,3,7,5.58).
cancion(655,'bad guy',70,2019,3,3,2,5,5.28).
cancion(656,'savage',71,2020,3,2,1,7,5.32).
cancion(657,'wap',72,2020,3,4,5,3,3.04).
cancion(658,'life is good',73,2020,3,4,3,1,3.44).
cancion(659,'toosie slide',63,2020,3,4,2,1,4.66).
cancion(660,'good 4 u',74,2021,3,3,4,4,5.24).
cancion(661,'leave the door open',75,2021,3,3,3,9,1.68).
cancion(662,'montero',76,2021,3,3,4,10,5.6).
cancion(663,'industry baby',66,2021,3,1,4,8,4.44).
cancion(664,'essence',77,2020,3,1,2,1,2.38).
cancion(665,'jail',58,2021,3,1,2,9,2.94).
cancion(666,'waves',58,2016,3,2,4,1,5.79).
cancion(667,'highest in the room',65,2019,3,2,2,10,2.12).
cancion(668,'shake it off',78,2014,3,2,2,10,2.98).
cancion(669,'gin and juice',61,1993,3,2,5,5,3.98).
cancion(670,'the way i am',55,2000,3,3,3,2,5.32).
cancion(671,'started from the bottom',63,2013,3,3,4,4,2.97).
cancion(672,'super bass',79,2011,3,2,3,9,5.08).
cancion(673,'stronger',58,2007,3,4,2,9,5.08).
cancion(674,'black and yellow',62,2010,3,3,3,1,1.86).
cancion(675,'see you again',62,2015,3,4,5,5,4.73).
cancion(676,'hotline bling',63,2015,3,3,3,10,2.41).
cancion(677,'mood',80,2020,3,3,3,5,3.25).
cancion(678,'watermelon sugar',81,2020,3,4,3,7,1.67).
cancion(679,'lucid dreams',82,2018,3,2,2,2,2.9).
cancion(680,'faded',83,2015,3,5,3,10,3.99).
cancion(681,'sunflower',69,2018,3,5,3,1,1.01).
cancion(682,'thank u, next',84,2019,3,4,4,2,2.78).
cancion(683,'blinding lights',89,2019,3,4,4,2,5.94).
cancion(684,'yummy',85,2020,3,3,2,9,2.94).
cancion(685,'memories',86,2019,3,5,2,3,2.53).
cancion(686,'circles',69,2019,3,4,4,5,2.38).
cancion(687,'sicko mode',65,2018,3,5,5,2,3.23).
cancion(688,'7 rings',84,2019,3,4,4,10,4.47).
cancion(689,'roxanne',87,2019,3,4,5,8,2.47).
cancion(690,'circles',69,2019,3,3,1,10,1.2).
cancion(691,'mood',80,2020,3,4,1,9,2.4).
cancion(692,'watermelon sugar',81,2020,3,2,2,10,1.33).
cancion(693,'old town road',66,2019,3,3,2,9,5.94).
cancion(694,'stuck with u',84,2020,3,3,4,1,3.36).
cancion(695,'someone you loved',88,2019,3,3,3,10,3.84).
cancion(696,'blinding lights',89,2019,3,4,4,3,4.63).
cancion(697,'dance monkey',90,2019,3,2,4,6,5.23).
cancion(698,'happier',91,2018,3,4,3,3,2.92).
cancion(699,'rockstar',69,2017,3,4,4,8,3.39).
cancion(700,'señorita',92,2018,3,5,5,2,4.45).
cancion(701,'sonata en la menor, h. 562',93,1763,4,4,1,1,2.72).
cancion(702,'concierto para flauta en re mayor, k. 314',94,1778,4,4,1,5,5.22).
cancion(703,'danza de los espíritus bienaventurados de orfeo y eurídice',95,1762,4,4,4,1,2.06).
cancion(704,'concierto en do mayor, rv 443',96,1728,4,3,3,5,1.66).
cancion(705,'stars and stripes forever',97,1896,4,2,3,9,5.35).
cancion(706,'suite de tres piezas, op. 116',98,1890,4,4,2,6,3.95).
cancion(707,'pavane',99,1887,4,2,2,6,3.65).
cancion(708,'andante y rondo, op. 25',100,1857,4,5,4,9,2.61).
cancion(709,'fantasía sobre temas de la traviata',101,1857,4,5,1,10,2.33).
cancion(710,'andante pastoral et scherzettino',102,1908,4,4,5,7,5.96).
cancion(711,'sonata para flauta y piano, op. 52',103,1911,4,5,2,5,2.07).
cancion(712,'syrinx',104,1913,4,3,4,9,3.16).
cancion(713,'acht stücke',105,1927,4,4,1,5,4.36).
cancion(714,'density 21.5',106,1936,4,2,2,6,3.74).
cancion(715,'canzone',107,1977,4,5,1,2,5.71).
cancion(716,'air',108,1995,4,4,5,5,3.62).
cancion(717,'zoom tube',109,1998,4,4,5,4,4.52).
cancion(718,'sounds of the forest',110,1978,4,5,5,6,2.28).
cancion(719,'rapid fire',111,1995,4,1,2,5,1.67).
cancion(720,'piccolodeon polka',112,1993,4,3,4,5,2.09).
cancion(721,'in memoriam',113,2002,4,3,2,3,3.14).
cancion(722,'honami',114,1993,4,2,1,5,3.23).
cancion(723,'the falcons eye',115,2007,4,3,5,8,2.16).
cancion(724,'sonata latino',116,1998,4,2,2,3,3.51).
cancion(725,'murciélago',117,2007,4,2,2,5,4.65).
cancion(726,'rubispheres',118,2008,4,5,5,4,4.5).
cancion(727,'the great train race',109,1993,4,4,1,1,2.21).
cancion(728,'sonata for piccolo and piano',119,2011,4,4,5,6,4.7).
cancion(729,'sea to sea',120,2004,4,4,5,4,2.36).
cancion(730,'sonatine de giverny',121,1996,4,4,1,10,2.84).
cancion(731,'lied',122,1999,4,2,3,9,4.29).
cancion(732,'fish are jumping',123,2003,4,4,4,1,4.04).
cancion(733,'regret',113,1997,4,3,1,4,4.46).
cancion(734,'three piccolo pieces',124,2009,4,4,4,1,5.39).
cancion(735,'capriccio spagnuolo',112,2003,4,1,2,10,2.49).
cancion(736,'blast off!',121,1994,4,1,2,3,4.41).
cancion(737,'raw',125,2000,4,4,2,2,2.62).
cancion(738,'piccolo plus',112,1991,4,5,5,9,4.72).
cancion(739,'lamentation and satire',126,2008,4,3,3,5,5.23).
cancion(740,'sunday solitude',113,1999,4,4,4,10,2.16).
cancion(741,'siete sonidos',127,1999,4,3,2,2,4.79).
cancion(742,'arcana',128,2002,4,3,5,1,4.42).
cancion(743,'oiseaux exotiques',129,1956,4,1,2,9,1.44).
cancion(744,'kopanitza',130,2004,4,1,2,8,3.39).
cancion(745,'ku-ka-ilimoku',131,1991,4,3,2,7,1.24).
cancion(746,'winter spirits',132,1999,4,5,4,1,5.22).
cancion(747,'brio',133,1991,4,1,4,8,3.37).
cancion(748,'laconisme de laile',134,1982,4,3,4,7,4.22).
cancion(749,'chincoteague',130,2000,4,2,1,2,1.64).
cancion(750,'duo ye',135,1995,4,3,2,9,1.87).
cancion(751,'what a wonderful world',136,1967,5,3,4,9,5.54).
cancion(752,'hello, dolly!',136,1964,5,2,4,5,2.16).
cancion(753,'when the saints go marching in',136,1938,5,3,2,6,4.09).
cancion(754,'mack the knife',136,1956,5,2,2,5,5.38).
cancion(755,'blueberry hill',136,1949,5,4,2,2,3.8).
cancion(756,'a kiss to build a dream on',136,1951,5,3,1,2,4.13).
cancion(757,'stardust',136,1931,5,3,5,7,4.11).
cancion(758,'when youre smiling',136,1929,5,4,4,1,3.18).
cancion(759,'georgia on my mind',136,1932,5,3,2,1,2.52).
cancion(760,'dream a little dream of me',136,1931,5,3,5,10,5.49).
cancion(761,'so what',137,1959,5,4,5,2,2.75).
cancion(762,'kind of blue',137,1959,5,3,5,1,4.78).
cancion(763,'all blues',137,1959,5,4,5,5,1.46).
cancion(764,'freddie freeloader',137,1959,5,3,1,7,4.48).
cancion(765,'my funny valentine',137,1956,5,4,5,8,3.44).
cancion(766,'blue in green',137,1959,5,4,3,4,2.57).
cancion(767,'summertime',137,1958,5,4,5,6,2.32).
cancion(768,'milestones',137,1958,5,4,5,8,1.15).
cancion(769,'nardis',137,1958,5,2,5,1,4.99).
cancion(770,'on green dolphin street',137,1958,5,3,5,10,3.13).
cancion(771,'giant steps',138,1959,5,2,3,4,4.56).
cancion(772,'my favorite things',138,1960,5,3,1,4,1.98).
cancion(773,'naima',138,1959,5,3,3,10,1.92).
cancion(774,'a love supreme',138,1964,5,3,1,1,4.39).
cancion(775,'blue train',138,1957,5,5,5,9,4.92).
cancion(776,'acknowledgement',138,1964,5,2,4,8,2.16).
cancion(777,'equinox',138,1960,5,2,4,2,4.24).
cancion(778,'alabama',138,1963,5,2,4,1,1.5).
cancion(779,'central park west',138,1960,5,3,1,1,1.91).
cancion(780,'impressions',138,1961,5,3,2,7,3.59).
cancion(781,'minor swing',139,1937,5,4,1,6,3.83).
cancion(782,'nuages',139,1940,5,1,5,2,5.36).
cancion(783,'djangology',139,1948,5,2,2,7,5.01).
cancion(784,'swing 42',139,1940,5,4,2,3,4.61).
cancion(785,'limehouse blues',139,1935,5,4,2,10,3.06).
cancion(786,'dark eyes',139,1940,5,3,3,3,5.44).
cancion(787,'sweet georgia brown',139,1938,5,1,5,10,2.13).
cancion(788,'coquette',139,1937,5,2,1,10,4.68).
cancion(789,'honeysuckle rose',139,1939,5,4,1,2,3.12).
cancion(790,'belleville',139,1940,5,1,3,8,3.92).
cancion(791,'the windmills of your mind',140,1968,5,4,2,7,2.93).
cancion(792,'i will wait for you',140,1964,5,4,4,7,1.39).
cancion(793,'what are you doing the rest of your life?',140,1969,5,1,5,3,1.03).
cancion(794,'summer of 42',140,1971,5,2,5,9,1.38).
cancion(795,'how do you keep the music playing?',140,1982,5,3,3,6,3.94).
cancion(796,'watch what happens',140,1964,5,5,5,9,4.11).
cancion(797,'papa, can you hear me?',140,1983,5,3,5,9,5.43).
cancion(798,'the summer knows',140,1971,5,2,4,5,1.32).
cancion(799,'his eyes, her eyes',140,1966,5,2,5,4,3.42).
cancion(800,'once upon a summertime',140,1963,5,3,5,10,1.56).
cancion(801,'mambo influenciado',141,1972,5,3,5,2,5.74).
cancion(802,'la comparsa',141,1998,5,3,3,1,4.01).
cancion(803,'claudia',141,1985,5,4,5,1,5.23).
cancion(804,'caridad amaro',141,1972,5,3,2,8,1.17).
cancion(805,'bebo',141,2000,5,2,3,2,1.55).
cancion(806,'zawinuls mambo',141,1996,5,4,4,8,5.83).
cancion(807,'invitación',141,1998,5,3,1,1,5.71).
cancion(808,'son xxi',141,1999,5,4,4,4,3).
cancion(809,'yansa',141,1987,5,3,5,4,3.93).
cancion(810,'lorenas tango',141,2000,5,3,1,5,2.62).
cancion(811,'mozarts adagio',142,1988,5,5,1,9,4.29).
cancion(812,'aires tropicales',142,1994,5,5,3,1,4.85).
cancion(813,'song for maura',142,1993,5,4,4,9,5.92).
cancion(814,'wapango',142,1992,5,5,4,5,2).
cancion(815,'tico tico',142,1994,5,3,5,2,2.3).
cancion(816,'samba for carmen',142,1997,5,1,3,6,2.01).
cancion(817,'the cape verdean blues',142,1996,5,4,3,1,1.06).
cancion(818,'samba soho',142,2002,5,1,2,10,1.19).
cancion(819,'contradanza',142,1990,5,4,5,1,3.58).
cancion(820,'marielas dream',142,1982,5,2,3,1,4.04).
cancion(821,'the thrill is gone',143,1969,6,4,4,5,5.04).
cancion(822,'every day i have the blues',143,1955,6,4,3,4,2.37).
cancion(823,'sweet little angel',143,1956,6,4,5,7,3.71).
cancion(824,'lucille',143,1968,6,1,3,7,1.11).
cancion(825,'rock me baby',143,1964,6,2,4,6,5.04).
cancion(826,'why i sing the blues',143,1969,6,3,5,1,3.4).
cancion(827,'how blue can you get?',143,1964,6,4,3,10,1.18).
cancion(828,'paying the cost to be the boss',143,1968,6,2,3,2,4.32).
cancion(829,'dont answer the door',143,1966,6,3,1,6,3.8).
cancion(830,'caldonia',143,1969,6,4,2,8,3.83).
cancion(831,'hoochie coochie man',144,1954,6,2,3,8,5.48).
cancion(832,'mannish boy',144,1955,6,3,1,2,4.98).
cancion(833,'i just want to make love to you',144,1954,6,3,3,1,4.77).
cancion(834,'rollin stone',144,1950,6,3,3,3,1.54).
cancion(835,'got my mojo working',144,1957,6,1,5,4,5.05).
cancion(836,'i cant be satisfied',144,1948,6,3,3,9,2.24).
cancion(837,'baby please dont go',144,1953,6,5,3,2,1.56).
cancion(838,'she moves me',144,1948,6,2,3,2,4.83).
cancion(839,'long distance call',144,1951,6,3,5,2,2.18).
cancion(840,'im your hoochie coochie man',144,1954,6,2,5,1,3.51).
cancion(841,'cross road blues',145,1936,6,3,1,4,2.71).
cancion(842,'sweet home chicago',145,1936,6,2,2,1,1.5).
cancion(843,'love in vain',145,1937,6,4,4,5,2.04).
cancion(844,'hellhound on my trail',145,1937,6,2,3,4,3.56).
cancion(845,'i believe ill dust my broom',145,1936,6,1,4,8,2.05).
cancion(846,'come on in my kitchen',145,1936,6,2,5,5,3.94).
cancion(847,'ramblin on my mind',145,1936,6,2,3,3,4.08).
cancion(848,'walkin blues',145,1936,6,4,4,8,4.24).
cancion(849,'preachin blues (up jumped the devil)',145,1936,6,3,1,8,5.98).
cancion(850,'stop breakin down blues',145,1937,6,1,1,1,3.84).
cancion(851,'boogie chillen',146,1948,6,4,3,8,3.38).
cancion(852,'im in the mood',146,1951,6,5,1,1,1.71).
cancion(853,'crawlin king snake',146,1949,6,4,1,7,1.08).
cancion(854,'hobo blues',146,1948,6,1,4,1,3.77).
cancion(855,'boom boom',146,1962,6,3,2,6,5.3).
cancion(856,'dimples',146,1956,6,2,2,6,2.42).
cancion(857,'one bourbon, one scotch, one beer',146,1966,6,4,2,6,5.71).
cancion(858,'it serves me right to suffer',146,1966,6,4,5,4,1.77).
cancion(859,'maudie',146,1960,6,4,4,1,5.95).
cancion(860,'big legs, tight skirt',146,1964,6,3,5,1,3.37).
cancion(861,'i walk the line',147,1956,7,3,3,6,4.44).
cancion(862,'folsom prison blues',147,1955,7,3,1,5,5.74).
cancion(863,'ring of fire',147,1963,7,1,1,2,5.34).
cancion(864,'man in black',147,1971,7,1,1,8,1.66).
cancion(865,'get rhythm',147,1956,7,1,1,9,1.34).
cancion(866,'hurt',147,2002,7,2,3,8,1.33).
cancion(867,'a boy named sue',147,1969,7,2,3,2,3.48).
cancion(868,'cry, cry, cry',147,1955,7,2,1,7,2.2).
cancion(869,'sunday morning coming down',147,1970,7,2,2,7,5.03).
cancion(870,'dont take your guns to town',147,1958,7,3,4,10,4.41).
cancion(871,'on the road again',148,1980,7,3,3,7,3.96).
cancion(872,'always on my mind',148,1982,7,2,1,9,4.51).
cancion(873,'blue eyes crying in the rain',148,1975,7,4,1,7,5.01).
cancion(874,'whiskey river',148,1973,7,3,2,7,1.73).
cancion(875,'good hearted woman',148,1975,7,4,2,3,4.37).
cancion(876,'mammas dont let your babies',148,1978,7,3,2,6,2.28).
cancion(877,'georgia on my mind',148,1978,7,3,3,5,3.26).
cancion(878,'to all the girls ive loved before',148,1984,7,4,5,7,4.5).
cancion(879,'angel flying too close to the ground',148,1980,7,2,1,10,3.34).
cancion(880,'my heroes have always been cowboys',148,1980,7,5,2,4,3.76).
cancion(881,'your cheatin heart',149,1953,7,5,2,10,3.68).
cancion(882,'im so lonesome i could cry',149,1949,7,4,5,8,1.17).
cancion(883,'hey, good lookin',149,1951,7,4,4,1,2.82).
cancion(884,'jambalaya',149,1952,7,3,5,6,5.12).
cancion(885,'lovesick blues',149,1949,7,5,3,3,1.76).
cancion(886,'cold, cold heart',149,1951,7,4,3,10,4.44).
cancion(887,'you win again',149,1952,7,5,3,1,2.62).
cancion(888,'move it on over',149,1947,7,4,5,6,5.55).
cancion(889,'honky tonkin',149,1947,7,4,5,8,3.39).
cancion(890,'i cant help it',149,1951,7,3,1,9,2.99).
cancion(891,'windowlicker',150,1999,8,4,1,5,3.23).
cancion(892,'come to daddy',150,1997,8,2,1,6,5.4).
cancion(893,'avril 14th',150,2001,8,3,4,4,4.53).
cancion(894,'on',150,1993,8,3,2,6,3.21).
cancion(895,'selected ambient works 85-92',150,1992,8,3,4,1,4.21).
cancion(896,'alberto balsalm',150,1995,8,4,3,1,5.94).
cancion(897,'xtal',150,1992,8,2,5,3,3.46).
cancion(898,'flim',150,1997,8,4,1,4,4.69).
cancion(899,'rhubarb',150,1994,8,4,2,2,1.8).
cancion(900,'digeridoo',150,1992,8,5,2,6,3.18).
cancion(901,'timestretch',151,2010,8,4,3,9,4.43).
cancion(902,'bass head',151,2010,8,4,3,8,4.75).
cancion(903,'noise',151,2012,8,4,5,2,4.06).
cancion(904,'butterfly',151,2012,8,3,2,1,3.85).
cancion(905,'empathy',151,2011,8,2,2,6,5.35).
cancion(906,'teleport massive',151,2010,8,4,3,7,3.43).
cancion(907,'vava voom',151,2012,8,2,2,6,3.23).
cancion(908,'reaching out',151,2016,8,5,3,1,5.93).
cancion(909,'you & me',151,2014,8,5,1,6,5.02).
cancion(910,'into the sun',151,2015,8,4,3,5,3.56).
cancion(911,'chime',152,1989,8,5,4,8,3.68).
cancion(912,'halcyon',152,1993,8,3,5,8,5.44).
cancion(913,'belfast',152,1991,8,4,4,6,5.92).
cancion(914,'the box',152,1996,8,2,1,9,1.9).
cancion(915,'satan',152,1990,8,5,4,5,1.54).
cancion(916,'impact',152,1992,8,4,1,1,2.65).
cancion(917,'style',152,2001,8,4,1,6,3.63).
cancion(918,'lush 3-1',152,1993,8,5,3,1,1.01).
cancion(919,'doctor?',152,1996,8,1,3,6,2.2).
cancion(920,'beelzedub',152,1993,8,3,2,2,5.28).
cancion(921,'around the world',153,1997,8,3,4,1,3.68).
cancion(922,'one more time',153,2000,8,2,1,9,5.65).
cancion(923,'harder, better, faster, stronger',153,2001,8,3,3,2,5.38).
cancion(924,'digital love',153,2001,8,2,3,9,1.86).
cancion(925,'get lucky',153,2013,8,2,3,2,1.15).
cancion(926,'robot rock',153,2005,8,5,3,8,5.08).
cancion(927,'aerodynamic',153,2001,8,4,1,5,5.08).
cancion(928,'technologic',153,2005,8,4,3,9,5.74).
cancion(929,'instant crush',153,2013,8,4,2,6,2.23).
cancion(930,'da funk',153,1995,8,4,1,5,5.44).
cancion(931,'titanium',154,2011,8,2,1,7,1.95).
cancion(932,'when love takes over',154,2009,8,4,2,1,4.69).
cancion(933,'memories',154,2010,8,3,1,5,3.62).
cancion(934,'without you',154,2011,8,4,4,2,4.19).
cancion(935,'turn me on',154,2011,8,1,4,8,3.19).
cancion(936,'she wolf',154,2012,8,1,1,4,4.65).
cancion(937,'sexy bitc',154,2009,8,4,3,4,4.46).
cancion(938,'bad',154,2014,8,5,4,4,4.42).
cancion(939,'hey mama',154,2014,8,3,1,9,2.37).
cancion(940,'love is gone',154,2007,8,4,3,8,1.44).
cancion(941,'sinfonía no. 5 en do menor, op. 67',155,1808,9,3,3,3,2.16).
cancion(942,'sonata para piano claro de luna',155,1801,9,3,1,8,3.6).
cancion(943,'sinfonía no. 9 en re menor, op. 125',155,1824,9,1,2,3,4.46).
cancion(944,'sonata para piano patética',155,1798,9,1,2,8,4.89).
cancion(945,'concierto para piano no. 5 emperador',155,1811,9,3,5,9,3).
cancion(946,'cuartetos de cuerda op. 18',155,1798,9,5,3,4,1.67).
cancion(947,'missa solemnis, op. 123',155,1819,9,1,4,2,1.85).
cancion(948,'sonata para piano appassionata',155,1806,9,3,4,3,3.67).
cancion(949,'sonata para piano waldstein',155,1804,9,2,5,6,3.05).
cancion(950,'fidelio (ópera)',155,1805,9,3,1,9,2.64).
cancion(951,'sinfonía no. 40 en sol menor, k. 550',94,1788,9,3,4,7,1.47).
cancion(952,'requiem, k. 626',94,1791,9,2,4,9,4.28).
cancion(953,'concierto para piano no. 21, k. 467',94,1785,9,3,3,3,1.99).
cancion(954,'ópera las bodas de fígaro, k. 492',94,1786,9,2,1,7,3.85).
cancion(955,'sinfonía no. 41 júpiter, k. 551',94,1788,9,4,2,5,3.83).
cancion(956,'sonata para piano no. 16, k. 545',94,1788,9,3,2,9,4.07).
cancion(957,'ópera don giovanni, k. 527',94,1787,9,3,5,2,4.74).
cancion(958,'concierto para clarinete, k. 622',94,1791,9,4,3,2,1.9).
cancion(959,'sonata para piano no. 11, k. 331',94,1783,9,3,4,7,5.77).
cancion(960,'ópera la flauta mágica, k. 620',94,1791,9,3,1,8,4.54).
cancion(961,'sinfonía no. 6 patética, op. 74',157,1893,9,4,2,2,4.97).
cancion(962,'el lago de los cisnes, op. 20',157,1875,9,3,2,6,1.82).
cancion(963,'concierto para piano no. 1, op. 23',157,1875,9,4,2,5,1.55).
cancion(964,'sinfonía no. 4, op. 36',157,1877,9,3,2,3,5.88).
cancion(965,'el cascanueces, op. 71',157,1892,9,4,5,5,5.51).
cancion(966,'eugenio oneguin, op. 24 (ópera)',157,1877,9,4,5,4,1.42).
cancion(967,'sinfonía no. 5, op. 64',157,1888,9,4,1,7,3.7).
cancion(968,'serenata para cuerdas, op. 48',157,1880,9,4,2,6,5.16).
cancion(969,'romeo y julieta, th 42',157,1870,9,2,2,1,1.08).
cancion(970,'el sueño de invierno, op. 13',157,1866,9,3,5,3,1.17).
cancion(971,'no woman, no cry',157,1974,10,2,1,10,2.63).
cancion(972,'one love',157,1965,10,3,4,5,5.67).
cancion(973,'redemption song',157,1980,10,3,3,7,2.91).
cancion(974,'i shot the sheriff',157,1973,10,3,1,1,3.27).
cancion(975,'three little birds',157,1980,10,5,1,1,5.33).
cancion(976,'jamming',157,1977,10,2,4,10,3.79).
cancion(977,'buffalo soldier',157,1983,10,2,1,7,1.84).
cancion(978,'is this love',157,1978,10,2,4,7,5.62).
cancion(979,'stir it up',157,1973,10,3,3,9,3.16).
cancion(980,'get up, stand up',157,1973,10,3,5,10,4.25).
cancion(981,'legalize it',158,1976,10,4,3,7,3.77).
cancion(982,'equal rights',158,1977,10,1,2,9,4.95).
cancion(983,'johnny b. goode',158,1983,10,2,5,4,5.95).
cancion(984,'maga dog',158,1976,10,4,3,3,2.9).
cancion(985,'dont look back',158,1978,10,4,4,6,5.9).
cancion(986,'stepping razor',158,1977,10,3,5,10,1.2).
cancion(987,'bush doctor',158,1978,10,1,2,7,1.92).
cancion(988,'african',158,1977,10,2,3,1,2.07).
cancion(989,'mystic man',158,1979,10,4,2,8,3.03).
cancion(990,'i am that i am',158,1977,10,1,1,4,1.4).
cancion(991,'fire in me wire',159,1984,10,4,3,9,3.1).
cancion(992,'calypso queen',159,1972,10,4,1,4,5.37).
cancion(993,'her majesty',159,2017,10,1,3,8,1.69).
cancion(994,'abatina',159,1983,10,2,2,2,2.99).
cancion(995,'gimme more tempo',159,1978,10,3,5,7,2.66).
cancion(996,'far from home',159,2002,10,5,1,6,5.94).
cancion(997,'journey of life',159,1992,10,3,4,10,3.52).
cancion(998,'calypso queen medley',159,1991,10,2,3,8,5.35).
cancion(999,'no madame',159,1993,10,2,1,4,4.17).
cancion(1000,'i thank thee',159,1978,10,3,5,6,2.86).
cancion(1001,'blitzkrieg bop',160,1976,11,3,2,8,5.6).
cancion(1002,'i wanna be sedated',160,1978,11,3,1,3,3.92).
cancion(1003,'rock n roll high school',160,1979,11,4,1,3,3.52).
cancion(1004,'do you remember rock n roll radio?',160,1980,11,3,3,9,1.38).
cancion(1005,'sheena is a punk rocker',160,1977,11,2,1,4,4.03).
cancion(1006,'teenage lobotomy',160,1977,11,4,2,6,2.35).
cancion(1007,'i believe in miracles',160,1989,11,3,2,3,3.18).
cancion(1008,'pet sematary',160,1989,11,4,2,1,4.28).
cancion(1009,'the kkk took my baby away',160,1981,11,3,3,1,5.52).
cancion(1010,'outsider',160,1984,11,3,5,9,5.63).
cancion(1011,'my way',161,1978,11,5,2,7,1.94).
cancion(1012,'something else',161,1978,11,5,2,3,5.19).
cancion(1013,'cmon everybody',161,1979,11,4,2,9,3.57).
cancion(1014,'i wanna be your dog',161,1979,11,5,3,9,4.37).
cancion(1015,'stepping stone',161,1979,11,3,5,9,2.9).
cancion(1016,'search and destroy',161,1979,11,1,5,3,1.03).
cancion(1017,'chinese rocks',161,1979,11,4,1,2,5.22).
cancion(1018,'no lip',161,1979,11,1,1,7,2.74).
cancion(1019,'take a chance',161,1979,11,4,5,4,4.76).
cancion(1020,'born to lose',161,1978,11,2,5,9,3.13).
cancion(1021,'papas got a brand new bag',162,1965,12,4,4,10,3.73).
cancion(1022,'i feel good',162,1965,12,4,2,8,3.65).
cancion(1023,'its a mans mans mans world',162,1966,12,4,1,8,2.79).
cancion(1024,'say it loud – im black and im proud',162,1968,12,1,2,7,2.15).
cancion(1025,'get up',162,1970,12,2,3,4,5.53).
cancion(1026,'super bad',162,1970,12,3,1,1,5.93).
cancion(1027,'the payback',162,1974,12,4,5,6,5.35).
cancion(1028,'get up offa that thing',162,1976,12,2,5,9,3.5).
cancion(1029,'living in america',162,1985,12,3,2,2,5.8).
cancion(1030,'im real',162,1988,12,4,2,3,4.62).
cancion(1031,'purple rain',163,1984,12,2,3,9,1.3).
cancion(1032,'when doves cry',163,1984,12,3,1,5,2.51).
cancion(1033,'kiss',163,1986,12,3,3,7,3.89).
cancion(1034,'1999',163,1982,12,3,5,1,3.6).
cancion(1035,'raspberry beret',163,1985,12,1,1,2,1.73).
cancion(1036,'little red corvette',163,1983,12,3,3,6,1.12).
cancion(1037,'i would die 4 u',163,1984,12,5,2,7,1.16).
cancion(1038,'sign o the times',163,1987,12,2,3,3,2.61).
cancion(1039,'lets go crazy',163,1984,12,3,2,5,5.25).
cancion(1040,'diamonds and pearls',163,1991,12,2,1,5,3.58).
cancion(1041,'hair',164,1979,12,3,4,10,4.11).
cancion(1042,'one in a million you',164,1980,12,2,3,5,4.43).
cancion(1043,'sooner or later',164,1982,12,4,5,6,5.59).
cancion(1044,'just be my lady',164,1981,12,2,4,8,1).
cancion(1045,'the jam',164,1981,12,1,4,4,3.43).
cancion(1046,'when we get married',164,1983,12,2,4,5,3.73).
cancion(1047,'is it love?',164,1982,12,2,1,6,2.28).
cancion(1048,'entangled',164,1983,12,4,3,1,5.41).
cancion(1049,'im sick and tired',164,1983,12,3,5,9,2.64).
cancion(1050,'sneaky freak',164,1983,12,1,3,10,2.77).
cancion(1051,'paranoid',165,1970,13,4,3,5,3.97).
cancion(1052,'iron man',165,1970,13,5,4,9,3.3).
cancion(1053,'war pigs',165,1970,13,4,4,3,4.9).
cancion(1054,'children of the grave',165,1971,13,1,3,2,1.24).
cancion(1055,'n.i.b.',165,1970,13,3,4,1,5.36).
cancion(1056,'sabbath bloody sabbath',165,1973,13,2,4,2,3.43).
cancion(1057,'sweet leaf',165,1971,13,4,1,5,4.62).
cancion(1058,'heaven and hell',165,1980,13,4,2,1,4.5).
cancion(1059,'fairies wear boots',165,1970,13,4,1,7,2).
cancion(1060,'the wizard',165,1970,13,3,2,7,2.47).
cancion(1061,'run to the hills',166,1982,13,3,3,6,4.74).
cancion(1062,'the trooper',166,1983,13,3,2,9,2.19).
cancion(1063,'fear of the dark',166,1992,13,1,4,5,1.21).
cancion(1064,'hallowed be thy name',166,1982,13,1,2,7,1.3).
cancion(1065,'number of the beast',166,1982,13,1,3,8,2.02).
cancion(1066,'wasted years',166,1986,13,2,4,7,1.87).
cancion(1067,'aces high',166,1984,13,2,3,3,3.39).
cancion(1068,'2 minutes to midnight',166,1984,13,2,5,10,1.77).
cancion(1069,'the wicker man',166,2000,13,2,2,2,2.23).
cancion(1070,'wrathchild',166,1981,13,3,5,3,5.98).
cancion(1071,'breaking the law',167,1980,13,3,2,9,3.35).
cancion(1072,'painkiller',167,1990,13,2,5,6,4.91).
cancion(1073,'electric eye',167,1982,13,4,3,10,5.08).
cancion(1074,'youve got another thing comin',167,1982,13,3,2,8,2.59).
cancion(1075,'hell bent for leather',167,1978,13,4,2,1,2.06).
cancion(1076,'living after midnight',167,1980,13,3,2,10,1.4).
cancion(1077,'turbo lover',167,1986,13,3,3,8,2.7).
cancion(1078,'the hellion / electric eye',167,1982,13,4,1,10,2.4).
cancion(1079,'diamonds and rust',167,1975,13,2,3,7,3.67).
cancion(1080,'metal gods',167,1980,13,5,1,1,3.64).
cancion(1081,'enter sandman',168,1991,13,5,4,7,4.11).
cancion(1082,'master of puppets',168,1986,13,4,1,2,2.79).
cancion(1083,'one',168,1988,13,4,5,3,4.33).
cancion(1084,'the unforgiven',168,1991,13,3,4,3,2.6).
cancion(1085,'seek & destroy',168,1983,13,5,2,6,3.56).
cancion(1086,'fade to black',168,1984,13,4,5,5,2.19).
cancion(1087,'sad but true',168,1991,13,5,4,2,5.15).
cancion(1088,'for whom the bell tolls',168,1984,13,4,1,2,1.17).
cancion(1089,'creeping death',168,1984,13,4,3,6,2.58).
cancion(1090,'battery',168,1986,13,3,4,3,1.18).
cancion(1091,'symphony of destruction',169,1992,13,4,3,3,2.08).
cancion(1092,'holy wars... the punishment due',169,1990,13,2,2,4,3.77).
cancion(1093,'peace sells',169,1986,13,3,5,9,4.33).
cancion(1094,'hangar 18',169,1990,13,3,1,7,4.15).
cancion(1095,'sweating bullets',169,1993,13,3,1,9,4.52).
cancion(1096,'a tout le monde',169,1994,13,4,4,8,4.42).
cancion(1097,'in my darkest hour',169,1988,13,2,3,1,2.73).
cancion(1098,'trust',169,1997,13,4,4,8,4.25).
cancion(1099,'tornado of souls',169,1990,13,4,5,4,4.21).
cancion(1100,'mechanix',169,1985,13,5,4,10,2.54).
cancion(1101,'angel of death',170,1986,13,4,4,1,5.04).
cancion(1102,'raining blood',170,1986,13,4,2,10,3.68).
cancion(1103,'south of heaven',170,1988,13,4,2,6,1.49).
cancion(1104,'seasons in the abyss',170,1990,13,3,4,1,3.78).
cancion(1105,'war ensemble',170,1990,13,2,5,6,1.13).
cancion(1106,'dead skin mask',170,1990,13,4,2,2,3.4).
cancion(1107,'black magic',170,1983,13,2,1,3,4.54).
cancion(1108,'chemical warfare',170,1984,13,5,5,9,4.84).
cancion(1109,'hell awaits',170,1985,13,5,3,10,2.69).
cancion(1110,'disciple',170,2001,13,4,3,9,3.3).
cancion(1111,'blowin in the wind',171,1962,14,5,5,2,3.71).
cancion(1112,'the times they are a-changin',171,1964,14,3,3,7,5.3).
cancion(1113,'like a rolling stone',171,1965,14,4,3,2,5.97).
cancion(1114,'mr. tambourine man',171,1965,14,2,5,9,5.39).
cancion(1115,'knockin on heavens door',171,1973,14,5,2,6,4.04).
cancion(1116,'dont think twice, its all right',171,1963,14,4,3,2,5.69).
cancion(1117,'tangled up in blue',171,1975,14,4,1,9,2.62).
cancion(1118,'all along the watchtower',171,1967,14,5,5,5,2.32).
cancion(1119,'forever young',171,1974,14,1,3,5,5.04).
cancion(1120,'a hard rains a-gonna fall',171,1963,14,3,1,6,5.16).
cancion(1121,'this land is your land',172,1944,14,3,1,8,2.22).
cancion(1122,'so long, its been good to know you',172,1935,14,2,3,4,2.82).
cancion(1123,'pretty boy floyd',172,1940,14,3,5,7,2.85).
cancion(1124,'hard, aint it hard',172,1944,14,2,1,7,4.79).
cancion(1125,'deportee',172,1948,14,2,1,7,1.34).
cancion(1126,'pastures of plenty',172,1941,14,5,1,7,2.4).
cancion(1127,'do re mi',172,1940,14,4,4,7,5.68).
cancion(1128,'talkin dust bowl blues',172,1940,14,4,4,9,1.4).
cancion(1129,'i aint got no home',172,1940,14,4,5,9,4.16).
cancion(1130,'tom joad',172,1940,14,4,3,4,2.79).
cancion(1131,'big yellow taxi',173,1970,14,2,2,4,5.56).
cancion(1132,'a case of you',173,1971,14,4,4,4,5.24).
cancion(1133,'both sides, now',173,1969,14,3,5,7,2.86).
cancion(1134,'woodstock',173,1970,14,4,1,5,4.62).
cancion(1135,'river',173,1971,14,1,5,6,4.21).
cancion(1136,'help me',173,1974,14,1,3,6,2.64).
cancion(1137,'california',173,1971,14,4,1,2,4.07).
cancion(1138,'blue',173,1971,14,5,2,6,3.53).
cancion(1139,'free man in paris',173,1974,14,3,4,9,3.48).
cancion(1140,'chelsea morning',173,1969,14,4,3,10,4.69).
cancion(1141,'move on up a little higher',174,1946,15,3,5,10,4.38).
cancion(1142,'how i got over',174,1951,15,3,1,9,1.8).
cancion(1143,'precious lord, take my hand',174,1956,15,1,3,2,3.88).
cancion(1144,'i believe',174,1953,15,1,2,5,2.28).
cancion(1145,'didnt it rain',174,1954,15,3,4,6,1.45).
cancion(1146,'his eye is on the sparrow',174,1958,15,5,3,1,4.15).
cancion(1147,'come sunday',174,1958,15,1,1,3,5.43).
cancion(1148,'joshua fit the battle of jericho',174,1958,15,3,4,10,2.67).
cancion(1149,'go tell it on the mountain',174,1958,15,2,1,2,5.29).
cancion(1150,'take my hand, precious lord',174,1956,15,3,2,1,3.27).
cancion(1151,'why we sing',175,1993,15,3,1,8,1.59).
cancion(1152,'stomp',175,1997,15,2,4,7,3.55).
cancion(1153,'lean on me',175,1998,15,3,1,5,4.07).
cancion(1154,'hosanna',175,2002,15,2,5,5,2.32).
cancion(1155,'i smile',175,2011,15,4,4,8,1.92).
cancion(1156,'love theory',175,2019,15,3,5,2,1.4).
cancion(1157,'wanna be happy?',175,2015,15,3,2,9,5.87).
cancion(1158,'revolution',175,1998,15,4,4,7,1.82).
cancion(1159,'looking for you',175,2002,15,3,5,4,2.9).
cancion(1160,'imagine me',175,2005,15,3,4,5,2.94).
cancion(1161,'la vida es un carnaval',176,1998,17,4,2,8,1.77).
cancion(1162,'quimbara',176,1974,17,3,2,5,4.69).
cancion(1163,'la negra tiene tumbao',176,2001,17,4,5,8,3.71).
cancion(1164,'bemba colorá',176,1950,17,3,4,4,1.24).
cancion(1165,'rie y llora',176,1998,17,4,1,7,5.79).
cancion(1166,'usted abusó',176,1977,17,4,4,1,4.83).
cancion(1167,'la dicha mía',176,1990,17,4,1,3,4.06).
cancion(1168,'yerbero moderno',176,1950,17,4,2,1,2.02).
cancion(1169,'la guarachera',176,1976,17,2,5,6,4.51).
cancion(1170,'toro mata',176,1983,17,3,1,4,3.24).
cancion(1171,'oye como va',177,1963,17,2,2,9,2.85).
cancion(1172,'ran kan kan',177,1950,17,3,1,8,4.8).
cancion(1173,'mambo no. 5',177,1949,17,3,3,2,3.99).
cancion(1174,'para los rumberos',177,1956,17,3,2,6,1.91).
cancion(1175,'el cayuco',177,1952,17,5,3,2,1.76).
cancion(1176,'guararé',177,1960,17,2,5,9,3.99).
cancion(1177,'quimbo quimbumbia',177,1960,17,2,4,10,3).
cancion(1178,'cao cao maní picao',177,1950,17,2,4,1,5.73).
cancion(1179,'el rey del timbal',177,1960,17,3,5,10,4.29).
cancion(1180,'tito on timbales',177,1960,17,3,4,7,4.29).
cancion(1181,'periódico de ayer',178,1979,17,4,3,3,3.83).
cancion(1182,'el cantante',178,1978,17,1,5,1,2.52).
cancion(1183,'aquel lugar',178,1975,17,2,4,7,1.89).
cancion(1184,'aguanilé',178,1978,17,4,2,2,4.01).
cancion(1185,'hacha y machete',178,1975,17,4,4,7,1.61).
cancion(1186,'todo tiene su final',178,1975,17,3,5,4,4.77).
cancion(1187,'periodico de ayer',178,1979,17,1,4,1,4.52).
cancion(1188,'vamos a reir un poco',178,1975,17,2,3,1,5.14).
cancion(1189,'juanito alimaña',178,1972,17,4,2,2,5.28).
cancion(1190,'triste y vacia',178,1975,17,1,3,1,4.7).
cancion(1191,'idilio',179,1983,17,4,4,6,3.16).
cancion(1192,'aquel lugar',179,1981,17,4,2,7,2.13).
cancion(1193,'la murga',179,1969,17,1,3,3,4.05).
cancion(1194,'el gran varón',179,1989,17,2,3,5,3.9).
cancion(1195,'gitana',179,1982,17,3,2,6,3.45).
cancion(1196,'calle luna, calle sol',179,1985,17,5,5,6,1.64).
cancion(1197,'che che cole',179,1972,17,3,5,7,5.31).
cancion(1198,'talento de televisión',179,1989,17,2,5,5,3.4).
cancion(1199,'sin poderte hablar',179,1973,17,2,1,8,3.73).
cancion(1200,'casanova',179,1983,17,3,1,3,4.93).
cancion(1201,'pedro navaja',180,1978,17,3,2,7,3.46).
cancion(1202,'plástico',180,1984,17,3,1,10,2.4).
cancion(1203,'decisiones',180,1984,17,4,1,5,5.2).
cancion(1204,'desapariciones',180,1984,17,3,2,1,5.5).
cancion(1205,'tiburón',180,1978,17,2,5,4,5.29).
cancion(1206,'ligia elena',180,1981,17,4,3,2,3.07).
cancion(1207,'adán garcía',180,1978,17,3,4,1,5.96).
cancion(1208,'maestra vida',180,1980,17,4,2,7,3.54).
cancion(1209,'pablo pueblo',180,1980,17,3,5,6,2.25).
cancion(1210,'dime',180,1983,17,3,3,6,1.44).
cancion(1211,'conciencia',181,1991,17,5,1,9,2.85).
cancion(1212,'que alguien me diga',181,1990,17,5,2,8,5.65).
cancion(1213,'conteo regresivo',181,1999,17,4,1,5,5.4).
cancion(1214,'perdóname',181,1990,17,5,4,8,2.59).
cancion(1215,'vivir sin ella',181,2000,17,3,2,6,4.62).
cancion(1216,'déjate querer',181,1997,17,1,4,8,4.03).
cancion(1217,'amor mío no te vayas',181,1990,17,4,3,7,2.26).
cancion(1218,'déjame sentirte',181,1990,17,1,1,3,5.09).
cancion(1219,'la agarro bajando',181,1992,17,4,4,9,3.52).
cancion(1220,'que manera de quererte',181,1992,17,2,3,9,2.31).
cancion(1221,'la dicha mía',182,1970,17,4,5,10,3).
cancion(1222,'quítate tú',182,1972,17,4,5,10,5.35).
cancion(1223,'celia y tito',182,1974,17,4,2,5,3.37).
cancion(1224,'pacheco y tito',182,1972,17,1,3,6,4.63).
cancion(1225,'acuyuye',182,1987,17,2,4,9,5.97).
cancion(1226,'dulce con dulce',182,1984,17,3,3,7,5.62).
cancion(1227,'cuando tú quieras',182,1970,17,4,5,7,5.96).
cancion(1228,'la rebelión',182,1972,17,2,1,8,5.51).
cancion(1229,'el maestro',182,1974,17,3,1,8,3.16).
cancion(1230,'pacheco y masucci',182,1977,17,4,2,4,4.65).
cancion(1231,'llorarás',183,1978,17,2,5,3,3.01).
cancion(1232,'detalles',183,1983,17,3,4,7,3.46).
cancion(1233,'que bueno baila usted',183,1975,17,3,5,1,3.47).
cancion(1234,'me voy pa cali',183,1975,17,3,2,2,4.01).
cancion(1235,'mata siguaraya',183,1979,17,1,5,9,5.45).
cancion(1236,'llegó la banda',183,1980,17,3,4,10,2.6).
cancion(1237,'ven morena',183,1979,17,5,5,10,3.54).
cancion(1238,'el nazareno',183,1982,17,2,2,9,3.56).
cancion(1239,'la gota fria',183,1985,17,3,3,4,3.03).
cancion(1240,'mi bajo y yo',183,1981,17,2,4,2,4.21).
cancion(1241,'propuesta indecente',185,2013,18,3,5,3,2.38).
cancion(1242,'eres mía',185,2014,18,2,4,8,2.51).
cancion(1243,'odio',185,2014,18,4,1,2,5.87).
cancion(1244,'imitadora',185,2017,18,2,3,9,2.45).
cancion(1245,'bella y sensual',185,2017,18,1,5,1,3.26).
cancion(1246,'sobredosis',185,2018,18,2,3,1,2.46).
cancion(1247,'el favor',185,2019,18,2,4,8,3.19).
cancion(1248,'la mejor versión de mi',185,2019,18,4,3,6,3.46).
cancion(1249,'inmortal',185,2020,18,3,5,5,1.79).
cancion(1250,'héroe favorito',185,2017,18,1,2,6,1.93).
cancion(1251,'ojalá que llueva café',186,1989,18,4,4,3,2.72).
cancion(1252,'burbujas de amor',186,1990,18,5,1,3,4.98).
cancion(1253,'la bilirrubina',186,1988,18,4,5,2,2.9).
cancion(1254,'bachata rosa',186,1990,18,1,2,2,1.48).
cancion(1255,'visa para un sueño',186,1987,18,3,2,4,2.5).
cancion(1256,'a pedir su mano',186,1990,18,2,3,4,5.04).
cancion(1257,'el niagara en bicicleta',186,1992,18,4,5,6,4.93).
cancion(1258,'frío, frío',186,1991,18,4,5,6,1.64).
cancion(1259,'frio frio',186,1991,18,4,1,3,1.76).
cancion(1260,'como abeja al panal',186,1990,18,3,3,2,5.29).
cancion(1261,'voy pa lla',187,1991,18,3,2,1,4.37).
cancion(1262,'por mi timidez',187,1991,18,3,2,7,5.24).
cancion(1263,'ciego de amor',187,1990,18,1,1,5,3.04).
cancion(1264,'pegame tu vicio',187,1992,18,1,5,9,5.54).
cancion(1265,'corazón culpable',187,1993,18,1,5,5,4.33).
cancion(1266,'la parcela',187,1992,18,2,2,8,4.98).
cancion(1267,'creíste',187,1993,18,2,3,8,5.89).
cancion(1268,'vuelve amor',187,1995,18,2,5,9,2.57).
cancion(1269,'ay amor',187,1996,18,2,3,8,2.99).
cancion(1270,'un muerto vivo',187,1996,18,3,1,8,3.19).
cancion(1271,'ojalá',188,1969,19,3,1,7,3.01).
cancion(1272,'la maza',188,1973,19,2,2,5,1.75).
cancion(1273,'el necio',188,1984,19,4,2,1,1.98).
cancion(1274,'fusil contra fusil',188,1967,19,3,5,6,3.36).
cancion(1275,'canción del elegido',188,1969,19,4,5,5,1.69).
cancion(1276,'te doy una canción',188,1969,19,3,3,7,5.47).
cancion(1277,'sueño con serpientes',188,1974,19,3,3,4,3.68).
cancion(1278,'unicornio',188,1982,19,4,4,5,3.14).
cancion(1279,'playa girón',188,1976,19,2,5,7,4.84).
cancion(1280,'la era está pariendo un corazón',188,1972,19,5,3,5,1.95).
cancion(1281,'yolanda',189,1968,19,5,2,10,5.24).
cancion(1282,'para vivir',189,1984,19,4,1,2,4.95).
cancion(1283,'si el poeta eres tú',189,1984,19,4,3,8,4.21).
cancion(1284,'yo pisaré las calles nuevamente',189,1972,19,3,5,5,1.85).
cancion(1285,'de qué callada manera',189,1972,19,5,4,2,5.25).
cancion(1286,'amo esta isla',189,1974,19,4,4,4,3.79).
cancion(1287,'el breve espacio en que no estás',189,1984,19,5,5,5,1.32).
cancion(1288,'tú mi desengaño',189,1975,19,4,4,2,2.93).
cancion(1289,'el primer amor',189,1983,19,4,5,9,1.13).
cancion(1290,'canción por la unidad latinoamericana',189,1970,19,3,5,9,3.9).
cancion(1291,'la pared',190,1980,19,4,5,9,5.82).
cancion(1292,'hermano',190,1971,19,2,4,5,1.62).
cancion(1293,'vivito y coleando',190,1983,19,3,1,1,1.89).
cancion(1294,'aquelarre',190,1975,19,3,2,2,4.46).
cancion(1295,'de espaldas',190,1986,19,3,2,7,4.52).
cancion(1296,'duro, duro',190,1981,19,4,3,1,3.66).
cancion(1297,'para mi corazón basta tu pecho',190,1985,19,2,5,3,5.82).
cancion(1298,'trayectoria',190,1976,19,4,4,10,1.44).
cancion(1299,'pequeña serenata diurna',190,1971,19,4,4,7,3.79).
cancion(1300,'por siempre',190,1980,19,5,4,8,5.46).
cancion(1301,'de otra manera',191,1972,19,4,5,10,5.48).
cancion(1302,'soy niño',191,1968,19,4,1,6,2.13).
cancion(1303,'la tarde se ha puesto triste',191,1972,19,4,2,2,5.99).
cancion(1304,'corazonada',191,1967,19,3,4,8,4.86).
cancion(1305,'romance del campesino',191,1969,19,2,5,1,1.69).
cancion(1306,'la espuma de los días',191,1969,19,4,1,8,4.62).
cancion(1307,'yo soy un hombre sincero',191,1968,19,2,5,3,1.62).
cancion(1308,'a margarita debayle',191,1970,19,5,1,6,4.25).
cancion(1309,'canción a una mujer desnuda',191,1969,19,5,3,4,5.4).
cancion(1310,'al sur de mi vida',191,1970,19,4,4,9,5.51).
cancion(1311,'al alba',192,1975,19,5,5,2,5.09).
cancion(1312,'las cuatro y diez',192,1973,19,3,5,10,2.36).
cancion(1313,'anda',192,1976,19,4,4,5,1.37).
cancion(1314,'sin tu latido',192,1984,19,2,5,9,2.13).
cancion(1315,'rosas en el mar',192,1976,19,5,4,3,3.45).
cancion(1316,'prefiero amar',192,1976,19,4,4,9,4.68).
cancion(1317,'pasaba por aquí',192,1969,19,4,2,8,1.69).
cancion(1318,'una de dos',192,1978,19,5,5,9,1.21).
cancion(1319,'de alguna manera',192,1975,19,1,2,10,4.81).
cancion(1320,'aleluya no. 1',192,1973,19,3,2,3,2.07).
cancion(1321,'solo le pido a dios',193,1985,19,3,1,3,5.25).
cancion(1322,'la memoria',193,2004,19,2,4,10,5.53).
cancion(1323,'los salieris de charly',193,1991,19,3,2,2,1.89).
cancion(1324,'el fantasma de canterville',193,1991,19,2,3,4,3.88).
cancion(1325,'cinco siglos igual',193,1978,19,2,3,4,3).
cancion(1326,'solo le pido a dios',194,1978,19,5,3,4,5.23).
cancion(1327,'gracias a la vida',194,1971,19,4,2,2,5.04).
cancion(1328,'alfonsina y el mar',194,1969,19,4,2,4,2.27).
cancion(1329,'la maza',194,1996,19,4,3,5,3.44).
cancion(1330,'la negra',194,1996,19,4,1,2,4.64).
cancion(1331,'te recuerdo amanda',195,1969,19,2,2,9,4.19).
cancion(1332,'el derecho de vivir en paz',195,1971,19,4,5,7,2.16).
cancion(1333,'la plegaria a un labrador',195,1969,19,3,4,5,5.62).
cancion(1334,'luchín',195,1969,19,4,4,8,1.71).
cancion(1335,'son tus perjúmenes mujer',196,1983,19,1,5,5,3.65).
cancion(1336,'maría de los guardias',196,1979,19,1,3,6,1.37).
cancion(1337,'quincho barrilete',196,1980,19,4,5,4,5.79).
cancion(1338,'dale una luz',196,1984,19,5,2,3,5.09).
cancion(1339,'golondrinas del iguazú',197,1982,19,3,4,7,3.61).
cancion(1340,'terra vermelha',197,1982,19,4,3,3,1.21).
cancion(1341,'pobladora de luz',197,1982,19,3,3,4,5.68).
cancion(1342,'pueblero de allá ité',197,1982,19,3,2,7,2.47).
cancion(1343,'dulce paraguay',197,1982,19,1,2,1,2.45).
cancion(1344,'el río está llamando',197,1973,19,1,2,8,2.66).
cancion(1345,'alborada del viento',197,1973,19,3,3,5,5.77).
cancion(1346,'cacho betún',197,1973,19,5,5,6,4.36).
cancion(1347,'preludio por estefanía',197,1973,19,1,5,10,2.96).
cancion(1348,'quien te amaba ya se va',197,1973,19,3,1,6,4.87).


genero(1,'pop','bailable','alegre').
genero(2,'rock','melodico','euforico').
genero(3,'hip-hop','melodico','euforico').
genero(4,'piccolo','instrumental','ambiental').
genero(5,'jazz','instrumental','melancolico').
genero(6,'blues','instrumental','melancolico').
genero(7,'country','melodico','ambiental').
genero(8,'electronic','melodico','concentracion').
genero(9,'classical','instrumental','concentracion').
genero(10,'reggae','melodico','ambiental').
genero(11,'punk','melodico','euforico').
genero(12,'funk','melodico','ambiental').
genero(13,'metal','melodico','euforico').
genero(14,'folk','bailable','alegre').
genero(15,'gospel','melodico','alegre').
genero(17,'salsa','bailable','melancolico').
genero(18,'bachata','bailable','euforico').
genero(19,'trova','melodico','concentracion').
genero(27,'k-pop','bailable','concentracion').
genero(30,'marimba','instrumental','concentracion').

pais(1,'inglaterra','europa').
pais(2,'eeuu','america').
pais(3,'mexico','america').
pais(4,'italia','europa').
pais(5,'suecia','europa').
pais(6,'francia','europa').
pais(7,'colombia','america').
pais(8,'alemania','europa').
pais(9,'japon','asia').
pais(10,'korea','asia').
pais(11,'finlandia','europa').
pais(12,'noruega','europa').
pais(13,'austria','europa').
pais(14,'china','asia').
pais(15,'cuba','america').
pais(16,'rusia','europa').
pais(17,'jamaica','america').
pais(18,'trinidad y tobago','america').
pais(19,'canada','america').
pais(20,'puerto rico','america').
pais(21,'panama','america').
pais(22,'republica dominicana','america').
pais(23,'venezuela','america').
pais(24,'españa','europa').
pais(25,'argentina','america').
pais(26,'chile','america').
pais(27,'nicaragua','america').

tendencia(1,5,218,263).
tendencia(2,27,105,814).
tendencia(3,23,195,1003).
tendencia(4,23,245,277).
tendencia(5,21,297,1051).
tendencia(6,22,222,650).
tendencia(7,25,55,932).
tendencia(8,8,208,657).
tendencia(9,11,125,193).
tendencia(10,19,227,659).
tendencia(11,18,132,585).
tendencia(12,11,69,216).
tendencia(13,11,179,131).
tendencia(14,15,189,364).
tendencia(15,9,72,370).
tendencia(16,5,62,1098).
tendencia(17,15,184,1277).
tendencia(18,1,116,18).
tendencia(19,6,109,1048).
tendencia(20,1,51,85).
tendencia(21,19,53,1299).
tendencia(22,8,134,626).
tendencia(23,20,64,139).
tendencia(24,27,96,214).
tendencia(25,17,255,604).
tendencia(26,15,180,1005).
tendencia(27,1,84,1110).
tendencia(28,27,194,168).
tendencia(29,20,269,718).
tendencia(30,4,274,405).
tendencia(31,20,113,351).
tendencia(32,9,113,1023).
tendencia(33,27,251,658).
tendencia(34,19,83,133).
tendencia(35,23,260,580).
tendencia(36,23,287,1236).
tendencia(37,21,262,1220).
tendencia(38,9,223,902).
tendencia(39,24,104,1200).
tendencia(40,16,229,1170).
tendencia(41,17,101,1170).
tendencia(42,4,158,97).
tendencia(43,4,182,529).
tendencia(44,21,183,1165).
tendencia(45,17,88,1018).
tendencia(46,25,222,515).
tendencia(47,15,159,956).
tendencia(48,25,161,963).
tendencia(49,24,73,1093).
tendencia(50,8,273,343).
tendencia(51,17,97,1128).
tendencia(52,26,215,581).
tendencia(53,19,248,578).
tendencia(54,7,297,861).
tendencia(55,26,147,737).
tendencia(56,11,172,892).
tendencia(57,25,295,1).
tendencia(58,26,286,169).
tendencia(59,2,85,724).
tendencia(60,17,286,1029).
tendencia(61,22,167,504).
tendencia(62,5,155,1027).
tendencia(63,8,157,397).
tendencia(64,15,212,117).
tendencia(65,17,261,92).
tendencia(66,6,262,340).
tendencia(67,16,176,484).
tendencia(68,12,297,812).
tendencia(69,4,220,1161).
tendencia(70,2,176,631).
tendencia(71,3,284,127).
tendencia(72,3,243,295).
tendencia(73,3,66,1011).
tendencia(74,8,122,934).
tendencia(75,5,174,1139).
tendencia(76,27,117,740).
tendencia(77,14,293,1211).
tendencia(78,3,203,871).
tendencia(79,17,179,123).
tendencia(80,5,254,427).
tendencia(81,4,51,1164).
tendencia(82,12,56,250).
tendencia(83,3,100,1205).
tendencia(84,10,88,828).
tendencia(85,4,267,975).
tendencia(86,11,276,235).
tendencia(87,16,89,698).
tendencia(88,21,231,828).
tendencia(89,24,181,87).
tendencia(90,24,140,554).
tendencia(91,21,146,915).
tendencia(92,20,220,768).
tendencia(93,15,243,919).
tendencia(94,2,155,394).
tendencia(95,25,245,769).
tendencia(96,8,205,594).
tendencia(97,7,217,290).
tendencia(98,23,295,204).
tendencia(99,9,109,763).
tendencia(100,18,58,864).
tendencia(101,16,137,1052).
tendencia(102,3,91,590).
tendencia(103,10,86,1090).
tendencia(104,21,53,744).
tendencia(105,23,282,582).
tendencia(106,25,71,1262).
tendencia(107,22,247,120).
tendencia(108,14,223,1101).
tendencia(109,19,101,1194).
tendencia(110,8,111,805).
tendencia(111,4,213,528).
tendencia(112,25,119,765).
tendencia(113,2,238,1311).
tendencia(114,19,191,1330).
tendencia(115,9,90,788).
tendencia(116,4,117,544).
tendencia(117,19,276,199).
tendencia(118,2,83,66).
tendencia(119,24,82,1059).
tendencia(120,3,112,282).
tendencia(121,24,207,505).
tendencia(122,20,121,214).
tendencia(123,19,139,154).
tendencia(124,3,238,630).
tendencia(125,21,106,273).
tendencia(126,16,155,513).
tendencia(127,18,218,1289).
tendencia(128,6,77,287).
tendencia(129,17,160,11).
tendencia(130,8,239,1140).
tendencia(131,20,75,996).
tendencia(132,7,180,841).
tendencia(133,17,103,1109).
tendencia(134,21,112,85).
tendencia(135,25,284,264).
tendencia(136,9,266,541).
tendencia(137,14,125,882).
tendencia(138,26,259,1231).
tendencia(139,3,86,351).
tendencia(140,16,224,1221).
tendencia(141,16,241,899).
tendencia(142,8,291,316).
tendencia(143,21,193,24).
tendencia(144,20,168,82).
tendencia(145,16,81,1130).
tendencia(146,4,50,763).
tendencia(147,5,227,873).
tendencia(148,15,90,670).
tendencia(149,27,158,1113).
tendencia(150,18,245,1129).
tendencia(151,5,107,506).
tendencia(152,1,239,1343).
tendencia(153,5,281,290).
tendencia(154,4,59,1263).
tendencia(155,26,127,1328).
tendencia(156,24,59,343).
tendencia(157,1,196,270).
tendencia(158,21,115,1217).
tendencia(159,17,52,507).
tendencia(160,24,296,490).
tendencia(161,16,244,436).
tendencia(162,21,225,996).
tendencia(163,11,293,1220).
tendencia(164,9,137,301).
tendencia(165,14,128,994).
tendencia(166,25,208,925).
tendencia(167,21,82,251).
tendencia(168,23,183,140).
tendencia(169,11,290,388).
tendencia(170,14,171,305).
tendencia(171,13,245,423).
tendencia(172,5,120,37).
tendencia(173,16,226,151).
tendencia(174,10,273,1250).
tendencia(175,10,66,1021).
tendencia(176,2,170,1295).
tendencia(177,16,224,1267).
tendencia(178,6,300,987).
tendencia(179,3,176,1321).
tendencia(180,22,274,434).
tendencia(181,3,209,537).
tendencia(182,19,66,1151).
tendencia(183,22,105,685).
tendencia(184,9,203,189).
tendencia(185,4,92,314).
tendencia(186,1,270,1271).
tendencia(187,15,104,36).
tendencia(188,24,193,204).
tendencia(189,21,84,982).
tendencia(190,19,186,550).
tendencia(191,10,235,1118).
tendencia(192,6,141,607).
tendencia(193,16,142,457).
tendencia(194,4,285,33).
tendencia(195,3,101,1266).
tendencia(196,18,83,1214).
tendencia(197,25,254,1225).
tendencia(198,8,174,250).
tendencia(199,27,80,18).
tendencia(200,3,223,802).
tendencia(201,4,258,1049).
tendencia(202,8,216,453).
tendencia(203,1,121,351).
tendencia(204,19,149,161).
tendencia(205,21,233,1017).
tendencia(206,17,67,901).
tendencia(207,13,62,411).
tendencia(208,15,131,914).
tendencia(209,1,262,165).
tendencia(210,9,159,1202).
tendencia(211,14,108,1124).
tendencia(212,20,61,48).
tendencia(213,10,214,193).
tendencia(214,4,145,820).
tendencia(215,27,179,446).
tendencia(216,18,140,550).
tendencia(217,15,78,307).
tendencia(218,12,161,603).
tendencia(219,14,185,599).
tendencia(220,27,53,940).
tendencia(221,3,277,299).
tendencia(222,8,124,154).
tendencia(223,23,252,285).
tendencia(224,9,286,37).
tendencia(225,12,214,337).
tendencia(226,2,299,368).
tendencia(227,7,109,545).
tendencia(228,22,156,1059).
tendencia(229,24,117,194).
tendencia(230,6,178,1061).
tendencia(231,20,140,548).
tendencia(232,27,186,976).
tendencia(233,17,129,524).
tendencia(234,21,128,439).
tendencia(235,25,218,340).
tendencia(236,26,257,679).
tendencia(237,7,182,435).
tendencia(238,22,257,122).
tendencia(239,3,197,143).
tendencia(240,14,185,407).
tendencia(241,9,133,1021).
tendencia(242,13,289,1089).
tendencia(243,18,159,284).
tendencia(244,22,197,328).
tendencia(245,21,229,1206).
tendencia(246,5,247,1203).
tendencia(247,8,64,1286).
tendencia(248,26,273,493).
tendencia(249,1,229,606).
tendencia(250,15,65,356).
tendencia(251,13,286,746).
tendencia(252,7,258,643).
tendencia(253,1,75,1039).
tendencia(254,18,148,394).
tendencia(255,1,232,333).
tendencia(256,12,290,1042).
tendencia(257,12,67,1237).
tendencia(258,5,170,720).
tendencia(259,18,91,53).
tendencia(260,15,246,656).
tendencia(261,16,296,330).
tendencia(262,16,299,1261).
tendencia(263,11,145,766).
tendencia(264,5,264,64).
tendencia(265,5,94,683).
tendencia(266,7,110,759).
tendencia(267,20,207,910).
tendencia(268,16,271,955).
tendencia(269,14,174,986).
tendencia(270,23,179,673).
tendencia(271,11,238,1018).
tendencia(272,21,154,552).
tendencia(273,16,68,309).
tendencia(274,22,101,814).
tendencia(275,25,73,973).
tendencia(276,5,84,531).
tendencia(277,6,261,789).
tendencia(278,15,261,1247).
tendencia(279,11,162,250).
tendencia(280,21,97,457).
tendencia(281,4,165,172).
tendencia(282,3,75,1097).
tendencia(283,23,59,1253).
tendencia(284,3,160,809).
tendencia(285,18,176,504).
tendencia(286,21,283,415).
tendencia(287,21,71,882).
tendencia(288,18,209,1339).
tendencia(289,23,219,993).
tendencia(290,3,254,1184).
tendencia(291,1,171,1152).
tendencia(292,2,144,404).
tendencia(293,10,67,509).
tendencia(294,17,71,701).
tendencia(295,5,259,904).
tendencia(296,6,158,979).
tendencia(297,9,296,9).
tendencia(298,23,150,1209).
tendencia(299,15,293,784).
tendencia(300,18,50,1048).
tendencia(301,26,105,359).
tendencia(302,18,275,842).
tendencia(303,6,99,419).
tendencia(304,25,236,581).
tendencia(305,9,230,470).
tendencia(306,10,266,681).
tendencia(307,2,271,1325).
tendencia(308,24,101,1030).
tendencia(309,22,162,791).
tendencia(310,10,101,1299).
tendencia(311,5,88,489).
tendencia(312,16,76,1228).
tendencia(313,14,92,1154).
tendencia(314,25,288,57).
tendencia(315,5,70,1183).
tendencia(316,4,141,581).
tendencia(317,15,177,568).
tendencia(318,1,261,698).
tendencia(319,11,210,790).
tendencia(320,21,189,391).
tendencia(321,11,192,274).
tendencia(322,22,96,1044).
tendencia(323,21,60,1144).
tendencia(324,5,65,1099).
tendencia(325,21,185,97).
tendencia(326,25,295,844).
tendencia(327,24,204,32).
tendencia(328,3,209,397).
tendencia(329,14,56,479).
tendencia(330,15,146,412).
tendencia(331,26,87,729).
tendencia(332,8,226,907).
tendencia(333,14,227,892).
tendencia(334,15,118,253).
tendencia(335,15,92,854).
tendencia(336,6,211,565).
tendencia(337,27,197,1017).
tendencia(338,13,65,831).
tendencia(339,2,279,466).
tendencia(340,3,127,947).
tendencia(341,23,167,1214).
tendencia(342,23,114,1323).
tendencia(343,20,186,806).
tendencia(344,13,252,346).
tendencia(345,5,140,738).
tendencia(346,2,148,660).
tendencia(347,13,127,183).
tendencia(348,21,117,1295).
tendencia(349,9,73,1182).
tendencia(350,13,297,274).
tendencia(351,7,186,563).
tendencia(352,11,287,470).
tendencia(353,18,86,939).
tendencia(354,15,143,900).
tendencia(355,23,234,752).
tendencia(356,11,263,435).
tendencia(357,5,150,1298).
tendencia(358,1,205,263).
tendencia(359,6,111,1119).
tendencia(360,5,69,568).
tendencia(361,4,144,114).
tendencia(362,18,267,133).
tendencia(363,14,201,27).
tendencia(364,14,179,899).
tendencia(365,14,106,954).
tendencia(366,20,178,415).
tendencia(367,7,291,346).
tendencia(368,20,294,593).
tendencia(369,14,249,86).
tendencia(370,3,293,890).
tendencia(371,6,281,895).
tendencia(372,3,227,30).
tendencia(373,6,117,736).
tendencia(374,4,184,597).
tendencia(375,10,245,926).
tendencia(376,23,171,779).
tendencia(377,10,195,388).
tendencia(378,13,284,1007).
tendencia(379,20,83,889).
tendencia(380,9,55,828).
tendencia(381,15,59,779).
tendencia(382,26,223,993).
tendencia(383,27,89,58).
tendencia(384,2,279,1170).
tendencia(385,5,231,43).
tendencia(386,22,159,809).
tendencia(387,12,73,700).
tendencia(388,26,108,1131).
tendencia(389,18,205,1344).
tendencia(390,11,246,1013).
tendencia(391,20,87,969).
tendencia(392,13,70,907).
tendencia(393,23,126,601).
tendencia(394,10,277,1283).
tendencia(395,20,290,412).
tendencia(396,27,227,515).
tendencia(397,5,54,258).
tendencia(398,18,157,602).
tendencia(399,2,245,7).
tendencia(400,20,248,512).
tendencia(401,5,94,431).
tendencia(402,11,114,824).
tendencia(403,15,62,1090).
tendencia(404,24,191,239).
tendencia(405,18,294,557).
tendencia(406,20,121,157).
tendencia(407,16,225,296).
tendencia(408,25,259,1011).
tendencia(409,3,79,833).
tendencia(410,17,158,251).
tendencia(411,14,207,675).
tendencia(412,6,153,170).
tendencia(413,15,243,874).
tendencia(414,27,274,1242).
tendencia(415,7,111,47).
tendencia(416,9,285,1266).
tendencia(417,5,250,369).
tendencia(418,1,108,162).
tendencia(419,5,76,297).
tendencia(420,17,157,281).
tendencia(421,5,176,109).
tendencia(422,21,162,314).
tendencia(423,4,232,507).
tendencia(424,11,91,1187).
tendencia(425,10,174,906).
tendencia(426,2,128,96).
tendencia(427,16,96,408).
tendencia(428,25,286,1002).
tendencia(429,22,245,1096).
tendencia(430,4,127,442).
tendencia(431,10,74,20).
tendencia(432,12,120,906).
tendencia(433,16,211,296).
tendencia(434,12,124,641).
tendencia(435,21,192,1315).
tendencia(436,18,144,331).
tendencia(437,24,267,1290).
tendencia(438,9,129,1003).
tendencia(439,9,188,1339).
tendencia(440,18,98,1227).
tendencia(441,12,66,772).
tendencia(442,1,97,923).
tendencia(443,9,237,676).
tendencia(444,18,238,2).
tendencia(445,27,165,9).
tendencia(446,20,273,414).
tendencia(447,2,102,544).
tendencia(448,6,180,1016).
tendencia(449,22,223,521).
tendencia(450,23,176,1338).
tendencia(451,22,284,1330).
tendencia(452,1,99,962).
tendencia(453,4,231,1297).
tendencia(454,12,64,272).
tendencia(455,3,95,636).
tendencia(456,5,264,1015).
tendencia(457,27,133,729).
tendencia(458,6,295,636).
tendencia(459,2,195,62).
tendencia(460,21,143,158).
tendencia(461,12,169,1122).
tendencia(462,7,67,198).
tendencia(463,20,250,596).
tendencia(464,27,114,910).
tendencia(465,22,200,934).
tendencia(466,11,157,866).
tendencia(467,12,199,78).
tendencia(468,7,76,229).
tendencia(469,3,72,1307).
tendencia(470,5,143,328).
tendencia(471,18,275,357).
tendencia(472,14,188,232).
tendencia(473,7,254,1083).
tendencia(474,20,181,555).
tendencia(475,21,136,478).
tendencia(476,5,266,582).
tendencia(477,16,66,1139).
tendencia(478,4,154,836).
tendencia(479,3,269,136).
tendencia(480,21,184,645).
tendencia(481,23,82,30).
tendencia(482,8,74,822).
tendencia(483,3,254,293).
tendencia(484,20,96,966).
tendencia(485,1,292,1299).
tendencia(486,8,273,74).
tendencia(487,5,144,529).
tendencia(488,5,83,22).
tendencia(489,26,240,1347).
tendencia(490,12,103,882).
tendencia(491,27,111,881).
tendencia(492,11,162,290).
tendencia(493,12,151,1324).
tendencia(494,20,215,130).
tendencia(495,18,133,579).
tendencia(496,5,211,1249).
tendencia(497,4,285,629).
tendencia(498,12,101,1292).
tendencia(499,7,142,1188).
tendencia(500,8,155,958).
tendencia(501,6,79,362).
tendencia(502,10,243,1083).
tendencia(503,7,210,1282).
tendencia(504,17,225,742).
tendencia(505,26,196,1330).
tendencia(506,22,233,1044).
tendencia(507,14,294,145).
tendencia(508,6,154,508).
tendencia(509,5,104,704).
tendencia(510,17,89,1059).
tendencia(511,13,167,816).
tendencia(512,23,290,656).
tendencia(513,16,242,150).
tendencia(514,2,117,598).
tendencia(515,24,141,1296).
tendencia(516,25,255,1010).
tendencia(517,21,211,348).
tendencia(518,3,154,160).
tendencia(519,13,245,853).
tendencia(520,22,268,1130).
tendencia(521,5,235,214).
tendencia(522,9,144,777).
tendencia(523,13,201,409).
tendencia(524,24,80,980).
tendencia(525,14,99,239).
tendencia(526,15,203,873).
tendencia(527,5,261,629).
tendencia(528,3,242,207).
tendencia(529,5,235,261).
tendencia(530,8,281,605).
tendencia(531,20,260,371).
tendencia(532,8,120,1184).
tendencia(533,27,92,658).
tendencia(534,7,146,1256).
tendencia(535,26,105,955).
tendencia(536,18,119,402).
tendencia(537,11,196,1342).
tendencia(538,25,135,623).
tendencia(539,17,264,600).
tendencia(540,9,275,231).
tendencia(541,18,200,92).
tendencia(542,20,80,119).
tendencia(543,4,223,450).
tendencia(544,7,260,82).
tendencia(545,25,71,984).
tendencia(546,8,296,1062).
tendencia(547,5,275,1263).
tendencia(548,22,223,37).
tendencia(549,11,134,114).
tendencia(550,21,137,819).
tendencia(551,18,100,838).
tendencia(552,23,223,1221).
tendencia(553,19,87,643).
tendencia(554,8,70,1183).
tendencia(555,22,221,1197).
tendencia(556,16,109,288).
tendencia(557,27,161,1156).
tendencia(558,4,183,470).
tendencia(559,22,151,199).
tendencia(560,12,93,618).
tendencia(561,3,104,505).
tendencia(562,13,206,323).
tendencia(563,5,289,656).
tendencia(564,6,256,775).
tendencia(565,21,191,964).
tendencia(566,20,126,592).
tendencia(567,27,299,1232).
tendencia(568,18,286,486).
tendencia(569,15,291,1177).
tendencia(570,21,188,802).
tendencia(571,18,239,578).
tendencia(572,17,129,572).
tendencia(573,27,165,285).
tendencia(574,8,210,498).
tendencia(575,22,128,951).
tendencia(576,19,278,1042).
tendencia(577,7,275,124).
tendencia(578,18,95,298).
tendencia(579,6,111,1052).
tendencia(580,1,158,719).
tendencia(581,26,64,958).
tendencia(582,22,173,691).
tendencia(583,16,197,495).
tendencia(584,14,167,382).
tendencia(585,9,227,292).
tendencia(586,23,261,1124).
tendencia(587,12,141,728).
tendencia(588,6,114,818).
tendencia(589,4,215,351).
tendencia(590,2,267,1160).
tendencia(591,25,183,1099).
tendencia(592,16,162,442).
tendencia(593,8,51,517).
tendencia(594,26,236,379).
tendencia(595,10,55,73).
tendencia(596,24,61,1203).
tendencia(597,14,212,403).
tendencia(598,26,217,1213).
tendencia(599,10,207,441).
tendencia(600,8,210,1144).
tendencia(601,10,148,948).
tendencia(602,10,67,565).
tendencia(603,25,267,494).
tendencia(604,26,181,410).
tendencia(605,10,222,1029).
tendencia(606,22,149,1179).
tendencia(607,22,168,281).
tendencia(608,11,214,1270).
tendencia(609,2,238,486).
tendencia(610,3,58,471).
tendencia(611,22,271,1185).
tendencia(612,7,58,15).
tendencia(613,24,283,860).
tendencia(614,12,53,27).
tendencia(615,20,81,735).
tendencia(616,11,256,1316).
tendencia(617,24,65,977).
tendencia(618,20,159,904).
tendencia(619,1,217,928).
tendencia(620,1,228,159).
tendencia(621,10,231,1296).
tendencia(622,25,215,189).
tendencia(623,15,186,1212).
tendencia(624,10,109,629).
tendencia(625,23,186,435).
tendencia(626,3,298,35).
tendencia(627,1,157,294).
tendencia(628,17,186,320).
tendencia(629,26,160,1238).
tendencia(630,15,173,129).
tendencia(631,18,153,968).
tendencia(632,11,299,527).
tendencia(633,23,216,379).
tendencia(634,2,74,1103).
tendencia(635,12,72,1134).
tendencia(636,3,134,550).
tendencia(637,2,78,405).
tendencia(638,10,91,780).
tendencia(639,9,217,292).
tendencia(640,10,178,42).
tendencia(641,13,206,58).
tendencia(642,1,153,352).
tendencia(643,17,134,476).
tendencia(644,11,169,679).
tendencia(645,24,123,1069).
tendencia(646,9,54,877).
tendencia(647,15,232,109).
tendencia(648,21,184,708).
tendencia(649,16,100,558).
tendencia(650,18,193,1254).
tendencia(651,23,98,531).
tendencia(652,25,95,997).
tendencia(653,14,291,658).
tendencia(654,17,180,285).
tendencia(655,10,205,351).
tendencia(656,4,293,15).
tendencia(657,26,180,236).
tendencia(658,14,182,722).
tendencia(659,11,207,402).
tendencia(660,9,287,773).
tendencia(661,6,86,485).
tendencia(662,22,272,422).
tendencia(663,26,79,580).
tendencia(664,21,215,413).
tendencia(665,24,163,1322).
tendencia(666,22,107,1097).
tendencia(667,8,261,1041).
tendencia(668,23,260,1033).
tendencia(669,11,134,862).
tendencia(670,8,175,905).
tendencia(671,24,262,1323).
tendencia(672,15,130,607).
tendencia(673,22,200,1188).
tendencia(674,5,93,628).
tendencia(675,2,106,481).
tendencia(676,8,267,765).
tendencia(677,9,241,1326).
tendencia(678,22,288,455).
tendencia(679,26,112,133).
tendencia(680,12,183,529).
tendencia(681,22,250,21).
tendencia(682,6,60,607).
tendencia(683,3,77,1264).
tendencia(684,1,184,422).
tendencia(685,12,259,1051).
tendencia(686,18,217,1066).
tendencia(687,18,269,756).
tendencia(688,27,152,692).
tendencia(689,20,260,937).
tendencia(690,15,56,655).
tendencia(691,18,140,354).
tendencia(692,3,89,1242).
tendencia(693,8,203,125).
tendencia(694,6,62,765).
tendencia(695,17,174,950).
tendencia(696,1,92,524).
tendencia(697,25,50,283).
tendencia(698,18,259,191).
tendencia(699,10,155,1208).
tendencia(700,21,68,138).
tendencia(701,10,226,1192).
tendencia(702,1,237,489).
tendencia(703,27,94,213).
tendencia(704,8,191,1328).
tendencia(705,17,225,72).
tendencia(706,19,265,577).
tendencia(707,14,258,422).
tendencia(708,17,292,303).
tendencia(709,8,99,1070).
tendencia(710,16,289,1336).
tendencia(711,13,165,1064).
tendencia(712,8,202,693).
tendencia(713,3,103,144).
tendencia(714,2,152,183).
tendencia(715,18,297,1310).
tendencia(716,16,59,7).
tendencia(717,24,129,891).
tendencia(718,17,170,1043).
tendencia(719,10,64,559).
tendencia(720,6,288,397).
tendencia(721,16,292,1222).
tendencia(722,17,189,404).
tendencia(723,15,125,1012).
tendencia(724,23,289,105).
tendencia(725,19,197,541).
tendencia(726,9,158,1226).
tendencia(727,22,195,1293).
tendencia(728,15,162,35).
tendencia(729,10,166,428).
tendencia(730,8,87,7).
tendencia(731,20,162,213).
tendencia(732,12,212,1012).
tendencia(733,20,251,1229).
tendencia(734,21,186,278).
tendencia(735,10,250,173).
tendencia(736,19,260,1303).
tendencia(737,25,265,276).
tendencia(738,21,217,685).
tendencia(739,25,136,1314).
tendencia(740,16,89,487).
tendencia(741,10,87,1013).
tendencia(742,1,91,877).
tendencia(743,3,85,415).
tendencia(744,24,115,1334).
tendencia(745,24,127,1330).
tendencia(746,23,169,380).
tendencia(747,8,249,1091).
tendencia(748,8,170,644).
tendencia(749,22,237,1331).
tendencia(750,15,228,702).
tendencia(751,6,110,684).
tendencia(752,3,149,589).
tendencia(753,13,296,626).
tendencia(754,26,93,1251).
tendencia(755,19,187,1225).
tendencia(756,1,177,1059).
tendencia(757,25,79,328).
tendencia(758,19,294,215).
tendencia(759,16,93,151).
tendencia(760,26,161,318).
tendencia(761,22,120,170).
tendencia(762,7,248,1187).
tendencia(763,13,189,631).
tendencia(764,23,131,1044).
tendencia(765,2,134,653).
tendencia(766,24,232,501).
tendencia(767,5,124,203).
tendencia(768,4,208,264).
tendencia(769,26,105,962).
tendencia(770,25,211,606).
tendencia(771,18,202,1340).
tendencia(772,16,294,1103).
tendencia(773,4,214,1193).
tendencia(774,19,227,1229).
tendencia(775,26,98,392).
tendencia(776,11,170,383).
tendencia(777,24,219,914).
tendencia(778,24,84,979).
tendencia(779,27,120,804).
tendencia(780,9,112,1088).
tendencia(781,8,62,571).
tendencia(782,3,288,335).
tendencia(783,4,110,114).
tendencia(784,11,195,494).
tendencia(785,8,188,1059).
tendencia(786,5,263,1044).
tendencia(787,18,158,537).
tendencia(788,19,266,158).
tendencia(789,11,85,388).
tendencia(790,17,297,855).
tendencia(791,9,115,702).
tendencia(792,15,290,1231).
tendencia(793,24,239,869).
tendencia(794,6,83,1182).
tendencia(795,12,77,89).
tendencia(796,20,201,459).
tendencia(797,1,53,1265).
tendencia(798,26,173,293).
tendencia(799,13,281,247).
tendencia(800,18,228,16).
tendencia(801,24,259,460).
tendencia(802,3,60,1197).
tendencia(803,1,219,858).
tendencia(804,21,254,1267).
tendencia(805,19,100,935).
tendencia(806,23,63,595).
tendencia(807,7,227,67).
tendencia(808,19,195,89).
tendencia(809,25,79,1231).
tendencia(810,2,207,694).
tendencia(811,13,172,1109).
tendencia(812,22,91,941).
tendencia(813,19,61,354).
tendencia(814,27,144,935).
tendencia(815,12,237,230).
tendencia(816,3,290,443).
tendencia(817,2,137,512).
tendencia(818,16,61,623).
tendencia(819,2,282,1118).
tendencia(820,15,139,1287).
tendencia(821,15,75,412).
tendencia(822,1,185,49).
tendencia(823,17,102,435).
tendencia(824,8,152,736).
tendencia(825,26,107,527).
tendencia(826,26,270,778).
tendencia(827,11,195,1056).
tendencia(828,17,252,1303).
tendencia(829,11,227,754).
tendencia(830,6,169,551).
tendencia(831,3,124,344).
tendencia(832,26,132,865).
tendencia(833,18,74,381).
tendencia(834,22,282,724).
tendencia(835,4,94,532).
tendencia(836,8,226,733).
tendencia(837,17,293,294).
tendencia(838,17,258,1088).
tendencia(839,14,67,266).
tendencia(840,10,292,1110).
tendencia(841,2,296,1047).
tendencia(842,7,255,44).
tendencia(843,9,135,1048).
tendencia(844,19,287,365).
tendencia(845,5,75,923).
tendencia(846,10,196,412).
tendencia(847,6,86,303).
tendencia(848,23,154,994).
tendencia(849,11,266,174).
tendencia(850,15,240,63).
tendencia(851,18,154,949).
tendencia(852,7,184,364).
tendencia(853,25,169,831).
tendencia(854,12,226,609).
tendencia(855,16,79,1149).
tendencia(856,24,171,707).
tendencia(857,22,215,1248).
tendencia(858,22,210,218).
tendencia(859,5,119,855).
tendencia(860,3,204,44).
tendencia(861,16,224,293).
tendencia(862,11,112,1090).
tendencia(863,15,283,543).
tendencia(864,15,162,1054).
tendencia(865,5,253,973).
tendencia(866,19,271,81).
tendencia(867,2,81,1344).
tendencia(868,12,67,365).
tendencia(869,14,183,881).
tendencia(870,21,190,865).
tendencia(871,19,185,824).
tendencia(872,16,117,785).
tendencia(873,14,196,781).
tendencia(874,15,232,648).
tendencia(875,21,151,539).
tendencia(876,16,213,772).
tendencia(877,23,197,66).
tendencia(878,8,146,257).
tendencia(879,16,284,1148).
tendencia(880,16,227,813).
tendencia(881,25,269,342).
tendencia(882,2,183,1085).
tendencia(883,24,221,54).
tendencia(884,17,285,38).
tendencia(885,27,110,695).
tendencia(886,24,108,684).
tendencia(887,26,227,552).
tendencia(888,14,233,48).
tendencia(889,20,73,1030).
tendencia(890,21,113,832).
tendencia(891,19,110,843).
tendencia(892,3,268,742).
tendencia(893,1,176,510).
tendencia(894,10,93,716).
tendencia(895,8,194,313).
tendencia(896,6,167,1156).
tendencia(897,2,119,955).
tendencia(898,22,286,757).
tendencia(899,9,244,197).
tendencia(900,10,208,378).
tendencia(901,16,100,501).
tendencia(902,26,151,823).
tendencia(903,11,148,714).
tendencia(904,8,252,849).
tendencia(905,9,175,1010).
tendencia(906,1,114,1263).
tendencia(907,5,243,448).
tendencia(908,17,191,1195).
tendencia(909,21,73,449).
tendencia(910,15,280,711).
tendencia(911,7,186,262).
tendencia(912,21,67,516).
tendencia(913,22,229,160).
tendencia(914,26,128,629).
tendencia(915,2,262,1314).
tendencia(916,18,133,812).
tendencia(917,14,50,1136).
tendencia(918,18,215,117).
tendencia(919,1,84,1003).
tendencia(920,23,142,125).
tendencia(921,22,156,47).
tendencia(922,13,195,90).
tendencia(923,19,104,833).
tendencia(924,12,281,37).
tendencia(925,24,157,286).
tendencia(926,18,263,71).
tendencia(927,25,90,461).
tendencia(928,17,110,1184).
tendencia(929,6,288,1311).
tendencia(930,2,74,1234).
tendencia(931,20,191,161).
tendencia(932,26,279,1210).
tendencia(933,2,87,968).
tendencia(934,24,71,682).
tendencia(935,7,204,797).
tendencia(936,22,55,907).
tendencia(937,6,167,404).
tendencia(938,21,267,1085).
tendencia(939,18,288,563).
tendencia(940,6,117,1047).
tendencia(941,14,220,351).
tendencia(942,11,276,329).
tendencia(943,15,268,652).
tendencia(944,17,197,524).
tendencia(945,9,55,481).
tendencia(946,26,205,1286).
tendencia(947,27,99,1219).
tendencia(948,10,144,996).
tendencia(949,16,98,653).
tendencia(950,6,287,708).
tendencia(951,10,295,944).
tendencia(952,25,125,664).
tendencia(953,11,287,878).
tendencia(954,16,80,18).
tendencia(955,5,94,361).
tendencia(956,26,197,790).
tendencia(957,25,57,921).
tendencia(958,16,195,1226).
tendencia(959,11,72,1254).
tendencia(960,20,55,328).
tendencia(961,18,120,1229).
tendencia(962,16,76,321).
tendencia(963,4,194,600).
tendencia(964,16,294,390).
tendencia(965,16,141,172).
tendencia(966,18,60,682).
tendencia(967,11,122,306).
tendencia(968,23,132,650).
tendencia(969,26,213,875).
tendencia(970,9,191,264).
tendencia(971,24,86,819).
tendencia(972,10,58,486).
tendencia(973,3,273,270).
tendencia(974,10,59,561).
tendencia(975,17,77,676).
tendencia(976,24,223,1037).
tendencia(977,13,117,211).
tendencia(978,3,271,274).
tendencia(979,1,124,2).
tendencia(980,3,72,142).
tendencia(981,16,80,329).
tendencia(982,7,103,570).
tendencia(983,1,236,188).
tendencia(984,27,229,1314).
tendencia(985,5,281,970).
tendencia(986,11,251,751).
tendencia(987,24,273,514).
tendencia(988,12,177,646).
tendencia(989,12,67,190).
tendencia(990,19,231,34).
tendencia(991,16,144,1150).
tendencia(992,1,262,856).
tendencia(993,11,86,349).
tendencia(994,19,123,425).
tendencia(995,2,239,574).
tendencia(996,7,267,264).
tendencia(997,14,170,676).
tendencia(998,13,146,163).
tendencia(999,22,111,484).
tendencia(1000,10,296,1016).
tendencia(1001,16,242,559).
tendencia(1002,6,57,137).
tendencia(1003,5,255,780).
tendencia(1004,7,75,558).
tendencia(1005,22,284,724).
tendencia(1006,7,282,688).
tendencia(1007,7,118,1124).
tendencia(1008,15,255,122).
tendencia(1009,9,169,295).
tendencia(1010,18,68,1014).
tendencia(1011,11,211,922).
tendencia(1012,19,144,794).
tendencia(1013,14,133,1188).
tendencia(1014,19,71,1153).
tendencia(1015,14,252,769).
tendencia(1016,1,187,120).
tendencia(1017,23,224,327).
tendencia(1018,15,183,597).
tendencia(1019,19,127,93).
tendencia(1020,18,143,400).
tendencia(1021,13,231,272).
tendencia(1022,23,188,778).
tendencia(1023,12,111,543).
tendencia(1024,12,73,689).
tendencia(1025,7,76,2).
tendencia(1026,12,262,533).
tendencia(1027,22,68,639).
tendencia(1028,23,69,538).
tendencia(1029,24,51,403).
tendencia(1030,27,97,166).
tendencia(1031,10,122,322).
tendencia(1032,14,248,216).
tendencia(1033,27,67,108).
tendencia(1034,26,113,514).
tendencia(1035,11,226,358).
tendencia(1036,20,261,939).
tendencia(1037,26,70,349).
tendencia(1038,17,121,315).
tendencia(1039,1,252,864).
tendencia(1040,26,286,8).
tendencia(1041,26,167,889).
tendencia(1042,1,172,909).
tendencia(1043,8,73,54).
tendencia(1044,23,177,834).
tendencia(1045,15,70,827).
tendencia(1046,7,138,224).
tendencia(1047,21,92,475).
tendencia(1048,21,235,1041).
tendencia(1049,9,205,307).
tendencia(1050,5,113,935).
tendencia(1051,17,117,205).
tendencia(1052,10,55,715).
tendencia(1053,7,77,959).
tendencia(1054,17,290,1075).
tendencia(1055,9,191,747).
tendencia(1056,2,118,159).
tendencia(1057,11,129,565).
tendencia(1058,27,64,787).
tendencia(1059,25,98,524).
tendencia(1060,2,206,442).
tendencia(1061,11,59,1269).
tendencia(1062,7,118,985).
tendencia(1063,20,236,264).
tendencia(1064,6,91,87).
tendencia(1065,24,290,1057).
tendencia(1066,18,99,1153).
tendencia(1067,13,132,324).
tendencia(1068,21,159,555).
tendencia(1069,24,201,114).
tendencia(1070,2,144,1027).
tendencia(1071,3,235,420).
tendencia(1072,12,81,670).
tendencia(1073,23,127,227).
tendencia(1074,19,187,728).
tendencia(1075,10,78,539).
tendencia(1076,14,197,1327).
tendencia(1077,4,154,994).
tendencia(1078,23,228,372).
tendencia(1079,2,218,688).
tendencia(1080,19,73,423).
tendencia(1081,14,162,1170).
tendencia(1082,1,188,386).
tendencia(1083,19,133,740).
tendencia(1084,18,286,1301).
tendencia(1085,11,87,5).
tendencia(1086,4,232,504).
tendencia(1087,15,122,445).
tendencia(1088,12,267,1269).
tendencia(1089,22,154,384).
tendencia(1090,12,284,731).
tendencia(1091,16,245,882).
tendencia(1092,27,138,657).
tendencia(1093,7,166,704).
tendencia(1094,22,198,1318).
tendencia(1095,13,235,817).
tendencia(1096,21,160,46).
tendencia(1097,20,120,1234).
tendencia(1098,13,135,375).
tendencia(1099,9,213,1124).
tendencia(1100,1,194,807).
tendencia(1101,15,142,1292).
tendencia(1102,18,296,127).
tendencia(1103,17,227,959).
tendencia(1104,21,228,998).
tendencia(1105,15,239,1157).
tendencia(1106,22,80,283).
tendencia(1107,26,126,483).
tendencia(1108,15,177,1013).
tendencia(1109,24,129,976).
tendencia(1110,22,261,57).
tendencia(1111,10,248,969).
tendencia(1112,7,138,808).
tendencia(1113,5,217,413).
tendencia(1114,16,132,743).
tendencia(1115,4,82,928).
tendencia(1116,4,147,1042).
tendencia(1117,19,80,285).
tendencia(1118,3,197,153).
tendencia(1119,18,79,310).
tendencia(1120,8,234,71).
tendencia(1121,6,217,873).
tendencia(1122,6,190,378).
tendencia(1123,14,68,1318).
tendencia(1124,23,175,1061).
tendencia(1125,2,128,763).
tendencia(1126,5,262,646).
tendencia(1127,12,197,1162).
tendencia(1128,23,175,254).
tendencia(1129,15,121,595).
tendencia(1130,21,300,556).
tendencia(1131,26,292,989).
tendencia(1132,17,74,163).
tendencia(1133,7,134,940).
tendencia(1134,22,232,1020).
tendencia(1135,18,281,1116).
tendencia(1136,21,84,794).
tendencia(1137,5,128,884).
tendencia(1138,17,219,307).
tendencia(1139,8,68,16).
tendencia(1140,22,51,671).
tendencia(1141,2,129,804).
tendencia(1142,5,53,30).
tendencia(1143,20,198,1180).
tendencia(1144,11,105,589).
tendencia(1145,14,251,248).
tendencia(1146,17,194,237).
tendencia(1147,8,83,580).
tendencia(1148,12,287,948).
tendencia(1149,24,159,1132).
tendencia(1150,14,136,520).
tendencia(1151,22,297,438).
tendencia(1152,10,171,1025).
tendencia(1153,8,195,115).
tendencia(1154,3,252,969).
tendencia(1155,1,191,775).
tendencia(1156,2,256,21).
tendencia(1157,3,119,368).
tendencia(1158,13,240,143).
tendencia(1159,2,265,241).
tendencia(1160,25,275,74).
tendencia(1161,4,75,975).
tendencia(1162,10,115,737).
tendencia(1163,10,263,873).
tendencia(1164,21,102,426).
tendencia(1165,4,241,1261).
tendencia(1166,24,122,477).
tendencia(1167,10,108,865).
tendencia(1168,26,269,327).
tendencia(1169,21,98,316).
tendencia(1170,5,124,529).
tendencia(1171,25,272,1005).
tendencia(1172,10,84,235).
tendencia(1173,16,152,948).
tendencia(1174,25,260,223).
tendencia(1175,15,271,987).
tendencia(1176,3,136,815).
tendencia(1177,11,130,354).
tendencia(1178,25,118,1242).
tendencia(1179,17,187,224).
tendencia(1180,19,236,107).
tendencia(1181,20,130,1007).
tendencia(1182,1,218,1020).
tendencia(1183,1,119,357).
tendencia(1184,4,72,8).
tendencia(1185,4,204,486).
tendencia(1186,12,194,181).
tendencia(1187,27,209,904).
tendencia(1188,4,193,954).
tendencia(1189,19,200,627).
tendencia(1190,24,59,1309).
tendencia(1191,12,152,992).
tendencia(1192,10,218,118).
tendencia(1193,21,235,1030).
tendencia(1194,6,206,203).
tendencia(1195,10,169,496).
tendencia(1196,6,68,165).
tendencia(1197,6,198,252).
tendencia(1198,5,215,818).
tendencia(1199,14,225,867).
tendencia(1200,11,58,683).
tendencia(1201,21,138,359).
tendencia(1202,13,191,379).
tendencia(1203,24,235,695).
tendencia(1204,21,281,1093).
tendencia(1205,14,136,352).
tendencia(1206,1,68,706).
tendencia(1207,23,179,531).
tendencia(1208,20,76,992).
tendencia(1209,14,164,1244).
tendencia(1210,11,245,35).
tendencia(1211,26,141,554).
tendencia(1212,2,271,1123).
tendencia(1213,2,131,1118).
tendencia(1214,8,235,222).
tendencia(1215,13,228,1213).
tendencia(1216,16,223,50).
tendencia(1217,15,83,318).
tendencia(1218,10,51,65).
tendencia(1219,19,145,138).
tendencia(1220,16,150,511).
tendencia(1221,17,110,1003).
tendencia(1222,20,203,582).
tendencia(1223,27,166,240).
tendencia(1224,27,237,346).
tendencia(1225,9,197,777).
tendencia(1226,13,98,1154).
tendencia(1227,23,242,661).
tendencia(1228,19,211,245).
tendencia(1229,8,70,211).
tendencia(1230,10,132,1154).
tendencia(1231,20,78,213).
tendencia(1232,13,96,1137).
tendencia(1233,25,171,322).
tendencia(1234,5,288,351).
tendencia(1235,17,146,11).
tendencia(1236,22,92,1112).
tendencia(1237,15,160,229).
tendencia(1238,5,76,88).
tendencia(1239,16,257,136).
tendencia(1240,2,209,834).
tendencia(1241,9,255,75).
tendencia(1242,17,196,1047).
tendencia(1243,17,206,738).
tendencia(1244,12,135,1335).
tendencia(1245,12,73,895).
tendencia(1246,13,207,891).
tendencia(1247,26,74,695).
tendencia(1248,12,275,421).
tendencia(1249,13,289,284).
tendencia(1250,27,260,281).
tendencia(1251,13,247,975).
tendencia(1252,27,276,577).
tendencia(1253,5,253,576).
tendencia(1254,7,101,327).
tendencia(1255,18,265,210).
tendencia(1256,24,198,447).
tendencia(1257,8,54,670).
tendencia(1258,3,172,1030).
tendencia(1259,4,270,578).
tendencia(1260,18,130,47).
tendencia(1261,20,150,609).
tendencia(1262,1,74,914).
tendencia(1263,24,173,333).
tendencia(1264,12,259,69).
tendencia(1265,19,291,664).
tendencia(1266,26,107,1274).
tendencia(1267,2,78,1074).
tendencia(1268,14,131,191).
tendencia(1269,18,152,749).
tendencia(1270,11,217,883).
tendencia(1271,13,129,276).
tendencia(1272,7,255,1292).
tendencia(1273,7,234,37).
tendencia(1274,1,149,1196).
tendencia(1275,5,222,367).
tendencia(1276,4,212,792).
tendencia(1277,7,66,1318).
tendencia(1278,21,252,1281).
tendencia(1279,13,135,546).
tendencia(1280,13,207,930).
tendencia(1281,16,123,799).
tendencia(1282,2,242,359).
tendencia(1283,16,197,1211).
tendencia(1284,7,203,908).
tendencia(1285,7,209,1043).
tendencia(1286,5,289,188).
tendencia(1287,22,137,516).
tendencia(1288,23,217,396).
tendencia(1289,25,284,1310).
tendencia(1290,13,297,1120).
tendencia(1291,17,98,1112).
tendencia(1292,9,147,1055).
tendencia(1293,13,184,590).
tendencia(1294,14,144,590).
tendencia(1295,15,155,773).
tendencia(1296,4,164,527).
tendencia(1297,2,281,1225).
tendencia(1298,18,189,906).
tendencia(1299,14,237,62).
tendencia(1300,8,69,428).
tendencia(1301,6,125,1225).
tendencia(1302,5,199,188).
tendencia(1303,7,113,136).
tendencia(1304,17,129,1301).
tendencia(1305,18,95,554).
tendencia(1306,16,234,1246).
tendencia(1307,22,136,243).
tendencia(1308,20,113,487).
tendencia(1309,26,110,1266).
tendencia(1310,13,100,992).
tendencia(1311,19,217,910).
tendencia(1312,16,163,188).
tendencia(1313,5,159,612).
tendencia(1314,24,240,132).
tendencia(1315,18,232,261).
tendencia(1316,6,236,206).
tendencia(1317,10,73,889).
tendencia(1318,14,201,145).
tendencia(1319,3,222,696).
tendencia(1320,1,300,244).
tendencia(1321,2,61,651).
tendencia(1322,10,270,347).
tendencia(1323,19,257,985).
tendencia(1324,18,126,1235).
tendencia(1325,22,150,1043).
tendencia(1326,7,212,277).
tendencia(1327,27,208,590).
tendencia(1328,27,58,1220).
tendencia(1329,15,58,532).
tendencia(1330,6,134,560).
tendencia(1331,8,104,810).
tendencia(1332,5,122,524).
tendencia(1333,14,118,403).
tendencia(1334,27,188,694).
tendencia(1335,18,237,439).
tendencia(1336,14,195,464).
tendencia(1337,15,130,812).
tendencia(1338,22,200,1245).
tendencia(1339,20,224,672).
tendencia(1340,26,158,104).
tendencia(1341,6,119,671).
tendencia(1342,1,116,802).
tendencia(1343,1,124,399).
tendencia(1344,1,183,322).
tendencia(1345,14,190,1136).
tendencia(1346,20,78,1223).
tendencia(1347,9,115,624).
tendencia(1348,27,122,595).
tendencia(1349,10,198,170).
tendencia(1350,25,134,1280).
tendencia(1351,2,271,1004).
tendencia(1352,23,93,313).
tendencia(1353,5,108,295).
tendencia(1354,26,296,1292).
tendencia(1355,17,132,473).
tendencia(1356,26,65,594).
tendencia(1357,11,150,1265).
tendencia(1358,8,221,1222).
tendencia(1359,13,94,219).
tendencia(1360,3,112,341).
tendencia(1361,8,242,272).
tendencia(1362,13,118,164).
tendencia(1363,27,175,23).
tendencia(1364,16,232,925).
tendencia(1365,6,263,700).
tendencia(1366,14,196,53).
tendencia(1367,9,97,570).
tendencia(1368,23,288,176).
tendencia(1369,3,109,971).
tendencia(1370,1,164,1315).
tendencia(1371,10,226,1096).
tendencia(1372,18,79,54).
tendencia(1373,20,254,558).
tendencia(1374,27,75,1221).
tendencia(1375,17,75,1152).
tendencia(1376,18,158,1127).
tendencia(1377,20,212,314).
tendencia(1378,13,288,811).
tendencia(1379,8,140,361).
tendencia(1380,17,203,290).
tendencia(1381,11,251,917).
tendencia(1382,26,166,866).
tendencia(1383,22,275,177).
tendencia(1384,15,118,1116).
tendencia(1385,22,299,105).
tendencia(1386,24,260,1188).
tendencia(1387,9,182,108).
tendencia(1388,26,54,946).
tendencia(1389,17,61,781).
tendencia(1390,13,98,1198).
tendencia(1391,2,84,800).
tendencia(1392,11,108,523).
tendencia(1393,23,50,153).
tendencia(1394,10,62,1170).
tendencia(1395,4,165,519).
tendencia(1396,1,130,1314).
tendencia(1397,2,75,700).
tendencia(1398,11,149,889).
tendencia(1399,15,101,207).
tendencia(1400,14,80,981).
tendencia(1401,13,133,1095).
tendencia(1402,5,207,700).
tendencia(1403,7,144,1252).
tendencia(1404,18,133,93).
tendencia(1405,16,70,391).
tendencia(1406,27,151,232).
tendencia(1407,15,108,337).
tendencia(1408,7,52,153).
tendencia(1409,15,138,742).
tendencia(1410,3,258,46).
tendencia(1411,3,228,1304).
tendencia(1412,24,174,469).
tendencia(1413,2,271,315).
tendencia(1414,2,103,686).
tendencia(1415,2,191,601).
tendencia(1416,21,98,294).
tendencia(1417,1,151,434).
tendencia(1418,14,222,164).
tendencia(1419,2,249,104).
tendencia(1420,10,215,871).
tendencia(1421,14,206,475).
tendencia(1422,3,228,823).
tendencia(1423,17,129,467).
tendencia(1424,18,279,818).
tendencia(1425,19,236,720).
tendencia(1426,17,84,184).
tendencia(1427,4,139,1066).
tendencia(1428,15,70,578).
tendencia(1429,6,209,367).
tendencia(1430,5,267,1329).
tendencia(1431,8,227,1306).
tendencia(1432,15,194,832).
tendencia(1433,4,172,1041).
tendencia(1434,5,290,1103).
tendencia(1435,8,285,390).
tendencia(1436,22,290,145).
tendencia(1437,21,103,1119).
tendencia(1438,7,235,562).
tendencia(1439,16,223,666).
tendencia(1440,13,78,1311).
tendencia(1441,21,59,868).
tendencia(1442,24,216,374).
tendencia(1443,6,194,649).
tendencia(1444,14,88,118).
tendencia(1445,22,100,1239).
tendencia(1446,16,105,320).
tendencia(1447,3,295,455).
tendencia(1448,3,101,587).
tendencia(1449,17,61,1284).
tendencia(1450,14,101,686).
tendencia(1451,7,192,924).
tendencia(1452,16,227,902).
tendencia(1453,27,252,922).
tendencia(1454,13,200,1167).
tendencia(1455,24,101,584).
tendencia(1456,21,109,148).
tendencia(1457,18,265,802).
tendencia(1458,18,190,403).
tendencia(1459,9,235,594).
tendencia(1460,20,237,467).
tendencia(1461,25,85,954).
tendencia(1462,6,94,748).
tendencia(1463,16,291,1129).
tendencia(1464,24,257,1297).
tendencia(1465,17,94,940).
tendencia(1466,3,154,235).
tendencia(1467,25,85,18).
tendencia(1468,27,105,40).
tendencia(1469,12,212,1153).
tendencia(1470,10,166,507).
tendencia(1471,17,119,836).
tendencia(1472,15,167,189).
tendencia(1473,13,186,489).
tendencia(1474,7,234,462).
tendencia(1475,27,229,431).
tendencia(1476,22,209,534).
tendencia(1477,26,117,610).
tendencia(1478,11,132,1181).
tendencia(1479,22,55,1245).
tendencia(1480,15,54,291).
tendencia(1481,25,215,836).
tendencia(1482,3,151,743).
tendencia(1483,20,167,1048).
tendencia(1484,2,86,1159).
tendencia(1485,16,152,932).
tendencia(1486,18,198,1138).
tendencia(1487,12,226,309).
tendencia(1488,15,190,106).
tendencia(1489,4,53,224).
tendencia(1490,8,100,455).
tendencia(1491,4,118,1183).
tendencia(1492,2,203,709).
tendencia(1493,26,154,615).
tendencia(1494,3,122,997).
tendencia(1495,1,224,1155).
tendencia(1496,20,157,549).
tendencia(1497,15,110,815).
tendencia(1498,13,184,793).
tendencia(1499,11,222,981).
tendencia(1500,2,81,1059).
tendencia(1501,12,151,400).
tendencia(1502,6,52,472).
tendencia(1503,8,261,714).
tendencia(1504,26,244,505).
tendencia(1505,3,182,53).
tendencia(1506,17,288,772).
tendencia(1507,25,254,550).
tendencia(1508,2,129,802).
tendencia(1509,11,249,879).
tendencia(1510,27,68,90).
tendencia(1511,6,121,1204).
tendencia(1512,24,165,631).
tendencia(1513,12,179,463).
tendencia(1514,22,247,286).
tendencia(1515,4,280,382).
tendencia(1516,8,300,1088).
tendencia(1517,8,89,602).
tendencia(1518,23,278,462).
tendencia(1519,4,193,1215).
tendencia(1520,26,242,814).
tendencia(1521,1,55,113).
tendencia(1522,7,289,771).
tendencia(1523,24,57,1300).
tendencia(1524,22,78,868).
tendencia(1525,17,181,773).
tendencia(1526,2,124,1220).
tendencia(1527,4,231,226).
tendencia(1528,22,149,742).
tendencia(1529,10,63,722).
tendencia(1530,18,84,1206).
tendencia(1531,17,58,600).
tendencia(1532,1,279,308).
tendencia(1533,20,180,523).
tendencia(1534,4,94,1096).
tendencia(1535,9,56,172).
tendencia(1536,26,235,241).
tendencia(1537,13,141,130).
tendencia(1538,3,164,215).
tendencia(1539,6,62,348).
tendencia(1540,5,89,692).
tendencia(1541,25,160,966).
tendencia(1542,9,95,127).
tendencia(1543,1,196,813).
tendencia(1544,7,242,1288).
tendencia(1545,10,225,928).
tendencia(1546,13,76,806).
tendencia(1547,23,188,599).
tendencia(1548,22,283,65).
tendencia(1549,27,203,1098).
tendencia(1550,22,142,1078).
tendencia(1551,18,133,1055).
tendencia(1552,18,242,1116).
tendencia(1553,6,182,189).
tendencia(1554,18,251,361).
tendencia(1555,23,176,855).
tendencia(1556,11,272,681).
tendencia(1557,26,276,59).
tendencia(1558,26,65,825).
tendencia(1559,2,108,375).
tendencia(1560,21,73,851).
tendencia(1561,8,78,365).
tendencia(1562,16,135,301).
tendencia(1563,1,136,572).
tendencia(1564,15,161,746).
tendencia(1565,16,76,1014).
tendencia(1566,12,224,486).
tendencia(1567,15,296,675).
tendencia(1568,2,211,265).
tendencia(1569,9,155,736).
tendencia(1570,5,288,50).
tendencia(1571,16,94,546).
tendencia(1572,6,218,944).
tendencia(1573,6,187,1109).
tendencia(1574,20,246,1227).
tendencia(1575,8,282,363).
tendencia(1576,14,240,670).
tendencia(1577,18,74,621).
tendencia(1578,13,199,1326).
tendencia(1579,13,290,85).
tendencia(1580,11,164,181).
tendencia(1581,20,70,1).
tendencia(1582,2,149,820).
tendencia(1583,6,58,466).
tendencia(1584,17,278,481).
tendencia(1585,25,131,158).
tendencia(1586,22,68,94).
tendencia(1587,17,114,958).
tendencia(1588,12,183,1123).
tendencia(1589,25,289,489).
tendencia(1590,3,214,940).
tendencia(1591,15,85,386).
tendencia(1592,5,226,303).
tendencia(1593,25,85,205).
tendencia(1594,19,52,1034).
tendencia(1595,15,134,1147).
tendencia(1596,21,283,554).
tendencia(1597,2,78,201).
tendencia(1598,5,191,1146).
tendencia(1599,7,258,1239).
tendencia(1600,6,256,497).
tendencia(1601,20,151,679).
tendencia(1602,6,274,145).
tendencia(1603,14,243,823).
tendencia(1604,13,257,940).
tendencia(1605,27,173,483).
tendencia(1606,25,136,698).
tendencia(1607,26,75,168).
tendencia(1608,20,96,613).
tendencia(1609,7,248,570).
tendencia(1610,18,118,1061).
tendencia(1611,2,66,317).
tendencia(1612,5,154,325).
tendencia(1613,20,233,56).
tendencia(1614,13,203,242).
tendencia(1615,12,221,1267).
tendencia(1616,19,54,944).
tendencia(1617,9,61,339).
tendencia(1618,3,269,767).
tendencia(1619,15,221,997).
tendencia(1620,2,159,64).
tendencia(1621,8,287,500).
tendencia(1622,19,157,251).
tendencia(1623,27,229,787).
tendencia(1624,17,242,406).
tendencia(1625,7,125,914).
tendencia(1626,11,226,1139).
tendencia(1627,17,209,1147).
tendencia(1628,5,281,677).
tendencia(1629,6,244,1283).
tendencia(1630,10,79,506).
tendencia(1631,8,287,1278).
tendencia(1632,4,69,486).
tendencia(1633,19,234,893).
tendencia(1634,18,94,1175).
tendencia(1635,15,127,93).
tendencia(1636,27,232,335).
tendencia(1637,24,77,1216).
tendencia(1638,16,256,759).
tendencia(1639,5,265,451).
tendencia(1640,1,146,529).
tendencia(1641,3,157,1194).
tendencia(1642,7,170,108).
tendencia(1643,10,297,1161).
tendencia(1644,7,104,478).
tendencia(1645,24,136,991).
tendencia(1646,25,240,409).
tendencia(1647,9,262,476).
tendencia(1648,10,268,85).
tendencia(1649,16,80,330).
tendencia(1650,15,192,612).
tendencia(1651,12,229,1343).
tendencia(1652,11,81,304).
tendencia(1653,15,85,1006).
tendencia(1654,23,114,966).
tendencia(1655,1,162,601).
tendencia(1656,7,166,279).
tendencia(1657,26,272,1106).
tendencia(1658,20,92,932).
tendencia(1659,4,126,608).
tendencia(1660,6,119,13).
tendencia(1661,24,256,718).
tendencia(1662,19,255,1130).
tendencia(1663,16,135,750).
tendencia(1664,4,263,1277).
tendencia(1665,23,172,972).
tendencia(1666,7,72,683).
tendencia(1667,1,225,493).
tendencia(1668,8,241,1121).
tendencia(1669,25,298,577).
tendencia(1670,6,185,104).
tendencia(1671,12,84,491).
tendencia(1672,24,276,79).
tendencia(1673,13,225,106).
tendencia(1674,5,269,361).
tendencia(1675,9,97,484).
tendencia(1676,7,134,1128).
tendencia(1677,16,54,813).
tendencia(1678,24,294,23).
tendencia(1679,22,106,842).
tendencia(1680,16,134,554).
tendencia(1681,24,86,316).
tendencia(1682,17,107,1348).
tendencia(1683,12,289,1090).
tendencia(1684,17,223,1284).
tendencia(1685,5,187,1107).
tendencia(1686,27,214,1210).
tendencia(1687,4,209,387).
tendencia(1688,9,69,689).
tendencia(1689,12,278,689).
tendencia(1690,20,150,642).
tendencia(1691,14,202,447).
tendencia(1692,12,145,876).
tendencia(1693,6,283,42).
tendencia(1694,12,159,986).
tendencia(1695,7,279,533).
tendencia(1696,21,79,1195).
tendencia(1697,19,249,293).
tendencia(1698,12,148,350).
tendencia(1699,23,60,141).
tendencia(1700,19,170,633).
tendencia(1701,21,197,754).
tendencia(1702,16,152,97).
tendencia(1703,5,169,195).
tendencia(1704,24,84,307).
tendencia(1705,12,265,919).
tendencia(1706,10,294,77).
tendencia(1707,12,212,153).
tendencia(1708,11,197,824).
tendencia(1709,12,192,67).
tendencia(1710,27,197,1032).
tendencia(1711,8,245,727).
tendencia(1712,6,258,249).
tendencia(1713,24,97,898).
tendencia(1714,6,198,326).
tendencia(1715,15,134,640).
tendencia(1716,22,238,745).
tendencia(1717,16,169,217).
tendencia(1718,18,222,121).
tendencia(1719,20,128,1162).
tendencia(1720,20,293,1335).
tendencia(1721,3,155,591).
tendencia(1722,4,189,578).
tendencia(1723,4,52,399).
tendencia(1724,1,180,596).
tendencia(1725,7,181,1146).
tendencia(1726,20,102,406).
tendencia(1727,1,131,991).
tendencia(1728,17,110,6).
tendencia(1729,14,225,1064).
tendencia(1730,16,78,507).
tendencia(1731,11,256,136).
tendencia(1732,4,244,126).
tendencia(1733,17,230,1165).
tendencia(1734,16,279,517).
tendencia(1735,1,300,649).
tendencia(1736,1,276,22).
tendencia(1737,13,67,42).
tendencia(1738,5,259,434).
tendencia(1739,2,293,864).
tendencia(1740,25,241,344).
tendencia(1741,21,89,760).
tendencia(1742,17,298,866).
tendencia(1743,6,185,1168).
tendencia(1744,10,268,163).
tendencia(1745,21,228,152).
tendencia(1746,3,274,461).
tendencia(1747,16,232,42).
tendencia(1748,2,207,903).
tendencia(1749,3,193,811).
tendencia(1750,25,222,775).
tendencia(1751,9,226,323).
tendencia(1752,3,118,1040).
tendencia(1753,21,65,231).
tendencia(1754,22,128,239).
tendencia(1755,27,244,463).
tendencia(1756,24,247,8).
tendencia(1757,3,239,229).
tendencia(1758,15,94,920).
tendencia(1759,8,173,1104).
tendencia(1760,27,50,500).
tendencia(1761,23,57,128).
tendencia(1762,24,76,876).
tendencia(1763,24,67,1288).
tendencia(1764,4,168,1224).
tendencia(1765,3,161,1304).
tendencia(1766,6,187,526).
tendencia(1767,3,216,1278).
tendencia(1768,10,289,1254).
tendencia(1769,9,144,544).
tendencia(1770,13,269,558).
tendencia(1771,25,139,248).
tendencia(1772,25,93,352).
tendencia(1773,5,277,574).
tendencia(1774,1,234,345).
tendencia(1775,16,108,567).
tendencia(1776,23,140,657).
tendencia(1777,19,197,373).
tendencia(1778,27,110,409).
tendencia(1779,10,212,314).
tendencia(1780,4,185,1106).
tendencia(1781,7,148,1097).
tendencia(1782,26,236,488).
tendencia(1783,12,150,102).
tendencia(1784,5,155,626).
tendencia(1785,22,149,1295).
tendencia(1786,9,106,122).
tendencia(1787,4,264,620).
tendencia(1788,19,194,447).
tendencia(1789,23,171,312).
tendencia(1790,3,193,1023).
tendencia(1791,12,210,276).
tendencia(1792,12,258,554).
tendencia(1793,12,160,1230).
tendencia(1794,1,223,233).
tendencia(1795,9,109,284).
tendencia(1796,14,127,398).
tendencia(1797,8,137,858).
tendencia(1798,16,170,946).
tendencia(1799,6,175,1275).
tendencia(1800,3,258,926).
tendencia(1801,17,224,406).
tendencia(1802,21,168,1070).
tendencia(1803,9,272,62).
tendencia(1804,26,235,770).
tendencia(1805,27,161,387).
tendencia(1806,15,227,665).
tendencia(1807,9,61,797).
tendencia(1808,12,76,285).
tendencia(1809,25,280,1175).
tendencia(1810,27,120,139).
tendencia(1811,3,116,648).
tendencia(1812,1,162,53).
tendencia(1813,6,125,208).
tendencia(1814,8,244,391).
tendencia(1815,2,220,44).
tendencia(1816,12,106,1203).
tendencia(1817,7,271,414).
tendencia(1818,11,262,614).
tendencia(1819,1,201,430).
tendencia(1820,17,282,987).
tendencia(1821,7,295,252).
tendencia(1822,14,202,1304).
tendencia(1823,19,94,56).
tendencia(1824,21,232,541).
tendencia(1825,2,108,393).
tendencia(1826,23,261,949).
tendencia(1827,12,251,482).
tendencia(1828,6,195,679).
tendencia(1829,5,258,981).
tendencia(1830,3,222,1207).
tendencia(1831,26,96,635).
tendencia(1832,21,266,694).
tendencia(1833,1,72,308).
tendencia(1834,11,294,419).
tendencia(1835,5,210,257).
tendencia(1836,6,238,804).
tendencia(1837,13,63,135).
tendencia(1838,3,113,984).
tendencia(1839,24,136,223).
tendencia(1840,23,114,583).
tendencia(1841,5,67,907).
tendencia(1842,18,268,797).
tendencia(1843,2,134,596).
tendencia(1844,6,109,1174).
tendencia(1845,26,228,380).
tendencia(1846,5,191,386).
tendencia(1847,5,264,1285).
tendencia(1848,15,186,573).
tendencia(1849,10,242,447).
tendencia(1850,7,297,754).
tendencia(1851,25,220,50).
tendencia(1852,17,242,431).
tendencia(1853,10,235,285).
tendencia(1854,25,140,81).
tendencia(1855,27,149,542).
tendencia(1856,7,285,1253).
tendencia(1857,22,178,745).
tendencia(1858,25,274,1252).
tendencia(1859,20,257,919).
tendencia(1860,3,83,526).
tendencia(1861,5,255,90).
tendencia(1862,12,120,199).
tendencia(1863,19,219,1108).
tendencia(1864,7,55,698).
tendencia(1865,4,289,578).
tendencia(1866,16,118,410).
tendencia(1867,7,244,940).
tendencia(1868,20,142,638).
tendencia(1869,15,194,87).
tendencia(1870,5,215,845).
tendencia(1871,4,93,361).
tendencia(1872,5,235,915).
tendencia(1873,21,125,1292).
tendencia(1874,11,183,1323).
tendencia(1875,23,174,349).
tendencia(1876,10,156,231).
tendencia(1877,26,150,115).
tendencia(1878,10,168,1117).
tendencia(1879,8,132,1305).
tendencia(1880,5,173,859).
tendencia(1881,22,131,65).
tendencia(1882,4,271,400).
tendencia(1883,4,99,1031).
tendencia(1884,19,164,1081).
tendencia(1885,20,280,867).
tendencia(1886,21,272,1153).
tendencia(1887,24,115,1193).
tendencia(1888,27,106,1209).
tendencia(1889,11,216,701).
tendencia(1890,7,99,447).
tendencia(1891,22,118,575).
tendencia(1892,25,158,105).
tendencia(1893,16,111,851).
tendencia(1894,21,296,825).
tendencia(1895,3,119,305).
tendencia(1896,11,147,1307).
tendencia(1897,8,58,917).
tendencia(1898,4,218,848).
tendencia(1899,4,101,425).
tendencia(1900,5,204,1168).
tendencia(1901,27,243,1241).
tendencia(1902,15,161,1207).
tendencia(1903,19,251,648).
tendencia(1904,12,249,1205).
tendencia(1905,23,80,1099).
tendencia(1906,19,170,760).
tendencia(1907,19,136,509).
tendencia(1908,24,95,1313).
tendencia(1909,17,226,775).
tendencia(1910,22,267,741).
tendencia(1911,8,195,1053).
tendencia(1912,18,188,1282).
tendencia(1913,23,185,1246).
tendencia(1914,21,160,361).
tendencia(1915,1,207,678).
tendencia(1916,16,278,1060).
tendencia(1917,14,216,1149).
tendencia(1918,13,243,1300).
tendencia(1919,14,243,825).
tendencia(1920,19,176,1062).
tendencia(1921,2,217,555).
tendencia(1922,12,214,793).
tendencia(1923,6,210,312).
tendencia(1924,4,147,852).
tendencia(1925,3,291,310).
tendencia(1926,2,167,80).
tendencia(1927,4,148,160).
tendencia(1928,23,236,831).
tendencia(1929,24,151,226).
tendencia(1930,25,239,339).
tendencia(1931,12,130,139).
tendencia(1932,5,241,513).
tendencia(1933,8,56,891).
tendencia(1934,15,86,455).
tendencia(1935,13,232,199).
tendencia(1936,22,252,647).
tendencia(1937,10,73,626).
tendencia(1938,20,148,1101).
tendencia(1939,2,112,882).
tendencia(1940,15,264,84).
tendencia(1941,18,250,459).
tendencia(1942,9,99,638).
tendencia(1943,6,122,142).
tendencia(1944,19,139,979).
tendencia(1945,4,77,525).
tendencia(1946,19,213,1347).
tendencia(1947,27,51,697).
tendencia(1948,4,181,933).
tendencia(1949,26,157,1111).
tendencia(1950,14,264,462).
tendencia(1951,17,157,784).
tendencia(1952,5,112,1148).
tendencia(1953,11,225,281).
tendencia(1954,8,117,537).
tendencia(1955,1,168,282).
tendencia(1956,11,247,1322).
tendencia(1957,6,198,706).
tendencia(1958,24,125,999).
tendencia(1959,6,165,130).
tendencia(1960,7,176,223).
tendencia(1961,24,66,1187).
tendencia(1962,23,157,1084).
tendencia(1963,22,132,434).
tendencia(1964,5,254,144).
tendencia(1965,7,140,803).
tendencia(1966,3,208,701).
tendencia(1967,13,133,961).
tendencia(1968,6,287,414).
tendencia(1969,12,67,801).
tendencia(1970,5,185,81).
tendencia(1971,8,179,621).
tendencia(1972,14,177,225).
tendencia(1973,17,179,1275).
tendencia(1974,8,160,854).
tendencia(1975,20,239,1060).
tendencia(1976,15,259,1299).
tendencia(1977,20,121,401).
tendencia(1978,27,163,837).
tendencia(1979,1,192,401).
tendencia(1980,25,147,1225).
tendencia(1981,7,219,373).
tendencia(1982,26,210,157).
tendencia(1983,1,127,1259).
tendencia(1984,26,50,1031).
tendencia(1985,27,56,112).
tendencia(1986,24,243,884).
tendencia(1987,20,169,149).
tendencia(1988,14,71,1226).
tendencia(1989,19,248,1177).
tendencia(1990,22,95,112).
tendencia(1991,6,117,142).
tendencia(1992,24,197,1018).
tendencia(1993,22,173,878).
tendencia(1994,25,279,567).
tendencia(1995,19,229,891).
tendencia(1996,22,255,746).
tendencia(1997,26,147,515).
tendencia(1998,7,65,1266).
tendencia(1999,14,139,1228).
tendencia(2000,3,149,146).
tendencia(2001,12,164,1178).
tendencia(2002,7,130,147).
tendencia(2003,4,289,689).
tendencia(2004,4,160,455).
tendencia(2005,13,290,564).
tendencia(2006,18,69,246).
tendencia(2007,2,160,742).
tendencia(2008,19,119,309).
tendencia(2009,23,58,235).
tendencia(2010,4,202,566).
tendencia(2011,19,272,755).
tendencia(2012,12,202,1131).
tendencia(2013,5,218,387).
tendencia(2014,1,129,960).
tendencia(2015,8,165,1078).
tendencia(2016,23,250,674).
tendencia(2017,2,188,467).
tendencia(2018,15,135,431).
tendencia(2019,1,144,1035).
tendencia(2020,15,161,1230).
tendencia(2021,17,250,434).
tendencia(2022,9,95,1268).
tendencia(2023,20,200,871).
tendencia(2024,1,125,485).
tendencia(2025,25,58,492).
tendencia(2026,12,291,610).
tendencia(2027,11,134,424).
tendencia(2028,23,139,690).
tendencia(2029,4,215,816).
tendencia(2030,21,148,1316).
tendencia(2031,7,62,997).
tendencia(2032,7,87,65).
tendencia(2033,15,251,1079).
tendencia(2034,19,185,635).
tendencia(2035,22,99,611).
tendencia(2036,15,169,317).
tendencia(2037,8,296,539).
tendencia(2038,15,61,63).
tendencia(2039,10,50,328).
tendencia(2040,20,232,833).
tendencia(2041,10,250,926).
tendencia(2042,11,165,78).
tendencia(2043,18,285,229).
tendencia(2044,22,272,526).
tendencia(2045,11,120,659).
tendencia(2046,1,203,238).
tendencia(2047,19,155,1329).
tendencia(2048,7,289,812).
tendencia(2049,25,280,488).
tendencia(2050,23,261,126).
tendencia(2051,4,157,140).
tendencia(2052,6,55,785).
tendencia(2053,17,216,840).
tendencia(2054,7,154,839).
tendencia(2055,26,167,469).
tendencia(2056,4,167,1183).
tendencia(2057,1,112,823).
tendencia(2058,12,283,918).
tendencia(2059,13,274,34).
tendencia(2060,10,105,112).
tendencia(2061,12,69,631).
tendencia(2062,11,59,281).
tendencia(2063,18,102,1148).
tendencia(2064,3,59,228).
tendencia(2065,18,239,934).
tendencia(2066,19,222,625).
tendencia(2067,9,104,1123).
tendencia(2068,15,127,581).
tendencia(2069,5,130,792).
tendencia(2070,24,246,1101).
tendencia(2071,1,85,940).
tendencia(2072,7,184,1073).
tendencia(2073,16,101,7).
tendencia(2074,12,154,1293).
tendencia(2075,7,235,209).
tendencia(2076,25,161,502).
tendencia(2077,15,83,914).
tendencia(2078,14,85,253).
tendencia(2079,8,278,384).
tendencia(2080,19,200,76).
tendencia(2081,22,275,604).
tendencia(2082,19,163,918).
tendencia(2083,18,195,336).
tendencia(2084,25,193,928).
tendencia(2085,6,133,955).
tendencia(2086,19,74,1213).
tendencia(2087,22,54,457).
tendencia(2088,10,136,158).
tendencia(2089,2,295,893).
tendencia(2090,26,100,666).
tendencia(2091,20,95,225).
tendencia(2092,4,171,626).
tendencia(2093,9,64,475).
tendencia(2094,22,233,901).
tendencia(2095,23,239,750).
tendencia(2096,11,221,349).
tendencia(2097,14,130,734).
tendencia(2098,8,98,394).
tendencia(2099,25,230,883).
tendencia(2100,22,206,360).
tendencia(2101,4,200,432).
tendencia(2102,6,280,1252).
tendencia(2103,21,248,323).
tendencia(2104,27,232,938).
tendencia(2105,5,67,280).
tendencia(2106,9,141,698).
tendencia(2107,7,225,1293).
tendencia(2108,12,124,1218).
tendencia(2109,19,282,889).
tendencia(2110,22,85,441).
tendencia(2111,14,210,986).
tendencia(2112,23,229,1284).
tendencia(2113,10,114,32).
tendencia(2114,15,54,1157).
tendencia(2115,17,129,306).
tendencia(2116,15,228,774).
tendencia(2117,9,146,120).
tendencia(2118,19,254,626).
tendencia(2119,15,70,693).
tendencia(2120,19,51,214).
tendencia(2121,11,223,147).
tendencia(2122,3,59,971).
tendencia(2123,21,55,121).
tendencia(2124,13,254,644).
tendencia(2125,2,136,1096).
tendencia(2126,24,95,1022).
tendencia(2127,9,189,1163).
tendencia(2128,24,134,465).
tendencia(2129,9,229,989).
tendencia(2130,23,131,169).
tendencia(2131,25,187,841).
tendencia(2132,10,262,813).
tendencia(2133,13,212,542).
tendencia(2134,13,258,587).
tendencia(2135,25,194,93).
tendencia(2136,1,253,1249).
tendencia(2137,18,203,1343).
tendencia(2138,19,136,856).
tendencia(2139,16,208,865).
tendencia(2140,10,173,1101).
tendencia(2141,3,90,967).
tendencia(2142,4,228,1145).
tendencia(2143,26,137,687).
tendencia(2144,22,214,413).
tendencia(2145,10,268,896).
tendencia(2146,17,81,532).
tendencia(2147,27,237,396).
tendencia(2148,13,250,1180).
tendencia(2149,18,229,800).
tendencia(2150,20,192,296).
tendencia(2151,3,252,545).
tendencia(2152,8,171,436).
tendencia(2153,5,163,1333).
tendencia(2154,18,247,783).
tendencia(2155,13,88,676).
tendencia(2156,16,114,1012).
tendencia(2157,6,137,824).
tendencia(2158,17,232,670).
tendencia(2159,14,297,911).
tendencia(2160,11,127,785).
tendencia(2161,16,101,633).
tendencia(2162,10,110,257).
tendencia(2163,9,119,445).
tendencia(2164,18,65,1085).
tendencia(2165,6,243,189).
tendencia(2166,19,138,693).
tendencia(2167,9,228,1055).
tendencia(2168,27,53,329).
tendencia(2169,2,53,81).
tendencia(2170,2,294,1169).
tendencia(2171,24,55,267).
tendencia(2172,24,240,1210).
tendencia(2173,25,118,585).
tendencia(2174,1,236,1108).
tendencia(2175,6,96,107).
tendencia(2176,4,254,926).
tendencia(2177,27,65,1297).
tendencia(2178,12,100,937).
tendencia(2179,3,233,282).
tendencia(2180,14,121,78).
tendencia(2181,1,112,66).
tendencia(2182,5,266,578).
tendencia(2183,3,185,758).
tendencia(2184,18,59,169).
tendencia(2185,27,299,1341).
tendencia(2186,14,193,32).
tendencia(2187,20,193,279).
tendencia(2188,17,59,16).
tendencia(2189,18,57,999).
tendencia(2190,19,62,94).
tendencia(2191,11,251,642).
tendencia(2192,1,54,237).
tendencia(2193,21,206,505).
tendencia(2194,22,266,310).
tendencia(2195,3,98,243).
tendencia(2196,20,98,855).
tendencia(2197,21,222,480).
tendencia(2198,4,221,231).
tendencia(2199,8,282,750).
tendencia(2200,15,253,804).
tendencia(2201,24,175,341).
tendencia(2202,10,191,633).
tendencia(2203,15,265,685).
tendencia(2204,16,260,79).
tendencia(2205,25,243,136).
tendencia(2206,24,230,122).
tendencia(2207,20,135,683).
tendencia(2208,10,57,400).
tendencia(2209,14,156,769).
tendencia(2210,11,61,686).
tendencia(2211,6,82,865).
tendencia(2212,12,141,207).
tendencia(2213,18,60,1266).
tendencia(2214,2,137,917).
tendencia(2215,8,252,1020).
tendencia(2216,23,184,560).
tendencia(2217,3,73,1133).
tendencia(2218,18,114,363).
tendencia(2219,7,166,434).
tendencia(2220,10,238,225).
tendencia(2221,21,64,383).
tendencia(2222,11,75,71).
tendencia(2223,7,184,836).
tendencia(2224,27,162,852).
tendencia(2225,11,97,307).
tendencia(2226,2,231,500).
tendencia(2227,5,247,530).
tendencia(2228,11,183,331).
tendencia(2229,5,236,191).
tendencia(2230,6,145,212).
tendencia(2231,12,254,575).
tendencia(2232,2,213,851).
tendencia(2233,21,214,80).
tendencia(2234,6,147,1076).
tendencia(2235,21,121,1249).
tendencia(2236,5,197,962).
tendencia(2237,25,150,46).
tendencia(2238,4,217,486).
tendencia(2239,22,84,1339).
tendencia(2240,9,237,362).
tendencia(2241,12,276,697).
tendencia(2242,5,224,704).
tendencia(2243,9,288,847).
tendencia(2244,19,182,429).
tendencia(2245,14,240,762).
tendencia(2246,2,228,71).
tendencia(2247,9,87,888).
tendencia(2248,23,228,617).
tendencia(2249,26,119,591).
tendencia(2250,8,126,126).
tendencia(2251,16,239,822).
tendencia(2252,17,139,357).
tendencia(2253,24,292,705).
tendencia(2254,14,179,60).
tendencia(2255,26,122,404).
tendencia(2256,16,227,1267).
tendencia(2257,20,79,1184).
tendencia(2258,2,162,176).
tendencia(2259,18,135,1137).
tendencia(2260,17,269,397).
tendencia(2261,6,134,645).
tendencia(2262,19,187,142).
tendencia(2263,12,281,335).
tendencia(2264,27,259,372).
tendencia(2265,3,231,182).
tendencia(2266,7,211,125).
tendencia(2267,1,224,1150).
tendencia(2268,19,53,1283).
tendencia(2269,16,223,443).
tendencia(2270,7,297,1298).
tendencia(2271,1,83,391).
tendencia(2272,3,272,974).
tendencia(2273,5,208,405).
tendencia(2274,8,129,1253).
tendencia(2275,1,53,891).
tendencia(2276,8,222,616).
tendencia(2277,14,63,517).
tendencia(2278,8,287,65).
tendencia(2279,26,60,697).
tendencia(2280,14,281,876).
tendencia(2281,7,100,813).
tendencia(2282,6,66,514).
tendencia(2283,26,162,191).
tendencia(2284,23,166,822).
tendencia(2285,6,119,1255).
tendencia(2286,2,249,1093).
tendencia(2287,6,226,292).
tendencia(2288,21,144,889).
tendencia(2289,20,114,564).
tendencia(2290,12,204,968).
tendencia(2291,16,108,1322).
tendencia(2292,27,67,1039).
tendencia(2293,7,101,1318).
tendencia(2294,2,243,413).
tendencia(2295,27,74,456).
tendencia(2296,16,223,1231).
tendencia(2297,10,231,528).
tendencia(2298,19,125,47).
tendencia(2299,5,245,608).
tendencia(2300,7,190,1293).
tendencia(2301,3,51,1305).
tendencia(2302,21,67,978).
tendencia(2303,27,209,1177).
tendencia(2304,20,167,736).
tendencia(2305,7,113,18).
tendencia(2306,1,228,692).
tendencia(2307,14,183,923).
tendencia(2308,13,132,1259).
tendencia(2309,20,110,757).
tendencia(2310,19,103,287).
tendencia(2311,16,214,833).
tendencia(2312,4,176,619).
tendencia(2313,26,154,324).
tendencia(2314,18,215,78).
tendencia(2315,9,64,99).
tendencia(2316,16,88,503).
tendencia(2317,19,265,211).
tendencia(2318,16,55,869).
tendencia(2319,4,119,60).
tendencia(2320,27,80,14).
tendencia(2321,17,148,758).
tendencia(2322,7,106,1215).
tendencia(2323,21,209,1173).
tendencia(2324,27,229,387).
tendencia(2325,23,145,1159).
tendencia(2326,14,198,1169).
tendencia(2327,6,197,583).
tendencia(2328,6,119,58).
tendencia(2329,9,142,377).
tendencia(2330,27,184,1080).
tendencia(2331,11,97,199).
tendencia(2332,24,226,839).
tendencia(2333,22,255,904).
tendencia(2334,16,112,309).
tendencia(2335,5,231,439).
tendencia(2336,21,132,45).
tendencia(2337,19,262,2).
tendencia(2338,20,223,623).
tendencia(2339,27,190,248).
tendencia(2340,2,271,845).
tendencia(2341,19,291,323).
tendencia(2342,26,133,278).
tendencia(2343,2,239,1321).
tendencia(2344,11,149,512).
tendencia(2345,14,274,146).
tendencia(2346,12,119,617).
tendencia(2347,21,113,1214).
tendencia(2348,27,143,840).
tendencia(2349,15,284,1322).
tendencia(2350,23,208,754).
tendencia(2351,10,184,290).
tendencia(2352,11,160,411).
tendencia(2353,16,263,798).
tendencia(2354,24,60,827).
tendencia(2355,16,246,1332).
tendencia(2356,23,185,517).
tendencia(2357,9,234,1235).
tendencia(2358,7,92,538).
tendencia(2359,26,241,627).
tendencia(2360,13,100,838).
tendencia(2361,24,242,934).
tendencia(2362,17,170,54).
tendencia(2363,3,212,1237).
tendencia(2364,13,111,606).
tendencia(2365,2,188,1275).
tendencia(2366,10,114,807).
tendencia(2367,6,129,193).
tendencia(2368,15,170,164).
tendencia(2369,23,269,923).
tendencia(2370,27,76,109).
tendencia(2371,7,135,604).
tendencia(2372,1,64,1318).
tendencia(2373,11,281,660).
tendencia(2374,8,210,439).
tendencia(2375,16,275,918).
tendencia(2376,15,94,845).
tendencia(2377,24,147,559).
tendencia(2378,5,176,1320).
tendencia(2379,6,195,494).
tendencia(2380,6,177,551).
tendencia(2381,17,198,637).
tendencia(2382,24,53,1326).
tendencia(2383,21,205,1176).
tendencia(2384,11,122,703).
tendencia(2385,26,158,1038).
tendencia(2386,1,154,101).
tendencia(2387,11,286,297).
tendencia(2388,13,111,693).
tendencia(2389,16,141,327).
tendencia(2390,3,181,116).
tendencia(2391,17,249,192).
tendencia(2392,7,270,396).
tendencia(2393,15,169,186).
tendencia(2394,4,128,147).
tendencia(2395,12,90,169).
tendencia(2396,22,133,741).
tendencia(2397,12,64,988).
tendencia(2398,10,112,914).
tendencia(2399,26,165,785).
tendencia(2400,18,296,11).
tendencia(2401,15,292,10).
tendencia(2402,9,115,513).
tendencia(2403,4,296,1015).
tendencia(2404,17,136,1139).
tendencia(2405,11,200,397).
tendencia(2406,27,229,378).
tendencia(2407,17,77,854).
tendencia(2408,9,161,63).
tendencia(2409,18,289,246).
tendencia(2410,16,65,237).
tendencia(2411,8,213,479).
tendencia(2412,7,118,1230).
tendencia(2413,26,62,890).
tendencia(2414,23,172,775).
tendencia(2415,27,251,94).
tendencia(2416,4,210,673).
tendencia(2417,10,121,929).
tendencia(2418,22,264,46).
tendencia(2419,8,98,621).
tendencia(2420,10,203,798).
tendencia(2421,14,293,988).
tendencia(2422,15,279,166).
tendencia(2423,13,231,645).
tendencia(2424,18,127,510).
tendencia(2425,15,176,749).
tendencia(2426,5,96,894).
tendencia(2427,4,58,826).
tendencia(2428,25,293,1272).
tendencia(2429,12,251,1205).
tendencia(2430,3,297,897).
tendencia(2431,2,61,368).
tendencia(2432,18,70,526).
tendencia(2433,19,202,1103).
tendencia(2434,1,247,1082).
tendencia(2435,12,300,688).
tendencia(2436,18,101,1193).
tendencia(2437,5,233,739).
tendencia(2438,7,185,1001).
tendencia(2439,15,237,549).
tendencia(2440,10,121,1035).
tendencia(2441,6,176,276).
tendencia(2442,15,258,132).
tendencia(2443,27,101,917).
tendencia(2444,26,208,1278).
tendencia(2445,8,164,28).
tendencia(2446,17,204,581).
tendencia(2447,17,260,225).
tendencia(2448,25,121,70).
tendencia(2449,11,261,664).
tendencia(2450,7,80,1032).
tendencia(2451,1,222,986).
tendencia(2452,3,168,232).
tendencia(2453,3,94,987).
tendencia(2454,8,117,499).
tendencia(2455,3,153,885).
tendencia(2456,23,67,239).
tendencia(2457,15,76,809).
tendencia(2458,19,103,420).
tendencia(2459,1,239,323).
tendencia(2460,1,272,893).
tendencia(2461,20,162,888).
tendencia(2462,18,112,581).
tendencia(2463,21,99,1246).
tendencia(2464,23,74,1342).
tendencia(2465,17,100,868).
tendencia(2466,10,133,245).
tendencia(2467,6,115,401).
tendencia(2468,17,293,434).
tendencia(2469,27,70,467).
tendencia(2470,20,265,614).
tendencia(2471,27,294,15).
tendencia(2472,14,101,102).
tendencia(2473,9,206,963).
tendencia(2474,10,101,539).
tendencia(2475,7,108,681).
tendencia(2476,20,67,140).
tendencia(2477,16,278,456).
tendencia(2478,19,214,497).
tendencia(2479,24,275,228).
tendencia(2480,10,274,680).
tendencia(2481,3,243,1164).
tendencia(2482,4,184,624).
tendencia(2483,20,83,966).
tendencia(2484,3,283,610).
tendencia(2485,4,68,192).
tendencia(2486,11,63,404).
tendencia(2487,3,156,1011).
tendencia(2488,17,135,221).
tendencia(2489,27,153,1337).
tendencia(2490,26,173,1281).
tendencia(2491,14,152,305).
tendencia(2492,8,279,115).
tendencia(2493,10,65,1219).
tendencia(2494,23,242,206).
tendencia(2495,13,291,1104).
tendencia(2496,7,58,311).
tendencia(2497,14,126,635).
tendencia(2498,22,109,392).
tendencia(2499,21,159,358).
tendencia(2500,5,144,736).
tendencia(2501,18,143,1053).
tendencia(2502,24,175,715).
tendencia(2503,16,128,933).
tendencia(2504,11,140,652).
tendencia(2505,25,249,376).
tendencia(2506,11,248,1070).
tendencia(2507,20,282,139).
tendencia(2508,12,237,702).
tendencia(2509,23,207,1148).
tendencia(2510,14,160,480).
tendencia(2511,20,230,765).
tendencia(2512,22,77,193).
tendencia(2513,20,293,47).
tendencia(2514,5,157,14).
tendencia(2515,10,193,51).
tendencia(2516,23,127,462).
tendencia(2517,16,249,845).
tendencia(2518,2,84,956).
tendencia(2519,27,276,870).
tendencia(2520,14,300,113).
tendencia(2521,25,51,458).
tendencia(2522,25,201,1169).
tendencia(2523,1,272,1163).
tendencia(2524,4,221,739).
tendencia(2525,22,135,1116).
tendencia(2526,13,132,609).
tendencia(2527,9,111,448).
tendencia(2528,13,288,1130).
tendencia(2529,5,241,1030).
tendencia(2530,7,144,381).
tendencia(2531,19,260,490).
tendencia(2532,2,66,861).
tendencia(2533,15,215,298).
tendencia(2534,26,56,112).
tendencia(2535,4,128,572).
tendencia(2536,2,81,693).
tendencia(2537,25,290,678).
tendencia(2538,3,239,701).
tendencia(2539,10,169,803).
tendencia(2540,12,134,303).
tendencia(2541,2,65,474).
tendencia(2542,14,116,753).
tendencia(2543,8,191,1293).
tendencia(2544,7,294,1017).
tendencia(2545,20,83,553).
tendencia(2546,19,51,1021).
tendencia(2547,12,295,1167).
tendencia(2548,14,116,680).
tendencia(2549,3,251,1142).
tendencia(2550,26,237,725).
tendencia(2551,14,140,282).
tendencia(2552,26,162,217).
tendencia(2553,20,94,346).
tendencia(2554,22,181,349).
tendencia(2555,12,51,767).
tendencia(2556,10,228,1294).
tendencia(2557,27,146,685).
tendencia(2558,15,275,292).
tendencia(2559,6,280,1039).
tendencia(2560,20,98,27).
tendencia(2561,20,220,1194).
tendencia(2562,14,121,1284).
tendencia(2563,26,53,369).
tendencia(2564,13,109,588).
tendencia(2565,13,271,402).
tendencia(2566,25,80,529).
tendencia(2567,9,216,334).
tendencia(2568,14,132,143).
tendencia(2569,24,140,599).
tendencia(2570,20,184,384).
tendencia(2571,7,204,80).
tendencia(2572,7,92,634).
tendencia(2573,15,135,163).
tendencia(2574,23,87,1197).
tendencia(2575,20,187,1118).
tendencia(2576,21,117,167).
tendencia(2577,16,217,493).
tendencia(2578,27,167,858).
tendencia(2579,9,124,1246).
tendencia(2580,9,112,798).
tendencia(2581,10,165,409).
tendencia(2582,21,194,1284).
tendencia(2583,24,84,38).
tendencia(2584,4,274,120).
tendencia(2585,8,280,1090).
tendencia(2586,2,240,436).
tendencia(2587,8,189,402).
tendencia(2588,2,71,103).
tendencia(2589,9,231,1038).
tendencia(2590,19,263,937).
tendencia(2591,19,216,1005).
tendencia(2592,24,50,987).
tendencia(2593,24,88,1220).
tendencia(2594,2,203,215).
tendencia(2595,25,61,769).
tendencia(2596,22,164,1219).
tendencia(2597,26,190,272).
tendencia(2598,2,123,1266).
tendencia(2599,23,281,614).
tendencia(2600,21,189,30).
tendencia(2601,20,163,104).
tendencia(2602,3,151,153).
tendencia(2603,4,185,1210).
tendencia(2604,1,126,769).
tendencia(2605,27,249,196).
tendencia(2606,5,85,493).
tendencia(2607,20,120,575).
tendencia(2608,14,149,244).
tendencia(2609,3,292,1324).
tendencia(2610,12,184,460).
tendencia(2611,22,110,687).
tendencia(2612,16,219,799).
tendencia(2613,8,151,908).
tendencia(2614,19,278,555).
tendencia(2615,17,92,344).
tendencia(2616,6,115,1259).
tendencia(2617,11,96,1258).
tendencia(2618,12,119,118).
tendencia(2619,27,96,1104).
tendencia(2620,27,85,1020).
tendencia(2621,15,200,1338).
tendencia(2622,4,144,769).
tendencia(2623,4,80,1098).
tendencia(2624,9,152,356).
tendencia(2625,4,100,698).
tendencia(2626,7,247,375).
tendencia(2627,4,266,429).
tendencia(2628,10,297,506).
tendencia(2629,3,171,97).
tendencia(2630,21,133,99).
tendencia(2631,24,105,928).
tendencia(2632,12,226,926).
tendencia(2633,1,198,28).
tendencia(2634,25,284,1017).
tendencia(2635,23,57,427).
tendencia(2636,18,101,594).
tendencia(2637,4,50,1108).
tendencia(2638,16,177,817).
tendencia(2639,18,199,524).
tendencia(2640,23,87,290).
tendencia(2641,7,148,93).
tendencia(2642,6,162,707).
tendencia(2643,1,219,1261).
tendencia(2644,14,260,1342).
tendencia(2645,21,282,1085).
tendencia(2646,25,107,260).
tendencia(2647,22,173,241).
tendencia(2648,24,216,1022).
tendencia(2649,18,196,113).
tendencia(2650,8,66,1206).
tendencia(2651,12,88,430).
tendencia(2652,12,277,331).
tendencia(2653,27,256,1202).
tendencia(2654,27,287,239).
tendencia(2655,2,154,415).
tendencia(2656,11,125,1135).
tendencia(2657,4,81,1255).
tendencia(2658,16,74,674).
tendencia(2659,26,161,242).
tendencia(2660,15,80,1302).
tendencia(2661,10,263,155).
tendencia(2662,5,260,1283).
tendencia(2663,6,80,1130).
tendencia(2664,27,139,1024).
tendencia(2665,5,139,605).
tendencia(2666,21,235,756).
tendencia(2667,19,276,842).
tendencia(2668,14,91,299).
tendencia(2669,20,275,696).
tendencia(2670,16,260,267).
tendencia(2671,3,184,1120).
tendencia(2672,7,121,1117).
tendencia(2673,4,172,974).
tendencia(2674,12,231,944).
tendencia(2675,23,241,707).
tendencia(2676,3,104,341).
tendencia(2677,18,281,1273).
tendencia(2678,25,262,631).
tendencia(2679,25,118,1347).
tendencia(2680,7,234,887).
tendencia(2681,4,206,563).
tendencia(2682,2,91,1186).
tendencia(2683,25,52,1022).
tendencia(2684,3,102,780).
tendencia(2685,13,76,888).
tendencia(2686,24,82,807).
tendencia(2687,8,293,233).
tendencia(2688,19,277,1160).
tendencia(2689,5,271,975).
tendencia(2690,12,120,473).
tendencia(2691,23,72,369).
tendencia(2692,15,187,660).
tendencia(2693,16,190,71).
tendencia(2694,16,254,960).
tendencia(2695,12,170,108).
tendencia(2696,20,50,859).
tendencia(2697,19,229,85).
tendencia(2698,6,188,363).
tendencia(2699,18,278,1322).
tendencia(2700,23,160,1315).
tendencia(2701,22,81,981).
tendencia(2702,23,147,1072).
tendencia(2703,26,101,1163).
tendencia(2704,27,216,804).
tendencia(2705,1,205,516).
tendencia(2706,21,206,460).
tendencia(2707,6,236,997).
tendencia(2708,15,102,588).
tendencia(2709,11,300,1348).
tendencia(2710,6,203,1147).
tendencia(2711,11,118,42).
tendencia(2712,13,121,565).
tendencia(2713,2,88,1010).
tendencia(2714,8,294,602).
tendencia(2715,6,85,1327).
tendencia(2716,8,86,582).
tendencia(2717,5,162,657).
tendencia(2718,18,270,419).
tendencia(2719,6,214,49).
tendencia(2720,1,100,1035).
tendencia(2721,14,254,881).
tendencia(2722,1,116,902).
tendencia(2723,10,102,905).
tendencia(2724,18,212,66).
tendencia(2725,18,287,72).
tendencia(2726,11,208,390).
tendencia(2727,24,288,145).
tendencia(2728,3,160,1220).
tendencia(2729,9,87,219).
tendencia(2730,27,173,659).
tendencia(2731,22,135,370).
tendencia(2732,10,174,2).
tendencia(2733,18,205,86).
tendencia(2734,1,160,640).
tendencia(2735,11,273,1141).
tendencia(2736,14,53,790).
tendencia(2737,5,290,1123).
tendencia(2738,15,66,814).
tendencia(2739,7,60,653).
tendencia(2740,13,274,919).
tendencia(2741,4,114,203).
tendencia(2742,26,252,412).
tendencia(2743,16,67,559).
tendencia(2744,16,225,1043).
tendencia(2745,1,110,1286).
tendencia(2746,5,256,1084).
tendencia(2747,5,100,1227).
tendencia(2748,18,223,828).
tendencia(2749,18,64,905).
tendencia(2750,12,79,1082).
tendencia(2751,25,243,893).
tendencia(2752,18,223,456).
tendencia(2753,4,233,832).
tendencia(2754,4,140,127).
tendencia(2755,8,272,1306).
tendencia(2756,13,55,368).
tendencia(2757,25,245,73).
tendencia(2758,6,292,342).
tendencia(2759,13,193,688).
tendencia(2760,1,283,318).
tendencia(2761,22,294,56).
tendencia(2762,20,230,595).
tendencia(2763,9,251,929).
tendencia(2764,2,134,198).
tendencia(2765,18,189,461).
tendencia(2766,10,159,6).
tendencia(2767,3,278,851).
tendencia(2768,9,52,857).
tendencia(2769,21,260,1145).
tendencia(2770,5,121,1227).
tendencia(2771,16,280,390).
tendencia(2772,26,197,872).
tendencia(2773,2,244,137).
tendencia(2774,5,130,824).
tendencia(2775,13,87,878).
tendencia(2776,10,150,199).
tendencia(2777,17,197,791).
tendencia(2778,17,209,464).
tendencia(2779,11,168,677).
tendencia(2780,24,252,716).
tendencia(2781,1,69,554).
tendencia(2782,13,220,2).
tendencia(2783,24,235,1114).
tendencia(2784,24,107,1029).
tendencia(2785,24,273,544).
tendencia(2786,1,135,239).
tendencia(2787,21,182,701).
tendencia(2788,8,239,1014).
tendencia(2789,2,299,31).
tendencia(2790,18,184,1232).
tendencia(2791,27,180,88).
tendencia(2792,23,83,1123).
tendencia(2793,20,68,842).
tendencia(2794,2,269,1234).
tendencia(2795,14,211,726).
tendencia(2796,4,94,488).
tendencia(2797,7,193,379).
tendencia(2798,22,246,6).
tendencia(2799,3,260,1160).
tendencia(2800,13,241,953).
tendencia(2801,3,190,450).
tendencia(2802,24,110,1252).
tendencia(2803,7,56,824).
tendencia(2804,12,181,1268).
tendencia(2805,26,92,486).
tendencia(2806,10,233,388).
tendencia(2807,21,245,220).
tendencia(2808,3,212,411).
tendencia(2809,9,148,522).
tendencia(2810,19,191,786).
tendencia(2811,7,123,115).
tendencia(2812,4,209,844).
tendencia(2813,2,211,962).
tendencia(2814,11,131,632).
tendencia(2815,9,285,204).
tendencia(2816,20,77,370).
tendencia(2817,6,248,1226).
tendencia(2818,27,220,1179).
tendencia(2819,15,153,1189).
tendencia(2820,22,250,1077).
tendencia(2821,20,198,1262).
tendencia(2822,1,261,343).
tendencia(2823,5,122,1122).
tendencia(2824,12,193,636).
tendencia(2825,8,279,1210).
tendencia(2826,3,57,361).
tendencia(2827,13,83,602).
tendencia(2828,23,231,456).
tendencia(2829,24,145,1179).
tendencia(2830,16,235,1068).
tendencia(2831,26,282,30).
tendencia(2832,18,154,529).
tendencia(2833,19,180,112).
tendencia(2834,7,88,245).
tendencia(2835,13,70,16).
tendencia(2836,12,168,596).
tendencia(2837,22,74,312).
tendencia(2838,24,146,7).
tendencia(2839,20,146,1102).
tendencia(2840,26,113,65).
tendencia(2841,7,178,1165).
tendencia(2842,27,138,1219).
tendencia(2843,24,192,1122).
tendencia(2844,25,202,505).
tendencia(2845,23,282,21).
tendencia(2846,8,68,592).
tendencia(2847,1,79,5).
tendencia(2848,13,272,271).
tendencia(2849,10,278,527).
tendencia(2850,26,262,1174).
tendencia(2851,23,208,413).
tendencia(2852,14,235,660).
tendencia(2853,3,105,916).
tendencia(2854,16,65,1008).
tendencia(2855,7,102,1218).
tendencia(2856,15,114,1293).
tendencia(2857,21,265,695).
tendencia(2858,3,123,482).
tendencia(2859,23,195,177).
tendencia(2860,17,237,292).
tendencia(2861,12,286,1217).
tendencia(2862,23,282,1212).
tendencia(2863,6,130,467).
tendencia(2864,10,68,1225).
tendencia(2865,19,63,513).
tendencia(2866,11,177,101).
tendencia(2867,4,270,796).
tendencia(2868,2,120,563).
tendencia(2869,26,244,1309).
tendencia(2870,3,183,893).
tendencia(2871,12,251,1069).
tendencia(2872,6,213,1184).
tendencia(2873,1,202,386).
tendencia(2874,27,107,628).
tendencia(2875,11,66,395).
tendencia(2876,26,94,197).
tendencia(2877,9,82,552).
tendencia(2878,3,208,774).
tendencia(2879,27,186,662).
tendencia(2880,9,238,370).
tendencia(2881,4,176,631).
tendencia(2882,15,181,283).
tendencia(2883,23,211,1134).
tendencia(2884,14,162,620).
tendencia(2885,15,236,795).
tendencia(2886,23,94,1248).
tendencia(2887,11,79,512).
tendencia(2888,18,273,237).
tendencia(2889,14,209,522).
tendencia(2890,13,173,146).
tendencia(2891,3,170,410).
tendencia(2892,23,111,764).
tendencia(2893,23,270,165).
tendencia(2894,5,234,910).
tendencia(2895,6,63,518).
tendencia(2896,23,244,60).
tendencia(2897,9,178,1094).
tendencia(2898,13,168,1227).
tendencia(2899,23,130,327).
tendencia(2900,3,264,1067).
tendencia(2901,16,180,1348).
tendencia(2902,23,292,827).
tendencia(2903,20,215,740).
tendencia(2904,4,78,1257).
tendencia(2905,2,96,496).
tendencia(2906,18,153,1263).
tendencia(2907,25,80,225).
tendencia(2908,24,126,704).
tendencia(2909,9,211,389).
tendencia(2910,12,198,969).
tendencia(2911,4,190,389).
tendencia(2912,12,132,200).
tendencia(2913,7,182,383).
tendencia(2914,24,94,1336).
tendencia(2915,19,205,654).
tendencia(2916,4,279,1072).
tendencia(2917,11,160,435).
tendencia(2918,18,265,903).
tendencia(2919,21,161,768).
tendencia(2920,15,259,709).
tendencia(2921,27,94,919).
tendencia(2922,1,138,925).
tendencia(2923,22,169,312).
tendencia(2924,15,50,722).
tendencia(2925,9,230,1088).
tendencia(2926,23,260,482).
tendencia(2927,26,288,1241).
tendencia(2928,18,251,403).
tendencia(2929,5,260,1072).
tendencia(2930,10,254,718).
tendencia(2931,23,266,875).
tendencia(2932,16,249,261).
tendencia(2933,16,284,884).
tendencia(2934,1,175,1330).
tendencia(2935,19,294,703).
tendencia(2936,1,157,939).
tendencia(2937,11,271,742).
tendencia(2938,5,299,732).
tendencia(2939,26,108,1231).
tendencia(2940,3,159,248).
tendencia(2941,13,225,82).
tendencia(2942,1,168,840).
tendencia(2943,9,225,781).
tendencia(2944,3,156,1260).
tendencia(2945,24,167,811).
tendencia(2946,1,170,571).
tendencia(2947,4,129,111).
tendencia(2948,9,67,989).
tendencia(2949,26,59,1343).
tendencia(2950,8,268,61).
tendencia(2951,21,219,726).
tendencia(2952,25,59,1334).
tendencia(2953,3,135,1191).
tendencia(2954,11,276,887).
tendencia(2955,20,191,437).
tendencia(2956,19,210,103).
tendencia(2957,20,233,631).
tendencia(2958,1,80,1156).
tendencia(2959,5,158,341).
tendencia(2960,21,263,873).
tendencia(2961,14,189,802).
tendencia(2962,22,259,598).
tendencia(2963,15,112,1027).
tendencia(2964,25,164,1112).
tendencia(2965,13,296,495).
tendencia(2966,27,145,1065).
tendencia(2967,2,51,511).
tendencia(2968,13,58,1061).
tendencia(2969,9,152,832).
tendencia(2970,19,203,961).
tendencia(2971,10,210,247).
tendencia(2972,25,266,322).
tendencia(2973,12,254,1085).
tendencia(2974,19,144,679).
tendencia(2975,25,248,831).
tendencia(2976,2,140,1255).
tendencia(2977,19,194,332).
tendencia(2978,7,203,1088).
tendencia(2979,3,144,659).
tendencia(2980,1,165,955).
tendencia(2981,8,59,573).
tendencia(2982,21,297,705).
tendencia(2983,4,122,354).
tendencia(2984,17,283,1248).
tendencia(2985,27,281,401).
tendencia(2986,22,74,650).
tendencia(2987,5,77,473).
tendencia(2988,19,273,146).
tendencia(2989,19,141,578).
tendencia(2990,15,72,572).
tendencia(2991,5,221,884).
tendencia(2992,19,242,588).
tendencia(2993,27,203,918).
tendencia(2994,25,116,313).
tendencia(2995,26,299,626).
tendencia(2996,13,109,153).
tendencia(2997,12,254,1137).
tendencia(2998,23,82,758).
tendencia(2999,19,274,392).
tendencia(3000,25,291,1190).
tendencia(3001,16,113,366).
tendencia(3002,5,159,315).
tendencia(3003,20,162,1282).
tendencia(3004,9,180,882).
tendencia(3005,11,208,1184).
tendencia(3006,2,220,275).
tendencia(3007,23,183,1172).
tendencia(3008,4,261,415).
tendencia(3009,17,182,771).
tendencia(3010,15,198,281).
tendencia(3011,22,147,802).
tendencia(3012,8,256,1173).
tendencia(3013,14,148,978).
tendencia(3014,24,62,1229).
tendencia(3015,13,59,951).
tendencia(3016,16,293,1122).
tendencia(3017,23,297,284).
tendencia(3018,8,71,1271).
tendencia(3019,18,221,536).
tendencia(3020,21,259,35).
tendencia(3021,5,157,983).
tendencia(3022,27,176,833).
tendencia(3023,24,206,647).
tendencia(3024,3,104,153).
tendencia(3025,23,130,230).
tendencia(3026,22,188,385).
tendencia(3027,8,165,772).
tendencia(3028,3,291,79).
tendencia(3029,14,299,302).
tendencia(3030,8,159,544).
tendencia(3031,8,257,597).
tendencia(3032,14,60,407).
tendencia(3033,9,220,780).
tendencia(3034,10,240,181).
tendencia(3035,1,62,1123).
tendencia(3036,22,195,1339).
tendencia(3037,24,116,492).
tendencia(3038,26,139,831).
tendencia(3039,10,171,698).
tendencia(3040,27,128,649).
tendencia(3041,6,198,783).
tendencia(3042,4,246,164).
tendencia(3043,13,54,252).
tendencia(3044,17,132,52).
tendencia(3045,12,253,1151).
tendencia(3046,11,80,338).
tendencia(3047,24,63,985).
tendencia(3048,25,53,844).
tendencia(3049,20,61,487).
tendencia(3050,18,253,777).
tendencia(3051,24,188,459).
tendencia(3052,20,124,1254).
tendencia(3053,9,180,717).
tendencia(3054,5,120,329).
tendencia(3055,12,273,1007).
tendencia(3056,16,103,538).
tendencia(3057,2,174,39).
tendencia(3058,14,234,721).
tendencia(3059,25,191,272).
tendencia(3060,15,284,1205).
tendencia(3061,24,67,1040).
tendencia(3062,3,141,573).
tendencia(3063,11,53,1096).
tendencia(3064,21,66,948).
tendencia(3065,15,89,665).
tendencia(3066,6,101,36).
tendencia(3067,19,269,1125).
tendencia(3068,8,238,237).
tendencia(3069,17,172,23).
tendencia(3070,22,262,1276).
tendencia(3071,5,92,143).
tendencia(3072,17,164,1273).
tendencia(3073,13,165,666).
tendencia(3074,21,211,696).
tendencia(3075,23,291,728).
tendencia(3076,26,271,1110).
tendencia(3077,4,179,1175).
tendencia(3078,11,150,1197).
tendencia(3079,17,173,912).
tendencia(3080,15,255,398).
tendencia(3081,12,140,795).
tendencia(3082,8,148,1148).
tendencia(3083,5,171,1319).
tendencia(3084,1,193,1299).
tendencia(3085,15,55,423).
tendencia(3086,19,278,386).
tendencia(3087,21,281,1106).
tendencia(3088,6,111,975).
tendencia(3089,7,54,377).
tendencia(3090,4,266,1059).
tendencia(3091,14,94,105).
tendencia(3092,23,51,276).
tendencia(3093,12,175,81).
tendencia(3094,24,300,1304).
tendencia(3095,12,182,648).
tendencia(3096,21,71,592).
tendencia(3097,11,291,1018).
tendencia(3098,24,236,523).
tendencia(3099,18,297,125).
tendencia(3100,6,298,902).
tendencia(3101,9,234,15).
tendencia(3102,20,187,89).
tendencia(3103,1,95,74).
tendencia(3104,23,89,240).
tendencia(3105,23,64,991).
tendencia(3106,4,204,1068).
tendencia(3107,21,99,1306).
tendencia(3108,26,144,1301).
tendencia(3109,3,278,578).
tendencia(3110,7,256,471).
tendencia(3111,19,215,1237).
tendencia(3112,5,263,629).
tendencia(3113,27,148,189).
tendencia(3114,21,175,593).
tendencia(3115,23,145,1124).
tendencia(3116,1,103,150).
tendencia(3117,23,243,692).
tendencia(3118,2,66,1337).
tendencia(3119,21,219,412).
tendencia(3120,8,88,1007).
tendencia(3121,13,243,469).
tendencia(3122,7,294,355).
tendencia(3123,23,84,901).
tendencia(3124,17,298,1031).
tendencia(3125,7,132,1300).
tendencia(3126,17,81,142).
tendencia(3127,27,189,503).
tendencia(3128,19,186,1279).
tendencia(3129,16,150,829).
tendencia(3130,27,53,438).
tendencia(3131,1,278,145).
tendencia(3132,6,109,415).
tendencia(3133,3,228,1017).
tendencia(3134,20,68,196).
tendencia(3135,13,194,1277).
tendencia(3136,20,62,110).
tendencia(3137,12,214,665).
tendencia(3138,10,237,768).
tendencia(3139,4,205,1032).
tendencia(3140,1,170,917).
tendencia(3141,11,209,481).
tendencia(3142,18,175,180).
tendencia(3143,21,220,640).
tendencia(3144,19,69,209).
tendencia(3145,27,60,1102).
tendencia(3146,8,247,34).
tendencia(3147,17,124,1192).
tendencia(3148,11,288,382).
tendencia(3149,21,84,948).
tendencia(3150,3,98,870).
tendencia(3151,12,156,270).
tendencia(3152,12,220,390).
tendencia(3153,21,105,978).
tendencia(3154,21,299,952).
tendencia(3155,8,154,55).
tendencia(3156,27,234,777).
tendencia(3157,20,185,1207).
tendencia(3158,16,297,965).
tendencia(3159,2,222,237).
tendencia(3160,23,244,772).
tendencia(3161,18,184,731).
tendencia(3162,7,234,1067).
tendencia(3163,18,170,332).
tendencia(3164,19,239,1174).
tendencia(3165,13,116,1107).
tendencia(3166,9,200,783).
tendencia(3167,12,185,1231).
tendencia(3168,26,73,360).
tendencia(3169,16,69,644).
tendencia(3170,18,205,1286).
tendencia(3171,12,145,1283).
tendencia(3172,20,122,989).
tendencia(3173,27,280,564).
tendencia(3174,20,142,1058).
tendencia(3175,20,103,632).
tendencia(3176,10,177,453).
tendencia(3177,23,89,354).
tendencia(3178,2,60,1133).
tendencia(3179,24,139,412).
tendencia(3180,17,94,1116).
tendencia(3181,23,247,1311).
tendencia(3182,7,69,657).
tendencia(3183,17,247,807).
tendencia(3184,13,274,758).
tendencia(3185,24,263,776).
tendencia(3186,6,173,752).
tendencia(3187,27,79,1124).
tendencia(3188,14,231,28).
tendencia(3189,3,273,142).
tendencia(3190,6,300,575).
tendencia(3191,9,68,478).
tendencia(3192,15,270,80).
tendencia(3193,4,134,1292).
tendencia(3194,10,50,817).
tendencia(3195,22,52,1196).
tendencia(3196,1,187,481).
tendencia(3197,2,192,99).
tendencia(3198,3,187,495).
tendencia(3199,24,59,1261).
tendencia(3200,27,120,662).
tendencia(3201,16,132,1145).
tendencia(3202,12,112,860).
tendencia(3203,15,104,325).
tendencia(3204,11,78,1081).
tendencia(3205,21,197,339).
tendencia(3206,20,132,804).
tendencia(3207,17,137,48).
tendencia(3208,14,294,381).
tendencia(3209,14,57,685).
tendencia(3210,14,227,60).
tendencia(3211,8,183,1051).
tendencia(3212,6,250,876).
tendencia(3213,21,281,406).
tendencia(3214,19,260,1080).
tendencia(3215,22,83,44).
tendencia(3216,7,69,672).
tendencia(3217,11,120,688).
tendencia(3218,16,153,42).
tendencia(3219,9,260,945).
tendencia(3220,20,98,426).
tendencia(3221,24,91,475).
tendencia(3222,11,236,321).
tendencia(3223,17,197,1031).
tendencia(3224,18,53,510).
tendencia(3225,9,178,1150).
tendencia(3226,4,126,88).
tendencia(3227,23,164,1199).
tendencia(3228,3,116,1162).
tendencia(3229,4,258,1099).
tendencia(3230,5,81,17).
tendencia(3231,16,225,439).
tendencia(3232,15,107,1144).
tendencia(3233,10,65,1331).
tendencia(3234,21,215,171).
tendencia(3235,5,187,1080).
tendencia(3236,14,236,380).
tendencia(3237,12,51,226).
tendencia(3238,16,231,996).
tendencia(3239,17,207,1304).
tendencia(3240,25,277,363).
tendencia(3241,5,211,1077).
tendencia(3242,11,230,693).
tendencia(3243,7,150,741).
tendencia(3244,2,98,246).
tendencia(3245,27,281,711).
tendencia(3246,13,118,581).
tendencia(3247,14,276,1262).
tendencia(3248,22,144,774).
tendencia(3249,21,195,1042).
tendencia(3250,22,136,591).
tendencia(3251,8,121,982).
tendencia(3252,10,260,554).
tendencia(3253,14,269,989).
tendencia(3254,2,229,415).
tendencia(3255,21,114,632).
tendencia(3256,12,210,109).
tendencia(3257,21,86,559).
tendencia(3258,27,86,326).
tendencia(3259,14,71,445).
tendencia(3260,17,99,319).
tendencia(3261,24,107,1113).
tendencia(3262,1,77,554).
tendencia(3263,15,77,1147).
tendencia(3264,9,234,1199).
tendencia(3265,24,274,1038).
tendencia(3266,2,240,736).
tendencia(3267,13,216,1189).
tendencia(3268,27,52,1218).
tendencia(3269,16,144,246).
tendencia(3270,7,211,634).
tendencia(3271,15,74,232).
tendencia(3272,17,130,657).
tendencia(3273,26,105,374).
tendencia(3274,10,84,107).
tendencia(3275,18,182,937).
tendencia(3276,17,261,726).
tendencia(3277,24,292,314).
tendencia(3278,15,171,1230).
tendencia(3279,27,137,638).
tendencia(3280,6,252,654).
tendencia(3281,3,189,902).
tendencia(3282,13,120,861).
tendencia(3283,5,252,1137).
tendencia(3284,2,200,903).
tendencia(3285,7,281,835).
tendencia(3286,22,274,167).
tendencia(3287,15,175,403).
tendencia(3288,19,270,406).
tendencia(3289,23,99,662).
tendencia(3290,21,230,438).
tendencia(3291,26,181,757).
tendencia(3292,17,127,1239).
tendencia(3293,23,224,1202).
tendencia(3294,3,244,1164).
tendencia(3295,5,116,847).
tendencia(3296,10,89,1003).
tendencia(3297,25,163,305).
tendencia(3298,5,58,101).
tendencia(3299,12,257,365).
tendencia(3300,6,129,1309).
tendencia(3301,23,178,523).
tendencia(3302,8,269,773).
tendencia(3303,17,158,1002).
tendencia(3304,9,297,1244).
tendencia(3305,9,286,1253).
tendencia(3306,20,99,176).
tendencia(3307,19,98,878).
tendencia(3308,21,188,18).
tendencia(3309,9,51,350).
tendencia(3310,23,272,131).
tendencia(3311,2,232,924).
tendencia(3312,20,204,255).
tendencia(3313,3,282,706).
tendencia(3314,13,101,1223).
tendencia(3315,17,123,1152).
tendencia(3316,12,137,539).
tendencia(3317,11,57,115).
tendencia(3318,2,175,439).
tendencia(3319,19,236,500).
tendencia(3320,20,98,1092).
tendencia(3321,21,195,1246).
tendencia(3322,18,55,633).
tendencia(3323,13,195,1186).
tendencia(3324,2,219,1302).
tendencia(3325,20,154,571).
tendencia(3326,5,192,124).
tendencia(3327,10,119,477).
tendencia(3328,7,164,111).
tendencia(3329,3,252,530).
tendencia(3330,13,99,212).
tendencia(3331,21,194,971).
tendencia(3332,17,211,529).
tendencia(3333,16,72,159).
tendencia(3334,9,171,251).
tendencia(3335,12,51,1169).
tendencia(3336,12,233,1160).
tendencia(3337,3,110,1092).
tendencia(3338,21,291,440).
tendencia(3339,1,70,1281).
tendencia(3340,24,300,183).
tendencia(3341,15,157,855).
tendencia(3342,21,224,94).
tendencia(3343,5,190,408).
tendencia(3344,4,177,331).
tendencia(3345,12,140,708).
tendencia(3346,24,56,503).
tendencia(3347,13,241,274).
tendencia(3348,26,296,720).
tendencia(3349,21,161,774).
tendencia(3350,2,287,185).
tendencia(3351,23,51,1122).
tendencia(3352,3,241,1182).
tendencia(3353,1,257,989).
tendencia(3354,8,246,643).
tendencia(3355,17,181,352).
tendencia(3356,20,284,600).
tendencia(3357,12,126,631).
tendencia(3358,12,248,693).
tendencia(3359,23,165,32).
tendencia(3360,6,83,1133).
tendencia(3361,1,65,473).
tendencia(3362,3,286,79).
tendencia(3363,11,97,1237).
tendencia(3364,21,126,1194).
tendencia(3365,12,284,1181).
tendencia(3366,8,144,1179).
tendencia(3367,15,222,670).
tendencia(3368,26,202,126).
tendencia(3369,14,209,616).
tendencia(3370,20,274,338).
tendencia(3371,3,172,401).
tendencia(3372,6,225,1167).
tendencia(3373,18,95,825).
tendencia(3374,9,110,1131).
tendencia(3375,4,241,526).
tendencia(3376,4,262,1021).
tendencia(3377,4,171,94).
tendencia(3378,17,277,1117).
tendencia(3379,12,250,917).
tendencia(3380,8,292,815).
tendencia(3381,22,235,418).
tendencia(3382,13,213,465).
tendencia(3383,14,229,1253).
tendencia(3384,2,163,878).
tendencia(3385,25,144,524).
tendencia(3386,24,190,641).
tendencia(3387,27,63,446).
tendencia(3388,14,291,1095).
tendencia(3389,27,228,1310).
tendencia(3390,12,219,1004).
tendencia(3391,17,140,566).
tendencia(3392,17,83,501).
tendencia(3393,21,287,13).
tendencia(3394,2,251,561).
tendencia(3395,3,86,15).
tendencia(3396,7,243,1302).
tendencia(3397,5,75,1281).
tendencia(3398,26,124,248).
tendencia(3399,8,208,951).
tendencia(3400,6,188,1176).
tendencia(3401,3,76,1296).
tendencia(3402,2,241,365).
tendencia(3403,19,178,1177).
tendencia(3404,5,300,318).
tendencia(3405,3,298,1311).
tendencia(3406,18,284,1207).
tendencia(3407,11,133,425).
tendencia(3408,22,260,1259).
tendencia(3409,18,286,908).
tendencia(3410,24,218,395).
tendencia(3411,14,76,193).
tendencia(3412,20,130,912).
tendencia(3413,10,270,324).
tendencia(3414,16,251,920).
tendencia(3415,27,152,27).
tendencia(3416,6,56,1199).
tendencia(3417,26,207,640).
tendencia(3418,14,213,1054).
tendencia(3419,4,207,631).
tendencia(3420,1,270,728).
tendencia(3421,6,300,1119).
tendencia(3422,17,133,925).
tendencia(3423,1,215,420).
tendencia(3424,17,132,962).
tendencia(3425,23,235,269).
tendencia(3426,21,214,535).
tendencia(3427,18,226,909).
tendencia(3428,27,160,830).
tendencia(3429,25,116,486).
tendencia(3430,3,196,1047).
tendencia(3431,4,282,51).
tendencia(3432,11,253,1181).
tendencia(3433,15,164,632).
tendencia(3434,3,272,677).
tendencia(3435,12,282,1004).
tendencia(3436,1,201,446).
tendencia(3437,20,198,1088).
tendencia(3438,7,212,691).
tendencia(3439,26,237,1266).
tendencia(3440,22,151,304).
tendencia(3441,18,257,753).
tendencia(3442,4,246,230).
tendencia(3443,27,128,426).
tendencia(3444,22,230,32).
tendencia(3445,4,165,1290).
tendencia(3446,11,134,1336).
tendencia(3447,24,227,690).
tendencia(3448,19,151,1088).
tendencia(3449,13,185,42).
tendencia(3450,20,130,1134).
tendencia(3451,8,60,1174).
tendencia(3452,14,128,499).
tendencia(3453,17,161,334).
tendencia(3454,18,286,573).
tendencia(3455,3,68,76).
tendencia(3456,19,189,1331).
tendencia(3457,5,249,417).
tendencia(3458,21,291,1245).
tendencia(3459,3,195,79).
tendencia(3460,19,72,249).
tendencia(3461,2,188,499).
tendencia(3462,14,258,6).
tendencia(3463,2,90,177).
tendencia(3464,9,61,1011).
tendencia(3465,8,194,1060).
tendencia(3466,23,277,378).
tendencia(3467,17,68,501).
tendencia(3468,2,124,1096).
tendencia(3469,8,118,467).
tendencia(3470,16,131,139).
tendencia(3471,22,280,187).
tendencia(3472,4,74,1082).
tendencia(3473,17,207,378).
tendencia(3474,20,293,455).
tendencia(3475,23,78,525).
tendencia(3476,8,200,122).
tendencia(3477,20,100,521).
tendencia(3478,17,100,295).
tendencia(3479,8,293,181).
tendencia(3480,6,270,227).
tendencia(3481,18,67,423).
tendencia(3482,24,186,394).
tendencia(3483,17,179,56).
tendencia(3484,5,241,1008).
tendencia(3485,21,210,373).
tendencia(3486,20,292,1238).
tendencia(3487,24,150,1123).
tendencia(3488,19,229,597).
tendencia(3489,1,131,64).
tendencia(3490,5,295,15).
tendencia(3491,2,221,187).
tendencia(3492,22,212,50).
tendencia(3493,17,95,1049).
tendencia(3494,18,196,1066).
tendencia(3495,2,244,769).
tendencia(3496,11,298,639).
tendencia(3497,15,207,649).
tendencia(3498,7,232,572).
tendencia(3499,19,297,503).
tendencia(3500,18,103,1062).
tendencia(3501,25,125,941).
tendencia(3502,25,93,556).
tendencia(3503,18,249,1297).
tendencia(3504,13,130,232).
tendencia(3505,11,109,1346).
tendencia(3506,11,92,1190).
tendencia(3507,19,106,543).
tendencia(3508,5,85,1055).
tendencia(3509,17,291,774).
tendencia(3510,25,125,907).
tendencia(3511,12,248,568).
tendencia(3512,11,224,386).
tendencia(3513,26,244,560).
tendencia(3514,26,258,761).
tendencia(3515,26,117,625).
tendencia(3516,6,60,1158).
tendencia(3517,18,50,184).
tendencia(3518,15,293,55).
tendencia(3519,11,189,306).
tendencia(3520,26,131,778).
tendencia(3521,15,270,1145).
tendencia(3522,9,89,54).
tendencia(3523,21,300,1197).
tendencia(3524,23,190,966).
tendencia(3525,18,242,739).
tendencia(3526,4,89,1249).
tendencia(3527,11,172,1140).
tendencia(3528,2,288,1033).
tendencia(3529,2,194,462).
tendencia(3530,11,113,710).
tendencia(3531,13,95,411).
tendencia(3532,18,215,537).
tendencia(3533,15,107,294).
tendencia(3534,3,296,833).
tendencia(3535,7,269,182).
tendencia(3536,26,239,1034).
tendencia(3537,3,57,968).
tendencia(3538,9,219,50).
tendencia(3539,26,248,120).
tendencia(3540,27,226,1345).
tendencia(3541,16,64,480).
tendencia(3542,7,245,817).
tendencia(3543,17,115,512).
tendencia(3544,6,197,509).
tendencia(3545,24,73,603).
tendencia(3546,18,126,792).
tendencia(3547,21,187,1154).
tendencia(3548,4,169,1036).
tendencia(3549,17,66,261).
tendencia(3550,12,168,1048).
tendencia(3551,15,238,1302).
tendencia(3552,3,198,1042).
tendencia(3553,21,165,197).
tendencia(3554,1,158,473).
tendencia(3555,26,223,1126).
tendencia(3556,25,165,765).
tendencia(3557,20,53,1002).
tendencia(3558,3,141,870).
tendencia(3559,25,267,787).
tendencia(3560,5,175,361).
tendencia(3561,3,282,512).
tendencia(3562,16,170,551).
tendencia(3563,12,293,1006).
tendencia(3564,22,179,95).
tendencia(3565,24,279,756).
tendencia(3566,25,69,1107).
tendencia(3567,21,234,316).
tendencia(3568,8,80,877).
tendencia(3569,5,190,1292).
tendencia(3570,23,103,1115).
tendencia(3571,17,166,755).
tendencia(3572,25,192,1333).
tendencia(3573,23,270,115).
tendencia(3574,20,131,811).
tendencia(3575,23,241,909).
tendencia(3576,17,251,1188).
tendencia(3577,4,193,1250).
tendencia(3578,19,131,385).
tendencia(3579,20,226,860).
tendencia(3580,11,173,630).
tendencia(3581,16,221,1200).
tendencia(3582,17,63,115).
tendencia(3583,22,142,809).
tendencia(3584,12,209,1297).
tendencia(3585,26,126,38).
tendencia(3586,11,259,625).
tendencia(3587,18,114,831).
tendencia(3588,27,220,447).
tendencia(3589,26,257,180).
tendencia(3590,19,260,1212).
tendencia(3591,20,125,671).
tendencia(3592,23,170,13).
tendencia(3593,9,106,132).
tendencia(3594,19,156,26).
tendencia(3595,25,270,1003).
tendencia(3596,2,248,253).
tendencia(3597,25,108,96).
tendencia(3598,15,126,542).
tendencia(3599,15,82,497).
tendencia(3600,13,287,702).
tendencia(3601,15,142,1221).
tendencia(3602,23,201,1267).
tendencia(3603,25,182,1180).
tendencia(3604,9,133,948).
tendencia(3605,14,207,385).
tendencia(3606,6,295,920).
tendencia(3607,4,296,900).
tendencia(3608,8,94,1209).
tendencia(3609,11,154,108).
tendencia(3610,19,285,639).
tendencia(3611,7,200,951).
tendencia(3612,21,79,517).
tendencia(3613,2,249,323).
tendencia(3614,6,127,43).
tendencia(3615,5,214,134).
tendencia(3616,1,54,934).
tendencia(3617,1,219,9).
tendencia(3618,26,149,935).
tendencia(3619,12,124,1129).
tendencia(3620,8,211,934).
tendencia(3621,27,223,1165).
tendencia(3622,2,84,776).
tendencia(3623,16,161,855).
tendencia(3624,20,58,1243).
tendencia(3625,7,68,649).
tendencia(3626,18,136,67).
tendencia(3627,2,53,1165).
tendencia(3628,13,130,975).
tendencia(3629,27,175,1253).
tendencia(3630,8,99,276).
tendencia(3631,26,108,625).
tendencia(3632,18,107,578).
tendencia(3633,1,191,227).
tendencia(3634,9,209,344).
tendencia(3635,21,227,1184).
tendencia(3636,11,179,281).
tendencia(3637,18,160,497).
tendencia(3638,5,173,993).
tendencia(3639,1,208,30).
tendencia(3640,16,187,822).
tendencia(3641,7,286,57).
tendencia(3642,12,298,963).
tendencia(3643,15,161,541).
tendencia(3644,6,294,346).
tendencia(3645,4,218,126).
tendencia(3646,20,277,384).
tendencia(3647,5,134,1243).
tendencia(3648,10,188,285).
tendencia(3649,5,79,388).
tendencia(3650,2,185,356).
tendencia(3651,6,133,954).
tendencia(3652,9,188,568).
tendencia(3653,16,83,26).
tendencia(3654,12,152,247).
tendencia(3655,16,230,589).
tendencia(3656,6,277,879).
tendencia(3657,17,59,671).
tendencia(3658,1,237,277).
tendencia(3659,3,204,565).
tendencia(3660,1,227,1016).
tendencia(3661,19,126,1133).
tendencia(3662,10,142,625).
tendencia(3663,14,248,445).
tendencia(3664,17,284,1015).
tendencia(3665,17,124,1146).
tendencia(3666,15,57,311).
tendencia(3667,13,226,12).
tendencia(3668,12,137,1175).
tendencia(3669,3,156,970).
tendencia(3670,13,111,322).
tendencia(3671,1,208,946).
tendencia(3672,24,91,305).
tendencia(3673,8,52,122).
tendencia(3674,18,171,234).
tendencia(3675,5,64,356).
tendencia(3676,12,104,1173).
tendencia(3677,23,107,591).
tendencia(3678,10,133,790).
tendencia(3679,19,192,754).
tendencia(3680,26,205,62).
tendencia(3681,27,137,577).
tendencia(3682,18,297,407).
tendencia(3683,3,101,1087).
tendencia(3684,21,189,164).
tendencia(3685,22,91,348).
tendencia(3686,15,240,1321).
tendencia(3687,6,182,574).
tendencia(3688,8,216,801).
tendencia(3689,19,206,341).
tendencia(3690,16,249,226).
tendencia(3691,13,234,179).
tendencia(3692,20,262,483).
tendencia(3693,11,237,1126).
tendencia(3694,7,174,879).
tendencia(3695,2,221,750).
tendencia(3696,16,202,1000).
tendencia(3697,27,127,335).
tendencia(3698,18,130,131).
tendencia(3699,3,85,283).
tendencia(3700,11,113,268).
tendencia(3701,22,282,517).
tendencia(3702,2,79,17).
tendencia(3703,13,198,339).
tendencia(3704,18,295,66).
tendencia(3705,14,279,1032).
tendencia(3706,17,206,353).
tendencia(3707,2,132,1154).
tendencia(3708,7,201,331).
tendencia(3709,8,106,1277).
tendencia(3710,20,212,448).
tendencia(3711,23,72,88).
tendencia(3712,17,54,540).
tendencia(3713,25,277,69).
tendencia(3714,15,79,121).
tendencia(3715,4,219,28).
tendencia(3716,7,292,29).
tendencia(3717,1,279,596).
tendencia(3718,15,146,1304).
tendencia(3719,7,205,836).
tendencia(3720,26,228,414).
tendencia(3721,15,157,7).
tendencia(3722,2,240,105).
tendencia(3723,11,236,723).
tendencia(3724,18,107,1087).
tendencia(3725,23,64,363).
tendencia(3726,6,106,38).
tendencia(3727,11,145,721).
tendencia(3728,21,104,648).
tendencia(3729,1,147,181).
tendencia(3730,22,90,761).
tendencia(3731,15,229,1152).
tendencia(3732,23,168,658).
tendencia(3733,22,281,1072).
tendencia(3734,19,188,1232).
tendencia(3735,5,203,435).
tendencia(3736,22,223,47).
tendencia(3737,23,56,623).
tendencia(3738,2,198,1165).
tendencia(3739,23,82,1042).
tendencia(3740,4,235,288).
tendencia(3741,5,203,1082).
tendencia(3742,16,64,1235).
tendencia(3743,13,183,589).
tendencia(3744,22,108,1246).
tendencia(3745,1,234,1085).
tendencia(3746,11,162,898).
tendencia(3747,6,60,1183).
tendencia(3748,19,125,459).
tendencia(3749,22,158,654).
tendencia(3750,8,238,165).
tendencia(3751,21,247,31).
tendencia(3752,20,192,745).
tendencia(3753,9,88,574).
tendencia(3754,25,101,566).
tendencia(3755,20,229,201).
tendencia(3756,16,227,1202).
tendencia(3757,26,292,963).
tendencia(3758,12,294,844).
tendencia(3759,4,237,190).
tendencia(3760,3,201,113).
tendencia(3761,22,67,1159).
tendencia(3762,10,256,280).
tendencia(3763,1,167,511).
tendencia(3764,1,241,449).
tendencia(3765,4,164,176).
tendencia(3766,19,209,123).
tendencia(3767,3,130,945).
tendencia(3768,9,206,965).
tendencia(3769,24,264,1030).
tendencia(3770,19,85,1002).
tendencia(3771,21,129,391).
tendencia(3772,21,109,215).
tendencia(3773,1,273,193).
tendencia(3774,22,274,675).
tendencia(3775,7,295,446).
tendencia(3776,26,196,402).
tendencia(3777,26,236,191).
tendencia(3778,3,106,829).
tendencia(3779,5,146,2).
tendencia(3780,4,150,703).
tendencia(3781,17,113,356).
tendencia(3782,22,197,160).
tendencia(3783,19,150,1143).
tendencia(3784,4,124,393).
tendencia(3785,26,92,109).
tendencia(3786,24,146,798).
tendencia(3787,17,248,747).
tendencia(3788,20,179,580).
tendencia(3789,1,213,1034).
tendencia(3790,7,237,988).
tendencia(3791,13,251,10).
tendencia(3792,13,94,666).
tendencia(3793,18,226,45).
tendencia(3794,15,128,1233).
tendencia(3795,13,245,1065).
tendencia(3796,6,207,228).
tendencia(3797,20,279,599).
tendencia(3798,18,177,1028).
tendencia(3799,19,167,239).
tendencia(3800,12,201,710).
tendencia(3801,2,71,198).
tendencia(3802,22,218,908).
tendencia(3803,6,197,923).
tendencia(3804,7,137,282).
tendencia(3805,4,54,488).
tendencia(3806,12,232,938).
tendencia(3807,10,226,151).
tendencia(3808,25,109,1030).
tendencia(3809,19,68,998).
tendencia(3810,15,221,1117).
tendencia(3811,19,238,126).
tendencia(3812,19,227,806).
tendencia(3813,1,243,618).
tendencia(3814,16,227,86).
tendencia(3815,13,133,806).
tendencia(3816,21,241,160).
tendencia(3817,21,212,850).
tendencia(3818,18,58,1135).
tendencia(3819,13,92,227).
tendencia(3820,23,273,10).
tendencia(3821,8,197,1233).
tendencia(3822,15,248,636).
tendencia(3823,11,175,344).
tendencia(3824,10,84,362).
tendencia(3825,4,83,15).
tendencia(3826,19,88,433).
tendencia(3827,25,193,1195).
tendencia(3828,16,283,950).
tendencia(3829,12,172,209).
tendencia(3830,7,140,1300).
tendencia(3831,9,205,820).
tendencia(3832,1,216,535).
tendencia(3833,3,50,1189).
tendencia(3834,19,105,635).
tendencia(3835,17,155,971).
tendencia(3836,26,263,911).
tendencia(3837,5,90,1151).
tendencia(3838,5,129,1034).
tendencia(3839,6,122,155).
tendencia(3840,10,271,1193).
tendencia(3841,21,296,872).
tendencia(3842,11,298,1073).
tendencia(3843,2,60,758).
tendencia(3844,15,121,568).
tendencia(3845,17,216,1076).
tendencia(3846,2,282,1036).
tendencia(3847,13,62,894).
tendencia(3848,3,60,917).
tendencia(3849,20,169,1207).
tendencia(3850,15,224,112).
tendencia(3851,3,66,47).
tendencia(3852,4,287,1309).
tendencia(3853,13,259,578).
tendencia(3854,7,265,611).
tendencia(3855,15,258,40).
tendencia(3856,7,83,449).
tendencia(3857,20,170,984).
tendencia(3858,1,289,84).
tendencia(3859,25,227,74).
tendencia(3860,27,288,1102).
tendencia(3861,23,176,1292).
tendencia(3862,26,298,259).
tendencia(3863,8,268,188).
tendencia(3864,24,76,120).
tendencia(3865,13,269,188).
tendencia(3866,25,130,1278).
tendencia(3867,26,226,339).
tendencia(3868,12,273,700).
tendencia(3869,13,248,548).
tendencia(3870,16,286,1140).
tendencia(3871,20,253,991).
tendencia(3872,17,84,699).
tendencia(3873,1,94,648).
tendencia(3874,11,184,739).
tendencia(3875,21,253,977).
tendencia(3876,16,218,67).
tendencia(3877,22,74,656).
tendencia(3878,16,133,533).
tendencia(3879,19,261,899).
tendencia(3880,24,60,386).
tendencia(3881,20,93,499).
tendencia(3882,11,166,9).
tendencia(3883,22,75,489).
tendencia(3884,14,238,1064).
tendencia(3885,9,190,227).
tendencia(3886,5,128,397).
tendencia(3887,18,180,414).
tendencia(3888,10,70,488).
tendencia(3889,17,147,1075).
tendencia(3890,14,170,348).
tendencia(3891,10,220,716).
tendencia(3892,4,278,454).
tendencia(3893,1,258,268).
tendencia(3894,9,283,1262).
tendencia(3895,4,77,967).
tendencia(3896,27,271,974).
tendencia(3897,7,137,1036).
tendencia(3898,18,132,570).
tendencia(3899,9,105,366).
tendencia(3900,23,119,1269).
tendencia(3901,16,151,492).
tendencia(3902,14,69,159).
tendencia(3903,18,160,720).
tendencia(3904,19,279,958).
tendencia(3905,19,103,1238).
tendencia(3906,14,218,792).
tendencia(3907,1,246,1260).
tendencia(3908,27,294,317).
tendencia(3909,23,237,737).
tendencia(3910,12,271,1333).
tendencia(3911,17,267,1113).
tendencia(3912,12,157,93).
tendencia(3913,8,193,558).
tendencia(3914,8,261,365).
tendencia(3915,21,167,492).
tendencia(3916,19,209,1342).
tendencia(3917,15,74,618).
tendencia(3918,19,123,897).
tendencia(3919,2,152,1197).
tendencia(3920,7,208,349).
tendencia(3921,10,291,1279).
tendencia(3922,20,207,556).
tendencia(3923,27,266,871).
tendencia(3924,12,88,566).
tendencia(3925,1,116,1274).
tendencia(3926,10,275,635).
tendencia(3927,25,106,147).
tendencia(3928,27,193,180).
tendencia(3929,18,104,396).
tendencia(3930,25,231,1178).
tendencia(3931,22,205,844).
tendencia(3932,19,263,748).
tendencia(3933,25,136,975).
tendencia(3934,20,62,193).
tendencia(3935,6,110,4).
tendencia(3936,6,152,326).
tendencia(3937,7,86,1190).
tendencia(3938,15,297,923).
tendencia(3939,19,181,223).
tendencia(3940,11,220,320).
tendencia(3941,24,65,153).
tendencia(3942,24,135,399).
tendencia(3943,11,286,254).
tendencia(3944,6,162,232).
tendencia(3945,16,214,190).
tendencia(3946,10,241,709).
tendencia(3947,5,134,570).
tendencia(3948,6,264,420).
tendencia(3949,11,88,1055).
tendencia(3950,26,117,1094).
tendencia(3951,9,52,238).
tendencia(3952,5,175,538).
tendencia(3953,15,158,227).
tendencia(3954,17,111,492).
tendencia(3955,7,237,1285).
tendencia(3956,17,276,791).
tendencia(3957,24,138,914).
tendencia(3958,12,290,95).
tendencia(3959,4,97,596).
tendencia(3960,2,157,318).
tendencia(3961,24,285,702).
tendencia(3962,14,276,1013).
tendencia(3963,6,283,523).
tendencia(3964,21,52,1238).
tendencia(3965,2,58,917).
tendencia(3966,23,53,1163).
tendencia(3967,13,202,227).
tendencia(3968,3,196,303).
tendencia(3969,7,58,122).
tendencia(3970,17,126,1283).
tendencia(3971,10,213,784).
tendencia(3972,27,240,1088).
tendencia(3973,18,176,817).
tendencia(3974,7,158,272).
tendencia(3975,22,141,1187).
tendencia(3976,3,120,1113).
tendencia(3977,12,257,894).
tendencia(3978,9,111,80).
tendencia(3979,8,204,206).
tendencia(3980,10,243,463).
tendencia(3981,27,280,1140).
tendencia(3982,8,254,244).
tendencia(3983,27,155,653).
tendencia(3984,7,271,332).
tendencia(3985,1,282,164).
tendencia(3986,22,266,281).
tendencia(3987,7,157,1190).
tendencia(3988,6,57,915).
tendencia(3989,9,273,789).
tendencia(3990,20,196,891).
tendencia(3991,11,142,487).
tendencia(3992,14,268,766).
tendencia(3993,23,169,704).
tendencia(3994,17,125,1038).
tendencia(3995,1,109,891).
tendencia(3996,27,233,1306).
tendencia(3997,3,231,666).
tendencia(3998,15,122,1329).
tendencia(3999,3,201,286).
tendencia(4000,16,264,843).
tendencia(4001,6,299,898).
tendencia(4002,22,78,1011).
tendencia(4003,12,107,1200).
tendencia(4004,18,216,18).
tendencia(4005,17,216,821).
tendencia(4006,23,273,1031).
tendencia(4007,25,206,198).
tendencia(4008,2,196,417).
tendencia(4009,3,136,154).
tendencia(4010,6,79,686).
tendencia(4011,9,164,369).
tendencia(4012,6,214,1201).
tendencia(4013,12,155,714).
tendencia(4014,10,287,1242).
tendencia(4015,3,134,174).
tendencia(4016,18,193,756).
tendencia(4017,4,135,750).
tendencia(4018,2,179,1261).
tendencia(4019,17,247,199).
tendencia(4020,9,124,303).
tendencia(4021,16,203,602).
tendencia(4022,21,287,67).
tendencia(4023,23,203,1066).
tendencia(4024,7,73,656).
tendencia(4025,3,142,73).
tendencia(4026,3,80,360).
tendencia(4027,24,173,827).
tendencia(4028,24,293,441).
tendencia(4029,24,279,715).
tendencia(4030,5,151,857).
tendencia(4031,21,260,729).
tendencia(4032,19,262,1272).
tendencia(4033,27,162,427).
tendencia(4034,20,182,175).
tendencia(4035,27,267,331).
tendencia(4036,18,209,1306).
tendencia(4037,25,83,289).
tendencia(4038,2,265,121).
tendencia(4039,24,85,442).
tendencia(4040,7,82,481).
tendencia(4041,8,170,971).
tendencia(4042,16,300,1039).
tendencia(4043,7,243,507).
tendencia(4044,10,246,218).
tendencia(4045,5,197,995).
tendencia(4046,21,212,60).
tendencia(4047,25,183,1334).
tendencia(4048,14,201,1004).
tendencia(4049,7,264,68).
tendencia(4050,25,288,647).
tendencia(4051,18,289,631).
tendencia(4052,20,232,886).
tendencia(4053,11,208,476).
tendencia(4054,15,206,834).
tendencia(4055,24,105,497).
tendencia(4056,11,87,413).
tendencia(4057,26,82,871).
tendencia(4058,20,106,1072).
tendencia(4059,17,234,1128).
tendencia(4060,6,115,777).
tendencia(4061,8,88,808).
tendencia(4062,18,196,209).
tendencia(4063,21,289,850).
tendencia(4064,14,75,252).
tendencia(4065,23,107,942).
tendencia(4066,26,65,18).
tendencia(4067,15,157,762).
tendencia(4068,13,71,374).
tendencia(4069,19,211,399).
tendencia(4070,24,250,649).
tendencia(4071,26,116,837).
tendencia(4072,4,211,1028).
tendencia(4073,1,92,1158).
tendencia(4074,21,172,1323).
tendencia(4075,8,179,447).
tendencia(4076,12,153,1247).
tendencia(4077,21,130,812).
tendencia(4078,6,79,739).
tendencia(4079,12,134,323).
tendencia(4080,25,92,74).
tendencia(4081,6,86,1210).
tendencia(4082,14,125,764).
tendencia(4083,5,66,805).
tendencia(4084,11,206,1188).
tendencia(4085,13,157,911).
tendencia(4086,9,134,135).
tendencia(4087,9,85,1282).
tendencia(4088,21,181,525).
tendencia(4089,10,120,252).
tendencia(4090,13,170,715).
tendencia(4091,4,139,863).
tendencia(4092,18,117,623).
tendencia(4093,24,59,712).
tendencia(4094,19,261,117).
tendencia(4095,25,83,488).
tendencia(4096,12,255,1118).
tendencia(4097,27,209,528).
tendencia(4098,19,128,870).
tendencia(4099,7,110,431).
tendencia(4100,20,77,693).
tendencia(4101,6,173,859).
tendencia(4102,10,195,89).
tendencia(4103,25,228,31).
tendencia(4104,8,109,154).
tendencia(4105,19,104,143).
tendencia(4106,7,223,868).
tendencia(4107,12,236,821).
tendencia(4108,25,157,405).
tendencia(4109,2,271,831).
tendencia(4110,25,233,203).
tendencia(4111,4,189,1309).
tendencia(4112,23,283,429).
tendencia(4113,10,122,529).
tendencia(4114,1,281,1051).
tendencia(4115,13,233,1057).
tendencia(4116,26,105,356).
tendencia(4117,22,273,1294).
tendencia(4118,12,127,238).
tendencia(4119,1,236,602).
tendencia(4120,9,282,685).
tendencia(4121,14,80,912).
tendencia(4122,23,179,766).
tendencia(4123,15,94,1047).
tendencia(4124,23,135,500).
tendencia(4125,12,227,1235).
tendencia(4126,15,92,1346).
tendencia(4127,20,81,1049).
tendencia(4128,21,200,631).
tendencia(4129,12,154,973).
tendencia(4130,15,261,405).
tendencia(4131,13,236,1094).
tendencia(4132,5,180,250).
tendencia(4133,27,236,1221).
tendencia(4134,11,237,129).
tendencia(4135,26,90,1124).
tendencia(4136,2,169,767).
tendencia(4137,26,167,792).
tendencia(4138,19,77,838).
tendencia(4139,9,105,505).
tendencia(4140,9,267,69).
tendencia(4141,23,238,70).
tendencia(4142,26,84,743).
tendencia(4143,7,191,169).
tendencia(4144,13,162,868).
tendencia(4145,26,196,185).
tendencia(4146,1,128,48).
tendencia(4147,19,51,483).
tendencia(4148,12,160,428).
tendencia(4149,19,245,242).
tendencia(4150,16,55,794).
tendencia(4151,25,201,980).
tendencia(4152,5,90,980).
tendencia(4153,2,116,659).
tendencia(4154,14,240,649).
tendencia(4155,2,50,361).
tendencia(4156,11,69,83).
tendencia(4157,11,146,566).
tendencia(4158,4,256,769).
tendencia(4159,25,165,671).
tendencia(4160,23,134,1274).
tendencia(4161,14,276,709).
tendencia(4162,21,76,1029).
tendencia(4163,25,233,1250).
tendencia(4164,21,220,88).
tendencia(4165,8,126,641).
tendencia(4166,5,190,1166).
tendencia(4167,9,72,681).
tendencia(4168,17,127,54).
tendencia(4169,18,244,245).
tendencia(4170,11,132,1130).
tendencia(4171,8,90,549).
tendencia(4172,4,92,919).
tendencia(4173,10,209,1066).
tendencia(4174,9,273,229).
tendencia(4175,21,299,391).
tendencia(4176,15,284,1102).
tendencia(4177,13,300,709).
tendencia(4178,7,80,964).
tendencia(4179,12,196,65).
tendencia(4180,3,219,939).
tendencia(4181,3,124,856).
tendencia(4182,19,130,675).
tendencia(4183,21,246,12).
tendencia(4184,21,92,53).
tendencia(4185,24,149,998).
tendencia(4186,22,50,841).
tendencia(4187,26,206,645).
tendencia(4188,5,206,55).
tendencia(4189,21,278,334).
tendencia(4190,14,206,371).
tendencia(4191,4,238,368).
tendencia(4192,12,190,43).
tendencia(4193,3,298,690).
tendencia(4194,11,273,625).
tendencia(4195,25,239,429).
tendencia(4196,24,88,573).
tendencia(4197,14,86,651).
tendencia(4198,2,172,467).
tendencia(4199,10,125,448).
tendencia(4200,14,170,513).
tendencia(4201,12,160,1217).
tendencia(4202,4,137,914).
tendencia(4203,26,179,706).
tendencia(4204,7,199,1049).
tendencia(4205,6,66,453).
tendencia(4206,15,292,688).
tendencia(4207,10,249,71).
tendencia(4208,2,98,617).
tendencia(4209,9,224,238).
tendencia(4210,24,117,194).
tendencia(4211,20,130,1313).
tendencia(4212,16,139,212).
tendencia(4213,4,192,288).
tendencia(4214,7,285,980).
tendencia(4215,14,178,290).
tendencia(4216,4,168,1007).
tendencia(4217,27,153,68).
tendencia(4218,25,86,647).
tendencia(4219,8,149,30).
tendencia(4220,3,76,816).
tendencia(4221,16,255,25).
tendencia(4222,25,191,1235).
tendencia(4223,10,70,267).
tendencia(4224,6,102,129).
tendencia(4225,13,253,470).
tendencia(4226,20,113,649).
tendencia(4227,3,165,1004).
tendencia(4228,6,160,1036).
tendencia(4229,10,195,150).
tendencia(4230,20,55,559).
tendencia(4231,12,288,561).
tendencia(4232,10,229,1018).
tendencia(4233,3,146,947).
tendencia(4234,11,219,379).
tendencia(4235,18,112,954).
tendencia(4236,21,160,1117).
tendencia(4237,18,128,51).
tendencia(4238,25,262,309).
tendencia(4239,6,139,1239).
tendencia(4240,7,185,1105).
tendencia(4241,6,231,963).
tendencia(4242,18,280,184).
tendencia(4243,23,134,15).
tendencia(4244,6,285,128).
tendencia(4245,1,238,880).
tendencia(4246,10,267,383).
tendencia(4247,9,164,279).
tendencia(4248,2,103,208).
tendencia(4249,5,249,865).
tendencia(4250,5,123,890).
tendencia(4251,10,60,234).
tendencia(4252,16,294,422).
tendencia(4253,25,143,62).
tendencia(4254,25,268,922).
tendencia(4255,14,193,492).
tendencia(4256,8,180,1173).
tendencia(4257,6,298,652).
tendencia(4258,6,101,1173).
tendencia(4259,25,271,9).
tendencia(4260,8,198,1079).
tendencia(4261,11,297,425).
tendencia(4262,15,95,663).
tendencia(4263,23,260,43).
tendencia(4264,13,272,1058).
tendencia(4265,18,62,413).
tendencia(4266,6,247,194).
tendencia(4267,15,160,1016).
tendencia(4268,20,170,669).
tendencia(4269,15,265,1143).
tendencia(4270,7,189,1160).
tendencia(4271,18,105,1178).
tendencia(4272,13,180,358).
tendencia(4273,13,94,129).
tendencia(4274,4,206,76).
tendencia(4275,12,67,607).
tendencia(4276,10,187,1228).
tendencia(4277,18,126,671).
tendencia(4278,19,255,737).
tendencia(4279,24,210,128).
tendencia(4280,16,278,218).
tendencia(4281,7,181,1158).
tendencia(4282,1,282,796).
tendencia(4283,21,52,606).
tendencia(4284,8,221,125).
tendencia(4285,19,90,333).
tendencia(4286,5,164,868).
tendencia(4287,1,268,414).
tendencia(4288,15,155,941).
tendencia(4289,18,166,68).
tendencia(4290,9,180,115).
tendencia(4291,15,252,1307).
tendencia(4292,14,263,1099).
tendencia(4293,23,152,234).
tendencia(4294,20,66,1000).
tendencia(4295,23,209,859).
tendencia(4296,6,275,667).
tendencia(4297,2,222,841).
tendencia(4298,4,232,250).
tendencia(4299,25,204,1341).
tendencia(4300,19,168,853).
tendencia(4301,27,288,13).
tendencia(4302,17,277,632).
tendencia(4303,11,178,240).
tendencia(4304,7,103,421).
tendencia(4305,24,247,741).
tendencia(4306,26,192,163).
tendencia(4307,14,74,765).
tendencia(4308,8,87,685).
tendencia(4309,1,158,1185).
tendencia(4310,27,139,1033).
tendencia(4311,8,257,213).
tendencia(4312,23,224,209).
tendencia(4313,9,259,861).
tendencia(4314,10,236,867).
tendencia(4315,23,77,1231).
tendencia(4316,18,246,1044).
tendencia(4317,4,254,1023).
tendencia(4318,13,230,1016).
tendencia(4319,16,229,969).
tendencia(4320,7,75,367).
tendencia(4321,3,207,175).
tendencia(4322,25,277,328).
tendencia(4323,5,133,1219).
tendencia(4324,6,159,953).
tendencia(4325,2,232,674).
tendencia(4326,3,250,609).
tendencia(4327,12,273,275).
tendencia(4328,27,283,128).
tendencia(4329,12,150,379).
tendencia(4330,12,284,76).
tendencia(4331,6,226,1341).
tendencia(4332,15,170,1107).
tendencia(4333,2,263,769).
tendencia(4334,20,129,701).
tendencia(4335,1,252,601).
tendencia(4336,8,220,1080).
tendencia(4337,13,182,1191).
tendencia(4338,18,143,1320).
tendencia(4339,5,140,408).
tendencia(4340,3,255,575).
tendencia(4341,26,116,196).
tendencia(4342,22,157,424).
tendencia(4343,19,212,635).
tendencia(4344,9,291,1219).
tendencia(4345,1,113,692).
tendencia(4346,23,258,1099).
tendencia(4347,13,141,1108).
tendencia(4348,1,52,39).
tendencia(4349,3,224,510).
tendencia(4350,21,95,1232).
tendencia(4351,2,103,603).
tendencia(4352,4,287,1328).
tendencia(4353,9,236,771).
tendencia(4354,10,104,739).
tendencia(4355,26,233,767).
tendencia(4356,12,250,1312).
tendencia(4357,13,170,1054).
tendencia(4358,12,196,979).
tendencia(4359,16,155,1114).
tendencia(4360,8,185,1187).
tendencia(4361,11,115,106).
tendencia(4362,1,59,850).
tendencia(4363,20,152,1198).
tendencia(4364,3,111,310).
tendencia(4365,15,60,368).
tendencia(4366,2,275,1238).
tendencia(4367,15,201,206).
tendencia(4368,6,104,60).
tendencia(4369,20,99,1056).
tendencia(4370,7,156,20).
tendencia(4371,7,279,993).
tendencia(4372,12,63,1057).
tendencia(4373,21,55,825).
tendencia(4374,4,268,90).
tendencia(4375,7,81,292).
tendencia(4376,15,51,246).
tendencia(4377,7,223,641).
tendencia(4378,7,95,876).
tendencia(4379,27,207,924).
tendencia(4380,7,135,1072).
tendencia(4381,11,142,834).
tendencia(4382,19,65,69).
tendencia(4383,7,221,140).
tendencia(4384,4,222,1034).
tendencia(4385,25,289,209).
tendencia(4386,17,200,974).
tendencia(4387,6,107,709).
tendencia(4388,19,118,58).
tendencia(4389,11,297,801).
tendencia(4390,2,254,631).
tendencia(4391,5,127,1344).
tendencia(4392,22,60,862).
tendencia(4393,14,175,101).
tendencia(4394,11,170,225).
tendencia(4395,14,143,660).
tendencia(4396,23,233,508).
tendencia(4397,12,151,320).
tendencia(4398,23,64,361).
tendencia(4399,19,94,871).
tendencia(4400,15,292,507).
tendencia(4401,22,243,1293).
tendencia(4402,20,170,605).
tendencia(4403,25,196,538).
tendencia(4404,2,257,358).
tendencia(4405,14,72,1157).
tendencia(4406,17,152,282).
tendencia(4407,10,209,609).
tendencia(4408,1,247,982).
tendencia(4409,23,292,21).
tendencia(4410,15,290,990).
tendencia(4411,4,156,417).
tendencia(4412,22,215,354).
tendencia(4413,16,85,422).
tendencia(4414,6,60,737).
tendencia(4415,17,294,587).
tendencia(4416,20,221,1290).
tendencia(4417,13,70,1169).
tendencia(4418,16,84,72).
tendencia(4419,1,214,704).
tendencia(4420,25,196,360).
tendencia(4421,6,289,407).
tendencia(4422,6,290,800).
tendencia(4423,18,191,276).
tendencia(4424,18,156,732).
tendencia(4425,7,249,983).
tendencia(4426,16,271,32).
tendencia(4427,3,218,979).
tendencia(4428,26,85,754).
tendencia(4429,5,170,1335).
tendencia(4430,14,245,432).
tendencia(4431,20,129,664).
tendencia(4432,12,156,680).
tendencia(4433,15,211,1138).
tendencia(4434,16,176,1257).
tendencia(4435,19,88,368).
tendencia(4436,27,83,751).
tendencia(4437,6,123,59).
tendencia(4438,1,52,156).
tendencia(4439,15,295,1260).
tendencia(4440,20,293,911).
tendencia(4441,16,86,1160).
tendencia(4442,22,107,215).
tendencia(4443,4,214,503).
tendencia(4444,5,292,159).
tendencia(4445,11,241,265).
tendencia(4446,2,254,123).
tendencia(4447,25,140,456).
tendencia(4448,16,201,796).
tendencia(4449,2,293,163).
tendencia(4450,20,101,565).
tendencia(4451,4,156,1341).
tendencia(4452,8,195,55).
tendencia(4453,25,84,888).
tendencia(4454,1,163,1328).
tendencia(4455,18,246,12).
tendencia(4456,12,176,1187).
tendencia(4457,13,108,860).
tendencia(4458,19,207,899).
tendencia(4459,27,141,797).
tendencia(4460,10,177,556).
tendencia(4461,8,180,1081).
tendencia(4462,6,71,919).
tendencia(4463,19,154,1077).
tendencia(4464,1,85,6).
tendencia(4465,18,281,207).
tendencia(4466,5,228,549).
tendencia(4467,14,162,1108).
tendencia(4468,7,163,208).
tendencia(4469,3,273,107).
tendencia(4470,2,261,612).
tendencia(4471,23,124,997).
tendencia(4472,14,264,1248).
tendencia(4473,9,230,492).
tendencia(4474,22,251,434).
tendencia(4475,6,157,310).
tendencia(4476,25,122,766).
tendencia(4477,27,110,737).
tendencia(4478,25,63,702).
tendencia(4479,24,237,1235).
tendencia(4480,21,208,1086).
tendencia(4481,18,143,362).
tendencia(4482,6,110,1200).
tendencia(4483,13,122,125).
tendencia(4484,24,296,599).
tendencia(4485,24,147,1019).
tendencia(4486,22,154,59).
tendencia(4487,1,230,814).
tendencia(4488,22,121,1321).
tendencia(4489,17,164,641).
tendencia(4490,10,136,1242).
tendencia(4491,9,286,725).
tendencia(4492,17,171,161).
tendencia(4493,1,155,528).
tendencia(4494,19,99,1159).
tendencia(4495,9,202,321).
tendencia(4496,10,197,259).
tendencia(4497,24,54,1184).
tendencia(4498,27,292,347).
tendencia(4499,11,244,1163).
tendencia(4500,4,72,554).
tendencia(4501,24,190,89).
tendencia(4502,5,160,900).
tendencia(4503,11,249,933).
tendencia(4504,15,79,1035).
tendencia(4505,24,85,518).
tendencia(4506,3,147,660).
tendencia(4507,25,182,1072).
tendencia(4508,23,196,652).
tendencia(4509,3,97,578).
tendencia(4510,26,166,541).
tendencia(4511,27,134,218).
tendencia(4512,14,89,405).
tendencia(4513,2,138,394).
tendencia(4514,9,189,339).
tendencia(4515,26,151,891).
tendencia(4516,21,278,403).
tendencia(4517,22,102,173).
tendencia(4518,22,268,377).
tendencia(4519,27,92,1099).
tendencia(4520,17,187,258).
tendencia(4521,18,63,548).
tendencia(4522,21,165,538).
tendencia(4523,7,247,956).
tendencia(4524,26,244,1230).
tendencia(4525,11,241,1172).
tendencia(4526,8,143,473).
tendencia(4527,21,90,653).
tendencia(4528,18,254,537).
tendencia(4529,10,151,1195).
tendencia(4530,15,206,560).
tendencia(4531,2,274,876).
tendencia(4532,7,125,1307).
tendencia(4533,2,236,633).
tendencia(4534,4,175,489).
tendencia(4535,18,98,310).
tendencia(4536,19,60,910).
tendencia(4537,23,169,1066).
tendencia(4538,26,60,982).
tendencia(4539,26,110,208).
tendencia(4540,19,84,960).
tendencia(4541,18,238,144).
tendencia(4542,15,192,1138).
tendencia(4543,18,107,189).
tendencia(4544,16,100,1075).
tendencia(4545,24,79,1078).
tendencia(4546,6,134,934).
tendencia(4547,3,218,491).
tendencia(4548,25,254,798).
tendencia(4549,4,261,1332).
tendencia(4550,23,94,1134).
tendencia(4551,3,259,894).
tendencia(4552,16,242,41).
tendencia(4553,17,300,793).
tendencia(4554,9,154,329).
tendencia(4555,8,222,1267).
tendencia(4556,3,118,499).
tendencia(4557,1,193,922).
tendencia(4558,27,179,64).
tendencia(4559,21,210,645).
tendencia(4560,13,166,1089).
tendencia(4561,3,126,103).
tendencia(4562,5,121,1136).
tendencia(4563,18,183,173).
tendencia(4564,4,265,896).
tendencia(4565,21,180,1130).
tendencia(4566,16,189,722).
tendencia(4567,20,298,501).
tendencia(4568,9,257,838).
tendencia(4569,2,106,742).
tendencia(4570,9,97,1288).
tendencia(4571,2,81,1208).
tendencia(4572,19,178,1040).
tendencia(4573,11,192,512).
tendencia(4574,25,288,1304).
tendencia(4575,26,266,1159).
tendencia(4576,2,77,333).
tendencia(4577,18,153,72).
tendencia(4578,19,145,511).
tendencia(4579,1,145,8).
tendencia(4580,27,147,366).
tendencia(4581,6,121,1284).
tendencia(4582,24,242,867).
tendencia(4583,19,66,79).
tendencia(4584,10,147,696).
tendencia(4585,22,133,695).
tendencia(4586,5,174,1081).
tendencia(4587,25,129,495).
tendencia(4588,27,145,483).
tendencia(4589,25,156,896).
tendencia(4590,25,259,183).
tendencia(4591,24,88,565).
tendencia(4592,14,139,1338).
tendencia(4593,8,270,997).
tendencia(4594,9,113,662).
tendencia(4595,5,148,816).
tendencia(4596,6,85,565).
tendencia(4597,26,272,215).
tendencia(4598,24,188,584).
tendencia(4599,24,276,767).
tendencia(4600,26,86,171).
tendencia(4601,17,226,114).
tendencia(4602,2,220,849).
tendencia(4603,15,263,174).
tendencia(4604,20,200,399).
tendencia(4605,6,55,1044).
tendencia(4606,3,84,503).
tendencia(4607,3,100,1301).
tendencia(4608,8,221,575).
tendencia(4609,9,63,635).
tendencia(4610,8,82,1322).
tendencia(4611,15,68,424).
tendencia(4612,19,76,416).
tendencia(4613,27,239,787).
tendencia(4614,5,144,424).
tendencia(4615,13,174,848).
tendencia(4616,5,275,538).
tendencia(4617,6,264,158).
tendencia(4618,2,52,1346).
tendencia(4619,8,288,510).
tendencia(4620,17,275,772).
tendencia(4621,17,290,1170).
tendencia(4622,8,178,796).
tendencia(4623,10,107,446).
tendencia(4624,27,265,269).
tendencia(4625,17,183,823).
tendencia(4626,11,271,1146).
tendencia(4627,21,260,1024).
tendencia(4628,7,299,584).
tendencia(4629,2,171,65).
tendencia(4630,15,233,846).
tendencia(4631,25,287,846).
tendencia(4632,14,220,784).
tendencia(4633,25,205,277).
tendencia(4634,24,51,659).
tendencia(4635,27,193,599).
tendencia(4636,11,62,1143).
tendencia(4637,26,191,944).
tendencia(4638,24,280,20).
tendencia(4639,5,68,1167).
tendencia(4640,12,291,84).
tendencia(4641,5,267,1089).
tendencia(4642,7,165,645).
tendencia(4643,21,275,803).
tendencia(4644,7,106,968).
tendencia(4645,12,119,1235).
tendencia(4646,25,149,1233).
tendencia(4647,27,169,498).
tendencia(4648,22,246,183).
tendencia(4649,15,297,413).
tendencia(4650,12,195,1093).
tendencia(4651,9,229,38).
tendencia(4652,3,177,803).
tendencia(4653,12,272,96).
tendencia(4654,24,63,616).
tendencia(4655,26,76,113).
tendencia(4656,8,208,1185).
tendencia(4657,6,135,138).
tendencia(4658,20,83,1131).
tendencia(4659,4,285,607).
tendencia(4660,9,288,827).
tendencia(4661,12,143,22).
tendencia(4662,16,192,1128).
tendencia(4663,24,152,124).
tendencia(4664,20,248,1001).
tendencia(4665,25,153,501).
tendencia(4666,11,186,651).
tendencia(4667,17,102,155).
tendencia(4668,12,267,316).
tendencia(4669,3,174,796).
tendencia(4670,19,210,50).
tendencia(4671,17,131,734).
tendencia(4672,8,134,366).
tendencia(4673,19,213,965).
tendencia(4674,7,59,325).
tendencia(4675,12,104,685).
tendencia(4676,4,267,778).
tendencia(4677,22,215,519).
tendencia(4678,24,147,1146).
tendencia(4679,17,184,182).
tendencia(4680,25,220,289).
tendencia(4681,11,52,272).
tendencia(4682,25,283,999).
tendencia(4683,1,111,1095).
tendencia(4684,2,124,67).
tendencia(4685,1,294,1076).
tendencia(4686,14,280,931).
tendencia(4687,11,54,217).
tendencia(4688,13,119,609).
tendencia(4689,10,193,919).
tendencia(4690,16,273,739).
tendencia(4691,26,208,547).
tendencia(4692,7,183,1214).
tendencia(4693,15,201,364).
tendencia(4694,15,123,862).
tendencia(4695,10,129,124).
tendencia(4696,11,132,1202).
tendencia(4697,12,288,422).
tendencia(4698,4,125,101).
tendencia(4699,7,298,223).
tendencia(4700,21,150,829).
tendencia(4701,6,220,270).
tendencia(4702,12,139,986).
tendencia(4703,23,124,972).
tendencia(4704,16,99,523).
tendencia(4705,11,172,124).
tendencia(4706,2,274,555).
tendencia(4707,5,251,146).
tendencia(4708,6,285,425).
tendencia(4709,3,104,686).
tendencia(4710,3,245,1071).
tendencia(4711,4,234,1249).
tendencia(4712,23,246,1197).
tendencia(4713,22,109,391).
tendencia(4714,22,293,152).
tendencia(4715,19,110,89).
tendencia(4716,24,219,2).
tendencia(4717,25,190,362).
tendencia(4718,23,141,909).
tendencia(4719,13,178,1037).
tendencia(4720,10,79,270).
tendencia(4721,17,213,1200).
tendencia(4722,11,248,1027).
tendencia(4723,21,279,776).
tendencia(4724,18,183,16).
tendencia(4725,5,70,11).
tendencia(4726,24,293,1252).
tendencia(4727,4,207,1248).
tendencia(4728,15,127,1230).
tendencia(4729,17,234,1260).
tendencia(4730,27,191,205).
tendencia(4731,7,222,747).
tendencia(4732,18,266,848).
tendencia(4733,25,272,874).
tendencia(4734,1,156,153).
tendencia(4735,1,249,878).
tendencia(4736,17,112,243).
tendencia(4737,13,127,277).
tendencia(4738,2,253,462).
tendencia(4739,8,106,237).
tendencia(4740,6,248,739).
tendencia(4741,22,273,610).
tendencia(4742,20,135,419).
tendencia(4743,15,288,1341).
tendencia(4744,4,182,139).
tendencia(4745,19,206,360).
tendencia(4746,22,245,884).
tendencia(4747,27,248,262).
tendencia(4748,23,113,189).
tendencia(4749,24,200,318).
tendencia(4750,25,85,1272).
tendencia(4751,13,234,946).
tendencia(4752,21,80,641).
tendencia(4753,19,228,72).
tendencia(4754,10,185,463).
tendencia(4755,20,188,87).
tendencia(4756,13,65,512).
tendencia(4757,26,267,1158).
tendencia(4758,5,160,718).
tendencia(4759,16,285,989).
tendencia(4760,15,229,227).
tendencia(4761,22,114,404).
tendencia(4762,7,89,788).
tendencia(4763,21,289,183).
tendencia(4764,14,62,1026).
tendencia(4765,25,148,265).
tendencia(4766,11,121,956).
tendencia(4767,19,62,784).
tendencia(4768,18,159,179).
tendencia(4769,27,257,781).
tendencia(4770,9,106,651).
tendencia(4771,9,275,580).
tendencia(4772,3,174,185).
tendencia(4773,6,114,743).
tendencia(4774,25,51,242).
tendencia(4775,5,51,1042).
tendencia(4776,2,134,1288).
tendencia(4777,15,132,85).
tendencia(4778,15,191,1058).
tendencia(4779,24,59,91).
tendencia(4780,21,105,1015).
tendencia(4781,12,276,79).
tendencia(4782,24,92,571).
tendencia(4783,23,277,692).
tendencia(4784,13,95,1114).
tendencia(4785,4,92,1084).
tendencia(4786,17,167,947).
tendencia(4787,24,246,604).
tendencia(4788,21,299,701).
tendencia(4789,2,110,686).
tendencia(4790,11,183,277).
tendencia(4791,9,151,418).
tendencia(4792,11,217,959).
tendencia(4793,24,134,182).
tendencia(4794,9,215,773).
tendencia(4795,25,149,26).
tendencia(4796,18,102,1309).
tendencia(4797,18,229,930).
tendencia(4798,1,272,1094).
tendencia(4799,19,144,1190).
tendencia(4800,22,146,912).
tendencia(4801,9,136,1209).
tendencia(4802,11,94,616).
tendencia(4803,17,278,1221).
tendencia(4804,22,162,144).
tendencia(4805,18,227,928).
tendencia(4806,18,65,1299).
tendencia(4807,12,214,879).
tendencia(4808,7,159,908).
tendencia(4809,5,181,1017).
tendencia(4810,26,103,1306).
tendencia(4811,24,204,238).
tendencia(4812,25,163,366).
tendencia(4813,19,188,793).
tendencia(4814,10,285,974).
tendencia(4815,2,85,293).
tendencia(4816,5,207,1057).
tendencia(4817,20,240,1133).
tendencia(4818,16,122,485).
tendencia(4819,3,287,365).
tendencia(4820,10,164,609).
tendencia(4821,23,224,441).
tendencia(4822,26,99,141).
tendencia(4823,3,87,1288).
tendencia(4824,20,67,234).
tendencia(4825,13,224,1265).
tendencia(4826,13,92,548).
tendencia(4827,2,194,353).
tendencia(4828,1,50,874).
tendencia(4829,14,273,764).
tendencia(4830,20,201,731).
tendencia(4831,4,99,1118).
tendencia(4832,23,228,1207).
tendencia(4833,5,131,1192).
tendencia(4834,14,129,70).
tendencia(4835,18,255,820).
tendencia(4836,4,240,572).
tendencia(4837,3,188,347).
tendencia(4838,4,276,256).
tendencia(4839,13,187,976).
tendencia(4840,27,81,307).
tendencia(4841,9,295,1239).
tendencia(4842,22,93,572).
tendencia(4843,22,253,345).
tendencia(4844,10,82,626).
tendencia(4845,13,285,547).
tendencia(4846,1,191,248).
tendencia(4847,26,98,155).
tendencia(4848,21,149,318).
tendencia(4849,10,51,613).
tendencia(4850,24,176,872).
tendencia(4851,17,175,1145).
tendencia(4852,22,217,1080).
tendencia(4853,1,269,270).
tendencia(4854,23,246,1222).
tendencia(4855,12,219,837).
tendencia(4856,8,253,430).
tendencia(4857,6,214,1169).
tendencia(4858,26,198,705).
tendencia(4859,23,142,654).
tendencia(4860,11,299,1321).
tendencia(4861,4,278,177).
tendencia(4862,15,237,503).
tendencia(4863,15,147,140).
tendencia(4864,6,284,491).
tendencia(4865,25,291,80).
tendencia(4866,1,111,725).
tendencia(4867,13,73,441).
tendencia(4868,9,281,1337).
tendencia(4869,25,87,663).
tendencia(4870,14,121,205).
tendencia(4871,12,134,548).
tendencia(4872,3,52,134).
tendencia(4873,13,101,796).
tendencia(4874,21,99,508).
tendencia(4875,16,177,465).
tendencia(4876,3,294,1219).
tendencia(4877,7,236,522).
tendencia(4878,13,182,763).
tendencia(4879,18,294,36).
tendencia(4880,10,109,684).
tendencia(4881,7,233,531).
tendencia(4882,26,159,195).
tendencia(4883,26,163,300).
tendencia(4884,11,51,442).
tendencia(4885,6,249,519).
tendencia(4886,12,216,918).
tendencia(4887,18,109,362).
tendencia(4888,17,187,474).
tendencia(4889,3,247,661).
tendencia(4890,12,169,177).
tendencia(4891,11,65,776).
tendencia(4892,16,182,779).
tendencia(4893,25,192,398).
tendencia(4894,27,292,1222).
tendencia(4895,24,205,246).
tendencia(4896,14,107,1333).
tendencia(4897,2,59,191).
tendencia(4898,3,245,1037).
tendencia(4899,6,300,1144).
tendencia(4900,22,141,1157).
tendencia(4901,27,91,471).
tendencia(4902,4,254,742).
tendencia(4903,7,296,840).
tendencia(4904,5,74,627).
tendencia(4905,17,68,1190).
tendencia(4906,16,286,275).
tendencia(4907,25,251,861).
tendencia(4908,4,229,770).
tendencia(4909,24,210,825).
tendencia(4910,23,243,69).
tendencia(4911,1,293,198).
tendencia(4912,8,86,216).
tendencia(4913,9,267,448).
tendencia(4914,10,285,1193).
tendencia(4915,22,82,1001).
tendencia(4916,10,179,1011).
tendencia(4917,12,272,279).
tendencia(4918,7,169,1204).
tendencia(4919,5,250,38).
tendencia(4920,12,155,597).
tendencia(4921,4,249,294).
tendencia(4922,17,102,1094).
tendencia(4923,11,169,555).
tendencia(4924,8,262,707).
tendencia(4925,6,111,497).
tendencia(4926,4,191,516).
tendencia(4927,13,108,1072).
tendencia(4928,17,115,173).
tendencia(4929,20,198,1205).
tendencia(4930,20,223,354).
tendencia(4931,21,244,748).
tendencia(4932,9,188,232).
tendencia(4933,4,223,922).
tendencia(4934,16,243,326).
tendencia(4935,22,284,772).
tendencia(4936,16,289,869).
tendencia(4937,8,75,4).
tendencia(4938,15,64,421).
tendencia(4939,5,89,279).
tendencia(4940,19,270,122).
tendencia(4941,9,248,737).
tendencia(4942,27,98,1257).
tendencia(4943,21,249,389).
tendencia(4944,9,113,1164).
tendencia(4945,5,80,611).
tendencia(4946,3,171,459).
tendencia(4947,7,260,371).
tendencia(4948,13,195,362).
tendencia(4949,21,273,1003).
tendencia(4950,25,131,824).
tendencia(4951,16,272,301).
tendencia(4952,3,84,451).
tendencia(4953,23,69,1154).
tendencia(4954,15,141,1180).
tendencia(4955,1,179,958).
tendencia(4956,23,212,286).
tendencia(4957,18,288,527).
tendencia(4958,24,55,383).
tendencia(4959,22,128,809).
tendencia(4960,21,111,686).
tendencia(4961,17,267,888).
tendencia(4962,18,268,186).
tendencia(4963,7,56,426).
tendencia(4964,11,145,765).
tendencia(4965,13,200,1099).
tendencia(4966,25,160,451).
tendencia(4967,5,247,971).
tendencia(4968,25,169,524).
tendencia(4969,21,261,396).
tendencia(4970,13,183,1108).
tendencia(4971,25,276,439).
tendencia(4972,24,281,145).
tendencia(4973,18,267,658).
tendencia(4974,3,171,650).
tendencia(4975,16,208,594).
tendencia(4976,25,86,1016).
tendencia(4977,26,113,979).
tendencia(4978,21,143,358).
tendencia(4979,9,114,1229).
tendencia(4980,22,263,13).
tendencia(4981,6,179,1046).
tendencia(4982,10,219,243).
tendencia(4983,25,196,1113).
tendencia(4984,1,259,284).
tendencia(4985,26,170,745).
tendencia(4986,2,131,541).
tendencia(4987,27,230,710).
tendencia(4988,6,128,763).
tendencia(4989,10,52,709).
tendencia(4990,7,80,1027).
tendencia(4991,25,177,583).
tendencia(4992,19,164,766).
tendencia(4993,27,137,276).
tendencia(4994,1,225,150).
tendencia(4995,25,291,803).
tendencia(4996,27,102,1278).
tendencia(4997,17,214,398).
tendencia(4998,13,64,964).
tendencia(4999,1,111,224).
tendencia(5000,26,119,230).


% mensaje de bievenida
mensaje_inicio :-
    repeat,nl,nl,
    write('*******************************************************************************'),nl,
    write('*         ¡Bienvenido al Universo Musical de tu IA Favorita!                  *'),nl,
    write('*******************************************************************************'),nl,
    write('¿En que puedo ayudarte hoy? Elige una opcion para comenzar tu viaje musical:'),nl,nl,
    write('1. Descubre una cancion basada en tu estado de animo actual.'), nl,
    write('2. Explora canciones segun tu tipo de genero preferido.'), nl,
    write('3. Encuentra una joya musical por su calificacion estelar.'), nl,
    write('4. Sumergete en el ritmo perfecto segun la duracion que deseas.'), nl,
    write('5. Generar reportes'),nl,
    write('6. Salir'),nl,nl,
    read(Opcion),
    (
        Opcion == 1 -> estado_de_animo();
        Opcion == 2 -> genero();
        Opcion == 3 -> calificacion();
        Opcion == 4 -> duracion();
        Opcion == 5 -> reportes();
        Opcion == 6 -> write('¡Hasta pronto!'),nl, !;
        true
    ).


% Regla para evaluar la opcion seleccionda por el usuario
estado_de_animo() :-
    nl,nl,
    write('!Genial, te encuentras en un estado de animo:'),nl,
    write('1. euforico'),nl,
    write('2. melancolico'),nl,
    write('3. alegre'),nl,nl,
    read(Animo),
    (
        Animo == 1 -> euforico(euforico);
        Animo == 2 -> melancolico(melancolico);
        Animo == 3 -> alegre(alegre)
    ).

genero() :- 
    nl,nl,
    write('!Genial, quieres explorar canciones segun tu tipo de genero preferido!'),nl,
    write('¿Me puedes indicar el genero que deseas escuchar?'),nl,
    write('1. Lento y suave'),nl,
    write('2. Moderado y relajado'),nl,
    write('3. Rapido y energico'),nl,
    write('4. Irregular y experimental'),nl,nl,
    read(Genero),
    (
        Genero == 1 -> lento_y_suave();
        Genero == 2 -> moderado_y_relajado();
        Genero == 3 -> rapido_y_energetico();
        Genero == 4 -> irregular_y_experimental()
    ).

calificacion() :-
    nl,nl,
    write('!Genial, quieres explorar canciones segun su calificacion estelar!'),nl,
    write('¿Me puedes indicar la calificacion maxima estelar que deseas escuchar?'),nl,
    write('1. 1 estrella'),nl,
    write('2. 2 estrellas'),nl,
    write('3. 3 estrellas'),nl,
    write('4. 4 estrellas'),nl,
    write('5. 5 estrellas'),nl,nl,
    read(Calificacion),
    (
        Calificacion == 1 -> calificacion_estelar(1);
        Calificacion == 2 -> calificacion_estelar(2);
        Calificacion == 3 -> calificacion_estelar(3);
        Calificacion == 4 -> calificacion_estelar(4);
        Calificacion == 5 -> calificacion_estelar(5)
    ).

duracion() :-
    nl,nl,
    write('!Genial, quieres explorar canciones segun su duracion!'),nl,
    write('¿Me puedes indicar la maxima duracion que deseas escuchar?'),nl,
    write('1. 1 min'),nl,
    write('2. 2 min'),nl,
    write('3. 3 min'),nl,
    write('4. 4 min'),nl,
    write('5. 5 min'),nl,nl,
    read(Duracion),
    (
        Duracion == 1 -> explorar_duracion(1);
        Duracion == 2 -> explorar_duracion(2);
        Duracion == 3 -> explorar_duracion(3);
        Duracion == 4 -> explorar_duracion(4);
        Duracion == 5 -> explorar_duracion(5)
    ).

reportes() :-
    nl,nl,
    write('!Genial, quieres ver los reportes!'),nl,
    write('¿Me puedes indicar el reporte que deseas ver?'),nl,
    write('1. Ver reporte 1'),nl,
    write('2. Ver reporte 2'),nl,
    write('3. Ver reporte 3'),nl,
    write('4. Ver reporte 4'),nl,
    write('5. Ver reporte 5'),nl,
    write('6. Ver reporte 6'),nl,nl,
    read(Reporte),
    (
        Reporte == 1 -> reporte1();
        Reporte == 2 -> reporte2();
        Reporte == 3 -> reporte3();
        Reporte == 4 -> reporte4();
        Reporte == 5 -> reporte5();
        Reporte == 6 -> reporte6()
    ).


explorar_duracion(DURACION) :-
    nl,nl,
    write('!Genial, ahora vamos por mas opciones!'),nl,
    write('¿Me puedes indicar si deseas que artista este activo o inactivo?(con comilla simple)'),nl,
    read(Activo),
    write('¿Me puedes indicar la cantidad maxima de estrellas que tiene la cancion? (1-5)'),nl,
    read(CalificacionSong),nl,nl,
    write('¿Me puedes indicar la cantidad maxima de premios que tiene la cancion? (1-10)'),nl,
    read(PremiosSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel)?'),nl,
    read(Dispositivo),nl,nl,
    write('Ya casi terminamos, ¿Me puede indicar el valor maximo de cuanto dispuesto estas a pagar por una cancion?(1-6)'),nl,
    read(Maximo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar de que pais eres?'),nl,
    read(PaisUser),nl,nl,
    write('¡Excelente!'),nl,nl,
    write('A continuacion te mostrare las canciones que se adaptan a tus gustos:'),nl,nl,
    inferencia4_match(DURACION, Activo, CalificacionSong, PremiosSong, Dispositivo, Maximo, PaisUser).
    

calificacion_estelar(ESTRELLA) :-
    nl,nl,
    write('!Genial, ahora vamos por mas opciones!'),nl,
    write('Ahora ¿Me puedes indicar el estado de animo que deseas escuchar?'),nl,
    write('1. euforico'),nl,
    write('2. melancolico'),nl,
    write('3. alegre'),nl,nl,
    read(Animo),
    (
        Animo == 1 -> explorar_calificacion_estelar(ESTRELLA, euforico);
        Animo == 2 -> explorar_calificacion_estelar(ESTRELLA, melancolico);
        Animo == 3 -> explorar_calificacion_estelar(ESTRELLA, alegre)
    ).

explorar_calificacion_estelar(ESTRELLA, ANIMO) :-
    nl,nl,
    write('!Genial, ahora vamos por mas opciones!'),nl,
    write('¿Me puedes indicar si deseas que artista este activo o inactivo?(con comilla simple)'),nl,
    read(Activo),
    write('¿Me puedes indicar si la maxima duracion de la cancion? (1-5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar el premio maximo que ha tenido la cancion? (1-10)'),nl,
    read(PremiosSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel)?'),nl,
    read(Dispositivo),nl,nl,
    write('Ya casi terminamos, ¿Me puede indicar el valor maximo de cuanto dispuesto estas a pagar por una cancion?(1-6)'),nl,
    read(Maximo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar de que pais eres?'),nl,
    read(PaisUser),nl,nl,
    write('¡Excelente!'),nl,
    write('A continuacion te mostrare las canciones que se adaptan a tus gustos:'),nl,nl,
    inferencia3_match(ESTRELLA, ANIMO, Activo, DuracionSong, PremiosSong, Dispositivo, Maximo, PaisUser).

% Caminos para cada opcion de estado de animo
lento_y_suave() :-
    nl,nl,
    write('!Genial, quieres explorar canciones lentos y suaves!'),nl,
    write('Veamos tus opciones: '),nl,
    write('1. Improvisacion sofisticada'),nl,
    write('2. Emocion melancolica'),nl,
    write('3. Historias rurales'),nl,
    write('4. Elegancia clasica'),nl,
    write('5. Espiritualidad emotiva'),nl,
    write('6. Ritmo caribeño'),nl,
    write('7. Poesia folklorica'),nl,
    write('8. Percusion vibrante'),nl,nl,
    read(Genero),
    (
        Genero == 1 -> explorar_lento_y_suave(jazz);
        Genero == 2 -> explorar_lento_y_suave(blues);
        Genero == 3 -> explorar_lento_y_suave(country);
        Genero == 4 -> explorar_lento_y_suave(classical);
        Genero == 5 -> explorar_lento_y_suave(gospel);
        Genero == 6 -> explorar_lento_y_suave(bachata);
        Genero == 7 -> explorar_lento_y_suave(trova);
        Genero == 8 -> explorar_lento_y_suave(marimba)
    ).

moderado_y_relajado() :-
    nl,nl,
    write('!Genial, quieres explorar canciones moderadas y relajadas!'),nl,
    write('Veamos tus opciones: '),nl,
    write('1. Ritmo contagioso'),nl,
    write('2. Energia intensa'),nl,
    write('3. Tradicion acustica'),nl,nl,
    read(Genero),
    (
        Genero == 1 -> explorar_moderado_y_relajado(pop);
        Genero == 2 -> explorar_moderado_y_relajado(rock);
        Genero == 3 -> explorar_moderado_y_relajado(folk)
    ).

rapido_y_energetico() :-
    nl,nl,
    write('1. Ritmo urbano'),nl,
    write('2. Sonidos sinteticos'),nl,
    write('3. Vibraciones positivas'),nl,
    write('4. Bass potente'),nl,
    write('5. Caliente y ritmica'),nl,
    write('6. Musica asiatica'),nl,nl,
    read(Genero),
    (
        Genero == 1 -> explorar_rapido_y_energetico(hip-hop);
        Genero == 2 -> explorar_rapido_y_energetico(eletronica); 
        Genero == 3 -> explorar_rapido_y_energetico(reggae);
        Genero == 4 -> explorar_rapido_y_energetico(funk);
        Genero == 5 -> explorar_rapido_y_energetico(salsa);
        Genero == 6 -> explorar_rapido_y_energetico(k-pop)
    ).

irregular_y_experimental() :-
    nl,nl,
    write('!Genial, quieres explorar canciones irregulares y experimentales!'),nl,
    write('Veamos tus opciones: '),nl,
    write('1. Instrumental'),nl,
    write('2. Subversivo y energetico'),nl,
    write('3. Intenso y estridente'),nl,nl,
    read(Genero),
    (
        Genero == 1 -> explorar_irregular_y_experimental(piccolo);
        Genero == 2 -> explorar_irregular_y_experimental(punk);
        Genero == 3 -> explorar_irregular_y_experimental(metal)
    ).


explorar_lento_y_suave(GENERO) :-
    nl,nl,
    write('!Genial, ahora vamos por mas opciones!'),nl,
    write('¿Me puedes indicar la duracion maxima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar la cantidad maxima de estrellas obtenidas de la cancion? (1 a 5)'),nl,
    read(EstrellaSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar el valor maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia2_match(GENERO, DuracionSong, EstrellaSong, Maximo, Dispositivo, PaisUser).

explorar_moderado_y_relajado(GENERO) :-
    nl,nl,
    write('!Genial, ahora vamos por mas opciones!'),nl,
    write('¿Me puedes indicar la duracion maxima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar la cantidad maxima de estrellas obtenidas de la cancion? (1 a 5)'),nl,
    read(EstrellaSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar el valor maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia2_match(GENERO, DuracionSong, EstrellaSong, Maximo, Dispositivo, PaisUser).

explorar_rapido_y_energetico(GENERO) :-
    nl,nl,
    write('!Genial, ahora vamos por mas opciones!'),nl,
    write('¿Me puedes indicar la duracion maxima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar la cantidad maxima de estrellas obtenidas de la cancion? (1 a 5)'),nl,
    read(EstrellaSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar el valor maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia2_match(GENERO, DuracionSong, EstrellaSong, Maximo, Dispositivo, PaisUser).

explorar_irregular_y_experimental(GENERO) :-
    nl,nl,
    write('!Genial, ahora vamos por mas opciones!'),nl,
    write('¿Me puedes indicar la duracion maxima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar la cantidad maxima de estrellas obtenidas de la cancion? (1 a 5)'),nl,
    read(EstrellaSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar el valor maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia2_match(GENERO, DuracionSong, EstrellaSong, Maximo, Dispositivo, PaisUser).


euforico(ANIMO) :-
    nl,nl,
    write("!Genial, te encuentras euforico!"),nl,
    write("Veamos tus opciones:"),nl,
    write('1. Bailar al ritmo de canciones bailables.'), nl,
    write('2. Explorar musica melodica que elevara tus emociones.'), nl,nl,
    read(Animo),
    (
        Animo == 1 -> bailar_al_ritmo(ANIMO,bailable);
        Animo == 2 -> explorar_melodica(ANIMO,melodico)
    ).

melancolico(ANIMO) :-
    nl,nl,
    write('Ho no, te encuentras melancolico'),nl,
    write('Veamos tus opciones:'),nl,
    write('1. Explorar canciones que te ayudaran a superar tu estado de animo.'),nl,
    write('2. Explorar canciones que te relajen en tu estao de animo.'),nl,nl,
    read(Animo),
    (
        Animo == 1 -> explorar_melancolico_bailable(ANIMO,bailable);
        Animo == 2 -> explorar_melancolico_instrumental(ANIMO,instrumental)
    ).

alegre(ANIMO) :-
    nl,nl,
    write('!Genial, te encuentras alegre!'),nl,
    write('Veamos tus opciones:'),nl,
    write('1. Explorar canciones para alegrarte mas.'),nl,
    write('2. Explorar canciones melodicas.'),nl,nl,
    read(Animo),
    (
        Animo == 1 -> explorar_alegre_bailable(ANIMO,bailable);
        Animo == 2 -> explorar_alegre_melodica(ANIMO,melodico)
    ).

explorar_alegre_bailable(ANIMO, TIPOSONG) :-
    nl,nl,
    write('!Genial, quieres explorar canciones bailables!'),nl,
    write('¿Me puedes indicar la duracion minima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar el premio minimo obtenido de la cancion? (1 a 10)'),nl,
    read(PremioSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar lo maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia1_match(ANIMO, TIPOSONG, DuracionSong, PremioSong, Maximo, Dispositivo, PaisUser).

explorar_alegre_melodica(ANIMO, TIPOSONG) :-
    nl,nl,
    write('!Genial, quieres explorar musica melodica!'),nl,
    write('¿Me puedes indicar la duracion minima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar el premio minimo obtenido de la cancion? (1 a 10)'),nl,
    read(PremioSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar lo maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia1_match(ANIMO, TIPOSONG, DuracionSong, PremioSong, Maximo, Dispositivo, PaisUser).


explorar_melancolico_bailable(ANIMO, TIPOSONG) :-
    nl, nl,
    write('!Genial, quieres explorar canciones bailables!'),nl,
    write('¿Me puedes indicar la duracion minima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar el premio minimo obtenido de la cancion? (1 a 10)'),nl,
    read(PremioSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar lo maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia1_match(ANIMO, TIPOSONG, DuracionSong, PremioSong, Maximo, Dispositivo, PaisUser).

explorar_melancolico_instrumental(ANIMO, TIPOSONG) :-
    nl, nl,
    write('!Genial, quieres explorar canciones instrumentales!'),nl,
    write('¿Me puedes indicar la duracion minima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar el premio minimo obtenido de la cancion? (1 a 10)'),nl,
    read(PremioSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar lo maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia1_match(ANIMO, TIPOSONG, DuracionSong, PremioSong, Maximo, Dispositivo, PaisUser).

bailar_al_ritmo(ANIMO, TIPOSONG) :-
    nl,nl,
    write('!Genial, quieres bailar!'),nl,
    write('¿Me puedes indicar la duracion minima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar el premio minimo obtenido de la cancion? (1 a 10)'),nl,
    read(PremioSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar lo maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia1_match(ANIMO, TIPOSONG, DuracionSong, PremioSong, Maximo, Dispositivo, PaisUser).

explorar_melodica(ANIMO, TIPOSONG) :-
    nl,nl,
    write('!Genial, quieres explorar musica melodica!'),nl,
    write('¿Me puedes indicar la duracion minima de la cancion que deseas escuchar? (1 a 5 min)'),nl,
    read(DuracionSong),nl,nl,
    write('Ahora ¿Me puedes indicar el premio minimo obtenido de la cancion? (1 a 10)'),nl,
    read(PremioSong),nl,nl,
    write('Ahora bien, ¿Me puedes indicar lo maximo que quieres gastar por cancion? (1-6)'),nl,
    read(Maximo),nl,nl,
    write('Ya casi terminamos, ¿Me puedes indicar el dispositivo donde escuchas (pc o tel en comillas simples)?'),nl,
    read(Dispositivo),nl,nl,
    write('Por ultimo, ¿Me puedes indicar que de pais eres'),nl,nl,
    read(PaisUser),
    inferencia1_match(ANIMO, TIPOSONG, DuracionSong, PremioSong, Maximo, Dispositivo, PaisUser).

% Inferencias que hacen match
inferencia1_match(ANIMO, TIPOSONG, DuracionSong, PremioSong, Maximo, Dispositivo, PaisUser) :-
    artista(IDA,NA,IDP,EA),
    genero(IDG,GS,TG,AG),
    cancion(IDC,NS,IDA,Anio,IDG,Duracion,Estrellas,Premios,Precio),
    pais(IDP,Pais,_),
    (
        Dispositivo == 'pc' -> IVA is 1.25;
        Dispositivo == 'tel' -> IVA is 0.65
    ),
    AG == ANIMO,
    TG == TIPOSONG,
    Duracion =< DuracionSong,
    Premios =< PremioSong,
    SubPrecio is Precio + IVA,
    (
        Pais == PaisUser -> Descuento is (SubPrecio * 0.25);
        Pais \= PaisUser -> Descuento is 0
    ),

    TotalFijo is SubPrecio - Descuento,
    TotalFijo =< Maximo,
    imprimirInferencia1(NS,NA,Pais,Anio,Estrellas,Duracion,GS,AG,Precio,IVA,TotalFijo).

inferencia2_match(GENERO, DuracionSong, EstrellaSong, Maximo, Dispositivo, PaisUser) :-
    artista(IDA,NA,IDP,EA),
    genero(IDG,GS,TG,AG),
    cancion(IDC,NS,IDA,Anio,IDG,Duracion,Estrellas,Premios,Precio),
    pais(IDP,Pais,_),
    (
        Dispositivo == 'pc' -> IVA is 1.25;
        Dispositivo == 'tel' -> IVA is 0.65
    ),
    GS == GENERO,
    Duracion =< DuracionSong,
    Estrellas =< EstrellaSong,
    SubPrecio is Precio + IVA,
    (
        Pais == PaisUser -> Descuento is (SubPrecio * 0.25);
        Pais \= PaisUser -> Descuento is 0
    ),

    TotalFijo is SubPrecio - Descuento,
    TotalFijo =< Maximo,
    imprimirInferencia1(NS,NA,Pais,Anio,Estrellas,Duracion,GS,AG,Precio,IVA,TotalFijo).

inferencia3_match(ESTRELLA, ANIMO, Activo, DuracionSong, PremiosSong, Dispositivo, Maximo, PaisUser) :-
    artista(IDA,NA,IDP,EA),
    genero(IDG,GS,TG,AG),
    cancion(IDC,NS,IDA,Anio,IDG,Duracion,Estrellas,Premios,Precio),
    pais(IDP,Pais,_),
    (
        Dispositivo == 'pc' -> IVA is 1.25;
        Dispositivo == 'tel' -> IVA is 0.65
    ),
    Estrellas =< ESTRELLA,
    AG == ANIMO,
    EA == Activo,
    Duracion =< DuracionSong,
    Premios =< PremiosSong,
    SubPrecio is Precio + IVA,
    (
        Pais == PaisUser -> Descuento is (SubPrecio * 0.25);
        Pais \= PaisUser -> Descuento is 0
    ),

    TotalFijo is SubPrecio - Descuento,
    TotalFijo =< Maximo,
    imprimirInferencia1(NS,NA,Pais,Anio,Estrellas,Duracion,GS,AG,Precio,IVA,TotalFijo).

inferencia4_match(DURACION, Activo, CalificacionSong, PremiosSong, Dispositivo, Maximo, PaisUser) :-
    artista(IDA,NA,IDP,EA),
    genero(IDG,GS,TG,AG),
    cancion(IDC,NS,IDA,Anio,IDG,Duracion,Estrellas,Premios,Precio),
    pais(IDP,Pais,_),
    (
        Dispositivo == 'pc' -> IVA is 1.25;
        Dispositivo == 'tel' -> IVA is 0.65
    ),
    Duracion =< DURACION,
    Estrellas =< CalificacionSong,
    EA == Activo,
    Premios =< PremiosSong,
    SubPrecio is Precio + IVA,
    (
        Pais == PaisUser -> Descuento is (SubPrecio * 0.25);
        Pais \= PaisUser -> Descuento is 0
    ),

    TotalFijo is SubPrecio - Descuento,
    TotalFijo =< Maximo,
    imprimirInferencia1(NS,NA,Pais,Anio,Estrellas,Duracion,GS,AG,Precio,IVA,TotalFijo).

imprimirInferencia1(NombreCancion,NombreArtist,PaisArtista, AnioCancion, EstrellasCancion, DuracionCancion, GeneroCancion, AnimoGenero, PreCancion, PreAgregado, PreTotal) :-
    format('
        |-------------------------------------------|
        |           Cancion recomendada             |
        |-------------------------------------------|
        |   Nombre de la Cancion: ~a
        |   Artista: ~a
        |   Pais del Artista: ~a
        |   Anio: ~a
        |   Estrellas: ~a
        |   Duracion: ~a
        |   Genero: ~a
        |   Animo del Genero: ~a
        |-------------------------------------------|
        |   Precio: ~a                                 
        |   IVA: ~a                                    
        |   Total: ~a                                  
        |-------------------------------------------|
    ',[NombreCancion,NombreArtist,PaisArtista,AnioCancion,EstrellasCancion,DuracionCancion, GeneroCancion, AnimoGenero, PreCancion,PreAgregado, PreTotal]),!,fail.


reporte1() :-
    nl, nl,
    write('************************************************************'), nl,
    write('***********************  Reporte 1  ************************'), nl,
    write('************************************************************'), nl,
    write('Artista              Cancion             Anio        Premios'), nl,
    write('------------------------------------------------------------'), nl,
    artista(IDA, NA, _, _),
    genero(IDG, GS, _, _),
    cancion(_, NS, IDA, Anio, IDG, _, _, Premios, _),
    Anio >= 1985,
    Anio =< 1990,
    Premios >= 5,
    GS == pop,
    format('~|~a~22+~|~a~20+~|~a~8+~|~t~a~5+~n', [NA, NS, Anio, Premios]),nl,
    fail.


reporte2() :-
    nl,nl,
    write('***********************************************************************************'), nl,
    write('************************************  Reporte 2  **********************************'), nl,
    write('***********************************************************************************'), nl,
    write('Pais                Artista             Cancion                               Horas'), nl,
    write('-----------------------------------------------------------------------------------'), nl,
    artista(IDA, NA, _, _),
    genero(IDG, GS, _, _),
    cancion(IDC, NS, IDA, _, IDG, _, Estrellas, _, _),
    pais(IDP, Pais, _),
    tendencia(_,IDP, Horas, IDC),
    Horas > 250,
    Estrellas == 5,
    GS == trova,
    format('~|~a~20+~|~a~20+~|~a~40+~|~a~5+~n', [Pais, NA, NS, Horas]),nl,fail.

reporte3() :-
    nl,nl,
    write('*******************************************************'), nl,
    write('********************  Reporte 3 ***********************'), nl,
    write('*******************************************************'), nl,
    write('Cancion             Genero              Artista    '), nl,
    write('-------------------------------------------------------'), nl,
    artista(IDA, NA, _, _),
    genero(IDG, GS, TS, AS),
    cancion(_, NS, IDA, _, IDG, Duracion, _, _, _),
    TS == bailable,
    AS == euforico,
    Duracion < 3,
    format('~|~a~20+~|~a~20+~|~a~20+~n', [NS, GS, NA]),nl,fail.

reporte4() :-
    nl,nl,
    write('**************************************************************'), nl,
    write('***********************  Reporte 4  **************************'), nl,
    write('**************************************************************'), nl,
    write('Pais      Cancion                       Estrellas      Genero'), nl,
    write('--------------------------------------------------------------'), nl,
    genero(IDG, GS, _, _),
    cancion(IDC, NS, _, _, IDG, _, Estrellas, _, _),
    pais(IDP, Pais, Continente),
    tendencia(_,IDP, Horas, IDC),
    GS == salsa,
    Horas >= 290,
    Continente == asia,
    format('~|~a~10+~|~a~30+~|~a~10+~|~t~a~10+~n', [Pais, NS, Estrellas, GS]),nl,fail.

reporte5() :-
    nl,nl,
    write('******************************************'), nl,
    write('***************  Reporte 5  **************'), nl,
    write('******************************************'), nl,
    write('Cancion            Estrellas        Precio'), nl,
    write('------------------------------------------'), nl,
    artista(IDA, NA, _, _),
    cancion(IDC, NS, IDA, _, _, _, Estrellas, Premios, Precio),
    pais(IDP, Pais, _),
    tendencia(_,IDP, _, IDC),
    NA == 'bts',
    Pais == colombia,
    Premios >= 7,
    Precio < 3,
    format('~|~a~20+~|~a~10+~|~t~a~10+~n', [NS, Estrellas, Precio]),nl,fail.

reporte6() :-
    nl,nl,
    write('***************************************************************************************'), nl,
    write('***************************************  Reporte 6  ***********************************'), nl,
    write('***************************************************************************************'), nl,
    write('Cancion                       Pais                     Anio     Ganancias'), nl,
    write('---------------------------------------------------------------------------------------'), nl,
    artista(IDA, NA, _, _),
    cancion(IDC, NS, IDA, Anio, _, Duracion, _, _, Precio),
    pais(IDP, Pais, Continente),
    tendencia(_,IDP, Horas, IDC),
    NA == 'the beatles',
    Horas < 60,
    Continente == america,
    NoReproducciones is Horas / Duracion,
    Ganancias is NoReproducciones * Precio,
    format('~|~a~30+~|~a~25+~|~a~8+~|~t~a~5+~n', [NS, Pais, Anio, Ganancias]),nl,fail.